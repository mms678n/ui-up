# Standalone tool tags after prose

The compatibility parser previously streamed a standalone tool envelope as plain text when the model prefixed it with prose. It now buffers potential standalone tag prefixes across chunk boundaries and requests one format repair through the existing bounded retry. A singleton calls object is normalized to a list before name, choice, parallel and argument-schema validation. Quoted/inline/fenced examples remain text; they are never directly executed. Plain text continues streaming.

Run on the platform VPS. Only backend/tool_compat.py is patched; a backup is saved and incompatible source layouts are rejected before writing. The app service is rebuilt afterwards. This does not change the token limits or model settings.

```bash
(
set -eu
cd ~/j/RSVX7-AI
python3 - <<'PY'
#!/usr/bin/env python3
import ast, base64, os, shutil, subprocess, tempfile, zlib
from pathlib import Path
from datetime import datetime, timezone

PAYLOAD = 'eNqdWF9z0zgQf8+n2OMebDduaCjQUgjTG4YeDxzcAA83UzpBcTaJQLGNJJf2euWz32otJ7bjZEo9Q2pZ+1+7v12xv78P4uFEJN8wnT60WabGSbbMhR3k171+vw+TbZunp7B/GD+F/mF8BKenPeiBXOaZtvDVZOlqkZle379qXH01mGi0pgcznS3BXudoqq2P9FfhO7FEk4uEWFjT0ZFTdXQcP3nKytxDEgqdwqVQcipspo2zoddPlDAGxp/wyn4ik/8shJ6e9PqO48GDB28yNYU8M0ZOFIKxIp0KlaUIVszNc5KZC6nBLnAJMjUWxRSyGeAVJoWV6Ry+F5nFKViSPiBxpdwpzmA8lqm043FoUM0ir9A9bj3IKYLEHvuVzibr1QzTBGEEQRDDJ11gDO/IoF5/LXuGOGW5MSuuS7+UpScjOL9Yf/0d3qfqGt6eAek1IIA02izJFCiZ4nNaokF9ifDqw9uzmDxNVOHsA5MraSFZFOk3M1jLy4W2hnSw20wTBp/TIFpTzDJNYqZ4FTMxvZPqYolaWAyZvW61e8gyCuSo5IIXoDD1hLAPwyYti+xTiEgpyJnnRWWQotYkpd00s8zRUuieJEvpGAvs5KmfTQevD/VA5O402dao5RIZ1MFYzwDnhePcpFIu10YN4oEyVss8DOCz/ayDaJOJLF/nUIdq9nkhdAw/5NQuKvlM3k1dRXeLME+icTArlFoKmyxCWqBJRI6hUxVBH4KbgH7J+JDV8qf49pzduNijQ4zZ3WiHklXgqvIoi6KLDNUdLNqrtN9Bd3eW7DhhHxUnd0CYQkn8Q9pF+P7v1+926dFCUga/YkyVE0lldX2WaXLhtdaZDgOGXEwvUWU5jsXMoh67EuzKhFoel9VByAahW3JiUXk6a+rWcRTuFwaueH8uFGsf9CD8cnMY3/730/1GVZy3mrorZzk6RUrimWow11mRh9HOnGy67uCEJEQwGvH7XfJtt8MbGenknx9cxCtd0Y78bFtHZ0IYGQZfKE7BF/79yT8/g/udSQue6jgS7cakZlfynehMUKpvwOQ2aGgJcG1sTeQbdRAMvmYyDb2hUaPDqcIsNlqnFVLFTfgctSyvw7/X47ic7B6Uo4CbAl77IjopRwfq3NwgBbiBRqHFMllZJF5Rg0ukpX0aCuau0XhuSEQKEyQedKxCKZ4BoHMGoF5Nik1M+JvJBEcOv7g5Ehsqv1wPL/yBnHfTzvHjeHgI/eHhk3j4eDXvrOJcCqwC4wVSZKrv1acWm8bvhdTcc0tKVxpB9TVwEEEnk7qZKHHAWQqbyoTaXFPSMptW6ifFbIbaL4z8lwcZfzounenfQWsWcgg2nruxjGibcxpVOKzDuTn2NM1gdf2yvJmgt9EXmeQl/PXHP+NXb/748LEm4i4AnBU2L+yYDnKshJ5j0KHCBYMjycjM1b0aJqrgnvT2G2p9ohJDs5T8RitMAw5Ey8Na9F0MWNZ226oTafnP40WOq7mjlFeNHREn47Nn8THl4pNhPBw2crGRDu7YXb7zeFaJ3eiFfmTjSN03ks0DRFMo28jFpi+MEF3BLznvHv6SvnYAK1TbwDHu0Rtgtk04I1/0S0FYTb71YiHo8RAaky5Bl7B6wWzNiKYGnwD+/Es0Gj7ie96Qbl/HjQTwXa0GGgRlwkOGgxODlj9F8NsIbgIHmCa4/cUalCmD5GoOqtcgS6QDd0rOvfzaNYgMrCOa2/bWtVpYJeecXy52ueilKGlKH932EF6UKMSbkVsNHx3f008ng+7ZRWq70KaG3Ck1DEbtsNkIpCmb92oM8la9hKE/0cNheXM/OoiHBxs1XT1Rb/cEsmWcRedO5/2KOC9R284BwjVt4KsRXUwHtTLqvvQ48i1T0rVEuuKP+Q7LoDlyxC1nSETNmt0yOHyj85uAb6rBSXXP3dtzO7f1q6/70Lz6rrREFy0TCiPmDjZb/+ER0hS1zF3P+YapGdnMCjXO42pQkVna3Eri3v8hzPH9'

root = Path.cwd()
p = root / "backend/tool_compat.py"
if not p.is_file() or p.is_symlink() or not (root / "deploy/compose.selfhost.yaml").is_file():
    raise SystemExit("Run inside ~/j/RSVX7-AI; expected compatibility module is missing.")
original = p.read_bytes()
patch = zlib.decompress(base64.b64decode(PAYLOAD))
with tempfile.TemporaryDirectory() as directory:
    stage = Path(directory)
    target = stage / "backend/tool_compat.py"
    target.parent.mkdir()
    target.write_bytes(original)
    def git(*args):
        return subprocess.run(["git", "apply", *args, "-"], cwd=stage,
                              input=patch, capture_output=True)
    check = git("--check")
    if check.returncode:
        if git("--reverse", "--check").returncode == 0:
            print("Tool-call fix is already installed.")
            raise SystemExit(0)
        raise SystemExit("Source differs from the expected version. No files changed.")
    applied = git()
    if applied.returncode:
        raise SystemExit("Patch failed. No project files changed.")
    updated = target.read_bytes()
    ast.parse(updated)
    if p.read_bytes() != original:
        raise SystemExit("Source changed during patching. Aborted.")
    backup = root / ".rsvx7-backups" / ("tool-tag-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ"))
    backup.mkdir(parents=True, mode=0o700)
    shutil.copy2(p, backup / p.name)
    fd, name = tempfile.mkstemp(prefix=".tool-compat-", dir=p.parent)
    try:
        with os.fdopen(fd, "wb") as file:
            file.write(updated)
        os.chmod(name, p.stat().st_mode & 0o777)
        os.replace(name, p)
    finally:
        if os.path.exists(name): os.unlink(name)
    print("Tool-call fix installed. Backup:", backup)
PY
export RSVX7_SELFHOST_ENV="$PWD/.env.selfhost"
docker compose -p rsvx7 --env-file "$RSVX7_SELFHOST_ENV" -f deploy/compose.selfhost.yaml up -d --build --no-deps --wait --wait-timeout 300 app
)
```

On the separate Ubuntu/proot environment where OpenCode executes shell commands, install its missing netcat utility:

```bash
apt-get update && apt-get install -y netcat-openbsd
```

Then start a new OpenCode conversation and ask it to run pwd and return the actual result. Tool calls are proposed by the model and executed by the client according to its permissions. Formatting repair is bounded and cannot guarantee that every model response will be correct.

Validation: 87 focused tests passed (text compatibility, real OpenAI SDK with mocked upstream, API tools, disconnect/lifetime handling, and legacy installer). New inline installer verified for application, repeat execution, backup integrity, unrelated environment preservation and rejection of incompatible source. No live VPS deployment or paid model test was performed.

Full-suite attempt: 110 passed plus 27 subtests, then stopped at tests/test_auth_regressions.py::test_password_validation_is_72_utf8_bytes_before_bcrypt because fixture MongoDB at 127.0.0.1:27017 was unavailable (connection refused). Full-project success is not claimed.
