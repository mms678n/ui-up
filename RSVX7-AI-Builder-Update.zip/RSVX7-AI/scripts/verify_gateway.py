#!/usr/bin/env python3
"""Check resolved Compose configuration and real gateway HTTP/TLS, without secrets."""
import argparse
import http.client
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import ssl
import subprocess
import sys
import time
from urllib.parse import urlsplit


class GatewayError(ValueError):
    pass


def gateway_settings(config):
    services=config['services']
    app=services['app'].get('environment',{})
    gateway=services['gateway']
    address=str(gateway.get('environment',{}).get('SITE_ADDRESS','')).strip()
    if not address or re.search(r'[\s,{}]',address):
        raise GatewayError('invalid_site_address')
    site=urlsplit(address if '://' in address else '//'+address) if address!=':80' else None
    https=address!=':80' and (site.scheme=='https' or (site.scheme!='http' and site.port!=80))
    if https:
        if not site.hostname or site.port not in (None,443):raise GatewayError('invalid_site_address')
        host=site.hostname
    elif site and site.hostname:
        if site.port not in (None,80):raise GatewayError('invalid_site_address')
        host=site.hostname
    else:
        origins=str(app.get('CORS_ORIGINS','')).split(',')
        origin=urlsplit(origins[0].strip() or str(app.get('OPENROUTER_SITE_URL','http://localhost')))
        host=origin.hostname or 'localhost'
        if origin.scheme=='https':raise GatewayError('https_not_configured')
    if (site and (site.scheme not in ('','http','https') or site.username or site.password or site.path not in ('','/') or site.query or site.fragment)) or not re.fullmatch(r'[A-Za-z0-9.-]{1,253}',host):
        raise GatewayError('invalid_site_address')
    if not https and str(app.get('COOKIE_SECURE','')).lower()=='true':
        raise GatewayError('https_not_configured')
    if https:
        try:ipaddress.ip_address(host)
        except ValueError:pass
        else:raise GatewayError('https_requires_domain')
    target=443 if https else 80
    ports=[p for p in gateway.get('ports',[]) if int(p['target'])==target and p.get('protocol','tcp')=='tcp']
    if len(ports)!=1:raise GatewayError('gateway_port_not_published')
    port=int(ports[0]['published'])
    bind=ports[0].get('host_ip') or '0.0.0.0'
    connect_host={'0.0.0.0':'127.0.0.1','::':'::1'}.get(bind,bind)
    default=443 if https else 80
    origin=('https' if https else 'http')+'://'+host+(':'+str(port) if port!=default else '')
    return {'https':https,'host':host,'port':port,'connect_host':connect_host,
            'origin':origin,'release':str(app.get('RSVX7_RELEASE_ID',''))}


def public_addresses(host,port):
    addresses=[]
    for family,_,_,_,target in socket.getaddrinfo(host,port,type=socket.SOCK_STREAM):
        if family in (socket.AF_INET,socket.AF_INET6) and target[0] not in addresses:
            addresses.append(target[0])
    if not addresses:raise socket.gaierror('no_addresses')
    return addresses


class LocalHTTPS(http.client.HTTPSConnection):
    """Reach the published port locally while verifying the domain and its chain."""
    def __init__(self,host,port,connect_host,context,timeout):
        super().__init__(host,port,context=context,timeout=timeout)
        self.connect_host=connect_host

    def connect(self):
        sock=socket.create_connection((self.connect_host,self.port),self.timeout)
        try:self.sock=self._context.wrap_socket(sock,server_hostname=self.host)
        except BaseException:
            sock.close()
            raise


def probe(settings,*,local=False,context=None,timeout=4):
    """No redirects or unverified TLS; /readyz must belong to this release."""
    if settings['https'] and not local:
        # A browser may choose any A/AAAA address. Connection fallback can hide
        # a broken route, so verify every resolved address with the same SNI.
        addresses=public_addresses(settings['host'],settings['port'])
        for address in addresses:
            probe({**settings,'connect_host':address},local=True,context=context,timeout=timeout)
        return
    for path in ('/readyz','/'):
        if settings['https']:
            context=context or ssl.create_default_context()
            if local:
                connection=LocalHTTPS(settings['host'],settings['port'],settings['connect_host'],context,timeout)
            else:connection=http.client.HTTPSConnection(settings['host'],settings['port'],context=context,timeout=timeout)
        else:
            connection=http.client.HTTPConnection(settings['connect_host'] if local else settings['host'],settings['port'],timeout=timeout)
        try:
            connection.request('GET',path,headers={'Host':urlsplit(settings['origin']).netloc,'Connection':'close'})
            response=connection.getresponse()
            if response.status!=200:raise GatewayError('gateway_http_response')
            if path=='/readyz':
                body=json.loads(response.read(4097))
                if body.get('status')!='ready':raise GatewayError('application_not_ready')
                if settings['release'] and body.get('release')!=settings['release']:raise GatewayError('release_mismatch')
            elif 'text/html' not in response.getheader('Content-Type',''):
                raise GatewayError('frontend_not_ready')
        finally:connection.close()


def load_settings(env_file,compose_file):
    command=['docker','compose','-p','rsvx7','--env-file',str(env_file),'-f',str(compose_file),'config','--format','json']
    try:
        result=subprocess.run(command,env=dict(os.environ,RSVX7_SELFHOST_ENV=str(env_file)),capture_output=True,text=True,timeout=20)
        if result.returncode:raise GatewayError('compose_configuration_failed')
        return gateway_settings(json.loads(result.stdout))
    except GatewayError:raise
    except Exception:raise GatewayError('compose_configuration_failed') from None


def error_code(error):
    if isinstance(error,GatewayError):return str(error)
    if isinstance(error,ssl.SSLCertVerificationError):return 'certificate_not_verified'
    if isinstance(error,ssl.SSLError):return 'tls_handshake_failed'
    if isinstance(error,socket.gaierror):return 'dns_lookup_failed'
    if isinstance(error,(TimeoutError,socket.timeout)):return 'connection_timeout'
    if isinstance(error,ConnectionError):return 'connection_failed'
    return 'gateway_unavailable'


def main():
    root=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--env-file',default=str(root/'.env.selfhost'))
    parser.add_argument('--compose-file',default=str(root/'deploy/compose.selfhost.yaml'))
    parser.add_argument('--preflight',action='store_true')
    parser.add_argument('--attempts',type=int,default=12)
    parser.add_argument('--delay',type=float,default=5)
    args=parser.parse_args()
    if not 1<=args.attempts<=24 or not 0<=args.delay<=10:parser.error('Invalid retry limits.')
    try:settings=load_settings(Path(args.env_file).resolve(),Path(args.compose_file).resolve())
    except Exception as error:
        print('RSVX7_GATEWAY:configuration:'+error_code(error),file=sys.stderr)
        print('For an existing domain: python3 scripts/init_selfhost.py --env-file YOUR_ENV_FILE --set-site https://YOUR_DOMAIN',file=sys.stderr)
        return 1
    print('RSVX7_GATEWAY:site='+settings['origin'],flush=True)
    if args.preflight:return 0
    failure='gateway_unavailable';scope='local'
    for attempt in range(args.attempts):
        try:
            scope='local';probe(settings,local=True)
            scope='public';probe(settings)
            print('RSVX7_GATEWAY:ready',flush=True)
            return 0
        except Exception as error:failure=error_code(error)
        print('RSVX7_GATEWAY:waiting:'+scope+':'+failure,flush=True)
        if attempt+1<args.attempts:time.sleep(args.delay)
    print('Gateway check failed: '+scope+':'+failure,file=sys.stderr)
    print('Inspect: docker logs --tail=80 rsvx7-gateway-1',file=sys.stderr)
    print('Check domain A/AAAA records and public TCP ports 80/443. A running app alone does not confirm HTTPS.',file=sys.stderr)
    return 1


if __name__=='__main__':raise SystemExit(main())
