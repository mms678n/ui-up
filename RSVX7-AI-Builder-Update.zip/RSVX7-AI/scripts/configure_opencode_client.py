import json
import os
import shutil
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

folder = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'opencode'
path = folder / 'opencode.json'
config = json.loads(path.read_text())
key = config.get('provider', {}).get('rsvx7', {}).get('options', {}).get('apiKey', '').strip()
if not key or key.startswith('{'):
    raise SystemExit('No literal RSVX7 API key in ' + str(path))
base = 'https://rsvx7-ai.com/api/v1'
request = urllib.request.Request(base + '/models', headers={'Authorization': 'Bearer ' + key})
with urllib.request.urlopen(request, timeout=30) as response:
    rows = json.load(response)['data']
models = {}
for row in rows:
    name = row.get('id')
    if name not in ('kaligpt', 'deepdark', 'rsvx7-ai'):
        continue
    context, output = row.get('context_length'), row.get('max_output_tokens')
    if not isinstance(context, int) or not isinstance(output, int) or context < 4096 or output < 1:
        raise SystemExit('Server did not return usable limits: ' + str(name))
    models[name] = {'name': name, 'limit': {'context': context, 'output': min(2048, output, context // 4)}}
if not models:
    raise SystemExit('No accessible models returned.')
selected = 'kaligpt' if 'kaligpt' in models else next(iter(models))
patch = {
    '$schema': 'https://opencode.ai/config.json',
    'provider': {'rsvx7': {'npm': '@ai-sdk/openai-compatible', 'name': 'RSVX7-AI',
        'options': {'baseURL': base, 'apiKey': key}, 'models': models}},
    'model': 'rsvx7/' + selected,
    'small_model': 'rsvx7/' + selected,
    'compaction': {'auto': True, 'prune': True, 'reserved': 1024},
    'agent': {'rsvx7-lite': {
        'description': 'Coding with a small context window', 'mode': 'primary',
        'prompt': 'You are a coding assistant. Follow the user language. Inspect relevant files, make focused changes, and verify them. Read small file ranges. Use tools only when needed and never claim unobserved results. Keep responses concise.',
        'permission': {'*': 'deny', 'read': 'allow', 'edit': 'ask', 'bash': 'ask', 'glob': 'allow', 'grep': 'allow'},
    }},
}
target = folder / 'rsvx7-fixed.json'
if target.exists():
    backup = target.with_name(target.name + '.backup-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
    shutil.copy2(target, backup)
    backup.chmod(0o600)
fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
os.fchmod(fd, 0o600)
with os.fdopen(fd, 'w') as file:
    json.dump(patch, file, ensure_ascii=False, indent=2)
    file.write('\n')
print('Saved:', target)
for name, model in models.items():
    print(name, model['limit'])
