import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { mkdir, readFile, writeFile, readdir } from 'node:fs/promises';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(resolve(root, 'frontend/package.json'));
const { build: compile } = require('esbuild');
// Write outputs through the orchestrating process. This also works on virtual
// filesystems where native compiler writes are not visible to the next build step.
async function build(options) {
  const result = await compile({ ...options, write: false });
  for (const output of result.outputFiles) {
    await mkdir(dirname(output.path), { recursive: true });
    await writeFile(output.path, output.contents);
  }
  return result;
}
const vendor = resolve(root, 'builder/vendor/darkforge');
const common = { bundle: true, target: 'es2022', minify: true,
  alias: { '~': resolve(vendor, 'app') }, nodePaths: [resolve(root, 'frontend/node_modules')], logLevel: 'info' };
await mkdir(resolve(root, 'builder/dist'), { recursive: true });
await mkdir(resolve(root, 'frontend/src/builder'), { recursive: true });
await mkdir(resolve(root, 'frontend/public/internal'), { recursive: true });
await build({ ...common, entryPoints: [resolve(root, 'builder/service.ts')], outfile: resolve(root, 'builder/dist/service.mjs'), platform: 'node', format: 'esm', define: { 'import.meta.env': '{}' } });
await build({ ...common, entryPoints: [resolve(root, 'builder/runtime-entry.ts')], outfile: resolve(root, 'frontend/src/builder/generated-runtime.js'), platform: 'browser', format: 'esm' });
await build({ ...common, entryPoints: [resolve(root, 'builder/widgets-entry.ts')], outfile: resolve(root, 'frontend/src/builder/generated-widgets.js'), platform: 'browser', format: 'esm', external: ['react', 'react/jsx-runtime', 'lucide-react'], jsx: 'automatic' });
for (const name of ['generated-runtime.js', 'generated-widgets.js']) {
 const output = resolve(root, 'frontend/src/builder', name); await writeFile(output, '/* eslint-disable */\n' + await readFile(output, 'utf8'));
}
const result = await build({ ...common, entryPoints: [resolve(vendor, 'verification/cli.ts')], outfile: resolve(root, 'frontend/public/internal/project-verifier.js'), platform: 'node', format: 'cjs', metafile: true });
const notices = new Map();
for (const input of Object.keys(result.metafile.inputs)) {
  let folder = dirname(resolve(input));
  while (dirname(folder) !== folder) {
    let pkg;
    try { pkg = JSON.parse(await readFile(resolve(folder, 'package.json'), 'utf8')); } catch {}
    if (pkg?.name) {
      if (!notices.has(pkg.name)) {
        const files = (await readdir(folder)).filter(n => /^(?:licen[cs]e|copying|notice)(?:\.[^.]+)?$/i.test(n));
        notices.set(pkg.name, pkg.name + '@' + pkg.version + '\n' + (await Promise.all(files.map(n => readFile(resolve(folder, n), 'utf8')))).join('\n'));
      }
      break;
    }
    folder = dirname(folder);
  }
}
const output = resolve(root, 'frontend/public/internal/project-verifier.js');
await writeFile(output, (await readFile(output, 'utf8')) + '\n/*! Open-source notices\n' + [...notices.values()].join('\n\n').replaceAll('*/', '* /') + '\n*/\n');
