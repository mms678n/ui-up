#!/usr/bin/env python3
"""Read-only HTTPS diagnosis. Prints only selected public settings and fixed codes."""
import argparse
import http.client
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import socket
import ssl
import subprocess
from urllib.parse import urlsplit

from init_selfhost import site_values
from verify_gateway import error_code, probe, public_addresses


def safe_site(value):
    value=str(value or '').strip()
    if value==':80':return value
    try:
        parsed=urlsplit(value if '://' in value else '//'+value)
        if parsed.scheme not in ('','http','https') or parsed.username or parsed.password or parsed.path not in ('','/') or parsed.query or parsed.fragment:return 'invalid'
        if not parsed.hostname or not re.fullmatch(r'[A-Za-z0-9.-]{1,253}',parsed.hostname):return 'invalid'
        if parsed.port not in (None,80,443):return 'invalid'
        return (parsed.scheme+'://' if parsed.scheme else '')+parsed.hostname+(':'+str(parsed.port) if parsed.port else '')
    except ValueError:return 'invalid'


def command(arguments,env=None,*,include_stderr=False):
    # Capture all subprocess output; raw Compose data, logs and errors are private.
    try:
        result=subprocess.run(arguments,env=env,capture_output=True,text=True,timeout=20)
        return result.stdout+(result.stderr if include_stderr else '') if result.returncode==0 else None
    except (OSError,subprocess.SubprocessError):return None


def endpoint_status(host,port,address,*,timeout=3,context=None):
    result={}
    try:
        with socket.create_connection((address,port),timeout) as connection:
            with (context or ssl.create_default_context()).wrap_socket(connection,server_hostname=host) as tls:
                result['tls']='verified'
                result['version']=tls.version()
    except Exception as error:
        result['tls']=error_code(error)
        return result
    settings={'https':True,'host':host,'port':port,'connect_host':address,
              'origin':'https://'+host+(':'+str(port) if port!=443 else ''),'release':''}
    try:
        probe(settings,local=True,context=context,timeout=timeout)
        result['application']='ready'
    except Exception as error:result['application']=error_code(error)
    return result


def published_ports(container):
    result=[]
    for target,bindings in container.get('NetworkSettings',{}).get('Ports',{}).items():
        if target not in ('80/tcp','443/tcp','443/udp'):continue
        for binding in bindings or []:
            try:
                address=str(ipaddress.ip_address(binding['HostIp']))
                port=int(binding['HostPort'])
                if not 1<=port<=65535:continue
                result.append({'target':target,'address':address,'port':port})
            except (ValueError,KeyError,TypeError):continue
    return result


def certificate_events(raw):
    # Never print log messages or error strings: upstream errors can echo secrets.
    text=(raw or '').lower()
    events=[]
    signatures={
        'certificate_obtained':('certificate obtained successfully',),
        'certificate_error':('could not get certificate','certificate_error'),
        'acme_connection_failed':('connection refused','connection timed out','timeout during connect'),
        'acme_dns_failed':('nxdomain','no valid a records','no valid aaaa records','dns problem'),
        'acme_rate_limited':('ratelimited','rate limited','too many certificates'),
        'acme_challenge_failed':('challenge failed','unauthorized','invalid response from'),
        'tls_handshake_error':('tls handshake error','no certificate available'),
        'http_only':('http only','automatic https is completely disabled'),
    }
    for line in (raw or '').splitlines():
        try:
            entry=json.loads(line)
            if isinstance(entry,dict) and entry.get('level')=='error' and 'certificate' in str(entry.get('msg','')).lower():
                events.append('certificate_error')
                break
        except (TypeError,ValueError):pass
    for code,phrases in signatures.items():
        if code not in events and any(phrase in text for phrase in phrases):events.append(code)
    return events


def diagnose(env_file,compose_file,site,expected_ip=None,*,timeout=3):
    public=site_values(site)
    host=urlsplit(public['CORS_ORIGINS']).hostname
    report={'requested_site':public['CORS_ORIGINS'],'configuration':{},'gateway':{},'dns':{'source':'system_resolver','A':[],'AAAA':[]},'ready':False}
    env=dict(os.environ,RSVX7_SELFHOST_ENV=str(env_file))
    compose=['docker','compose','-p','rsvx7','--env-file',str(env_file),'-f',str(compose_file)]
    raw=command(compose+['config','--format','json'],env)
    try:
        config=json.loads(raw)['services']
        resolved=safe_site(config['gateway'].get('environment',{}).get('SITE_ADDRESS'))
        app=config['app'].get('environment',{})
        report['configuration']={'resolved_site':resolved,
            'app_origins':[safe_site(origin) for origin in str(app.get('CORS_ORIGINS','')).split(',')],
            'cookie_secure':str(app.get('COOKIE_SECURE','')).lower()=='true',
            'shell_override_names':[key for key in ('SITE_ADDRESS','HTTP_BIND','HTTP_PORT','HTTPS_PORT','RSVX7_RELEASE_ID') if key in os.environ]}
    except (TypeError,KeyError,ValueError):
        report['configuration']={'error':'compose_configuration_failed'}
    if not shutil.which('docker'):
        report['gateway']={'error':'docker_unavailable'}
        return report
    ids=command(compose+['ps','--all','--quiet','gateway'],env)
    identifier=(ids or '').splitlines()
    container_id=identifier[0] if len(identifier)==1 and re.fullmatch(r'[A-Za-z0-9_.-]+',identifier[0]) else 'rsvx7-gateway-1'
    raw=command(['docker','inspect',container_id])
    try:
        container=json.loads(raw)[0]
        running_env=dict(value.split('=',1) for value in container.get('Config',{}).get('Env',[]) if '=' in value)
        running=safe_site(running_env.get('SITE_ADDRESS'))
        state=container.get('State',{}).get('Status','unknown')
        report['gateway']={'state':state if state in ('created','restarting','running','removing','paused','exited','dead') else 'unknown',
            'running_site':running,'site_matches_resolved':running==report['configuration'].get('resolved_site'),
            'published_ports':published_ports(container),
            'certificate_events':certificate_events(command(['docker','logs','--tail','100',container_id],include_stderr=True))}
    except (TypeError,ValueError,KeyError,IndexError):report['gateway']={'error':'gateway_inspect_failed'}
    # Test the requested domain with SNI even when Caddy is configured for :80.
    ports=report['gateway'].get('published_ports',[])
    binding=next((item for item in ports if item['target']=='443/tcp'),None)
    local_host={'0.0.0.0':'127.0.0.1','::':'::1'}.get(binding['address'],binding['address']) if binding else '127.0.0.1'
    local_port=binding['port'] if binding else 443
    report['local_https']={'address':local_host,'port':local_port,**endpoint_status(host,local_port,local_host,timeout=timeout)}
    try:
        addresses=public_addresses(host,443)
        for address in addresses:
            family='AAAA' if ipaddress.ip_address(address).version==6 else 'A'
            report['dns'][family].append(address)
        if expected_ip:report['dns']['expected_ip_present']=expected_ip in addresses
        report['public_https']=[{'address':address,'port':443,**endpoint_status(host,443,address,timeout=timeout)} for address in addresses]
    except Exception as error:
        report['dns']['error']=error_code(error)
        report['public_https']=[]
    report['ready']=(report['gateway'].get('state')=='running' and report['gateway'].get('site_matches_resolved',False)
        and report['local_https'].get('application')=='ready' and bool(report['public_https'])
        and all(item.get('application')=='ready' for item in report['public_https'])
        and report['dns'].get('expected_ip_present',True))
    return report


def main():
    root=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--env-file',default=str(root/'.env.selfhost'))
    parser.add_argument('--compose-file',default=str(root/'deploy/compose.selfhost.yaml'))
    parser.add_argument('--site',required=True)
    parser.add_argument('--expected-ip')
    args=parser.parse_args()
    try:
        if urlsplit(args.site).scheme!='https':raise ValueError()
        if args.expected_ip:ipaddress.ip_address(args.expected_ip)
        report=diagnose(Path(args.env_file).resolve(),Path(args.compose_file).resolve(),args.site,args.expected_ip)
    except Exception:
        print(json.dumps({'error':'https_diagnostic_failed','ready':False}))
        return 1
    print(json.dumps(report,indent=2,sort_keys=True))
    return 0 if report['ready'] else 1


if __name__=='__main__':raise SystemExit(main())
