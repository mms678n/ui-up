#!/usr/bin/env python3
"""Apply only the tested backend text-to-tool compatibility changes; preserve UI, .env, DB and TLS."""
import argparse, ast, base64, datetime, hashlib, json, os, shutil, subprocess, tempfile, zlib
from pathlib import Path
PAYLOAD = 'c-qZ8+m7VMb?@^PrCtLhw|l7R*_+f-3tFsKkpgLVvAZ@L%noQyvwDUeHreK7E}o1LDUsqR4~Buf`6&?$S&nU4F!JDhNzZG(B<E5^7H>V5b%4n5PP15b>eM->&aF;yb8}PpZ|?cCLm3BeW->jJsk=Pg7!HSGucQ6__r>Pj@x9UZeKEwpckYV!-`^1UUpN<;jN~krfj5gn8RsI*#FHeJ6YhZjrGA)6@!`vt&mN!5<T4MF*v@i4FEVeI1af+B>&{37GWWx1I#~U2_3g#yt8c{W>x+N7_~PR8i(jn%wEDeR{rAO}tM3Fn|1<pfYW2<P*W%*Ki(jt3TmAmxU$FfP8nXJ$>f6=V&<YTKv-%4?d<$<@zgztmzHh*F2M!~;08An=h2`XV81H9018N!UZfvTBrt+t5o+MEw{5TL6{j@}!z>;HO>v8VB%xx<xmdhkXsx1A~U&vghndOKi6+64mghBR^=I++kNLViqWJy{^?#*SI9EE{QMUcphCiVkhQH~%G8!_{v2yk%43mPbVYTlgrOMfqtYKe$^D(9)p4n&w|BJ+=6h7x_t*%%^b^E6q|aNyBm>BAxyxFYcqnjTS0xEDrYemde_2z(@-KYsS`qvzhU=TAR*_R{<C@x$*wfBN(jhBz}v0i{t&_|1Wzc?9Gj%<?3~mwtR|FWfW%w5L-hwuR(dxQr95G!t`dK<XoF7Bb8HeVHlzfnj#VG3eNw#34$QxR(rc#2YYS4458CYr?=3z^=}ST@m|7AiPLqbHpVKCXUr;0$V2tGXxVba)7GhS_jJ+MZt3DRMR%;+~QcBE<3xUQnbC<K@!enUD{;?lMQ0v)_{AWNJo*3yowd0`l{Fe=e;}#<HHwAzy<cjsM>PYEQxb@l6#Si_wxg5*I1QiFD$6GKzEr+KuFpR{^Ng5)zln%occ@k&TjP8TERad`Hv)W4giGIwNw$c*FX=@oY`R4DU~A$CUoLA$YA7QLqE1AS%k4&ZyYrssTppGXQ|wrN8$cKF6fQeFZ?tR|ML(3CS;a}3qO|v^u}VD!`ic43;_^nc45r8R|KH7T!sn5JT+ok!tgY8)%*svTk3IAZos<6Y{`0q493L6H8by=4Nxr%CSs7CX1QE|R1QdR;v5=(k|nVl6pJPF%w5_%9zNRgWEK^H^iYteFVjLgq(5@4KL}CS3ou8KO3%+`VL1K32jO?lHAl64rgGtjF~~qmBI*(hq98WSg>8!Md-qG}XoGuKj4v^qcgJ8X2V}%PU;P1%+v-2j)_ryHkE`FZf&4;Td;uLk1^Wgs{tV{w>x<8tb`MSBZ(;CPq7LWxV1B=Z2LkyEaq$_9`js}DpRc~V`1Im4w5FBeyo&U;R;mWG<aq^%B#gvAEKjQ4ltcBv!qxv?+!os)<=uveiEfG^DK`VUW(}f3rksV%Dee3KOuI}yKY(ST<dr{A)KVWT3qC0OKX43glF9WLbF^^Bewd43&&8=ScOJ%p2cl`84ZJV_LB{4C`n`KT5@!Pve{au^{CI}aKR$OV*mXLd-M)>#0FUM%6jr;22yB6~bBC8&?@jK?mUCXsatmw;^ay_j2!o}X&tbMbnIB8gJK8zP-Vu@XNx#IXXxK<8-W*6jNRwpYRvu83lZauBn`3u;&jF6!zgsExu0i#-+PLd!+J;gGC80@T8)V*TPzy9i4FgAUhuJ(kkh4QDm9gi~0bpQ4Y77LF0Rwy7L_`COlKp*<%`l!PHoN8z-Wojs&-|_X@JBo5r3v)s(gP*A#Ki*GEf;(bT=m!mJu;6HKSy_fx;T#07~J8-8ZI&mO;@LZa&_zA64GEkdf8{^l?3$IkFHl&vLnsukW(;runY6v#3ZyK8z_|?lVRB#GpjB%e`8oL=nfaFZ;Fnt<y0N-NM!Dh$0#!Q$8UFt4B29r<FQTz!z_#;e!~p`E`QBDIqd<+GINB23=v;A%bmIy=>EDBOBe=;1M;*70H&DF!x_40+TCiqp1mMQfp@_mRawS5UKk(w5oq3y<&eS9%FdH%nxwXD^lLnxhB6Aod=U7#KM`k!hjL~S0Ba)X?|HZP@hW~54>mSyQF|bdWR#F4T88c5z4aQo{`P~>cuNfN&z+L%X>yEvTJKeq{}^^Lk_zY(=8;^$-^@l$<?L9rdopX+*l$W5lqO9j4rWD~B89cKuo0}`oc9HoWsqg~{_q6gTj7^MXIzHsFPE@*plTQZNpU`ivy#1^fMXBOjJt(R$1$j@y;E#Vv!jy-)@Y+URB1*e6TRAYtkMet)p%0m%R)<=38gcFKwz8Qz?8P-P!=KSJcN;hxIzlz-02C}+7l4*-)Ka+ees@(o4sx*(<-nYG2)&|SrA)QH|^J?GB46toEaR9Aauu}xRc-+nGWs={I9+_K=l=2%7W|WCwXIYv|i)p*uFoyBZlzrecBqg#ETan0-Lf7*peZ2^8?%zx!eaQ58`v!VW7Y>ah#-w+0vg$2%m`1;bAhJ-gCjwZir*KmnAT1o=vCY`_MAn7~T>;MBRdcnOqbR0i*1VpY9iglkoR_)R#DAn8Hl62m;(d{OyaUPecZ;#KO<qjUnn0ewt42y4&~M@j5a@fX6yI(0e4r_$?s85dH;Sp_RlfaTNOcrx2Sn(GR2Qm5P3b_<5cJQMT{9V<by8$xsikmRGf<5?oFh&p=`}#NI4DUFNuU@MW%#CuzhxxK`GSueDZCwXq*|@}yeZdWuv-H?yUjg<zq4)CowXEr9fP9hN~J5rvBoMeLsY7E0YsC^3GpMQnfYf6RA-gVX7jd*{J5xZg{m4G@fdc|wG`4}{u&`=&%-*?)WMwTY02hosA4#mgYuT%MN5jc+FHS(F@uEk~k_-5aiNdrVB;-Zmoz9JxFVd@%O2cFX20Nu}AGA0+W+kjzec@GJ>%x`gLV&||<V<kCjF2^VwMy=yLp(A>U@-s$$;@#yUuny)W^ZH>Hn#qHU_v$g09uZB+QqYB%0@7-kMqPj;{@6EV~qK0xeJS*-0ZH>VD8;|b1Mc&_VFc`c92WB%*HaWPeCr2UBV7nww<gDP(IEG*!?42?~VlH#|L0M!84zmjoH-_ZbdEUIp(UJAETj$3Ryr}I8R#3H~*q0AUR{jK;(?2sg15Y4RfI)^}LiOrJh>p_}aBj!~BV6h<_aWF=hPqoVLQ!3+{ib_;KlSH1?9r|9wldI3+Uo2|4W~kaUOYzsU3EA1gYNWP?t|-+o|Y(<5yUK#eq1bd$61tQ(ktJ>80jyXW4Kih@l^8D1MfEXN5X@bfG~Ph)S@Y;QqVl8FTFad-f#nA{Pfx5C*Xfu?~=1z1(WYt8^cE*KYj6-UcTA!_LGM{@*aKo@c9eqvF&YbZQ=hnhCSK2DP>28_`g7Q9=BAv<qp61YG-ey<Es2i?UC{e-N<{v!kH3+E8`>Edj8^vKYHN3eERfb?-8K>@Fn@NX(25KcI2^4?J7}dZQ;u~hHw;f%;$gvMUOR4nwJY6UY3d4Da{8-3Tz;`vg<LnS_6{EgHSchJr9pB=6FbeoHrMV?JhS{PQa%PXC!zKXSW1%Z)<xb&g#y+HDll0>WGk=fq<pN3A<yy7>{VbSp5#qZyU$CU$6cQ?cc8c0>A!UtiGay+HV9O(ysn+@vp0|T|ppLzq|M)jQsTCSF1l^Qu@oX_v+V}ul^2R{8m)3aj01R$Lf!(?>L7I-Ty*oz&dAs@e7#Z8`nf010pSVUJ-{sEu_bBhaKi}QA%Davm(klgEiCv^PxN)37|(oVKeow9~?pl&MD#G&J)63)>}cbjL^}M9;zV^K$(Yq3~~orG3P@#)C8H|8*7Ub)EAhH$!+RhuIv&#V$6l2m?%WzVzDPv%cR?p)|;74yHkU%+8cx;`+~7mbr@;NF6(Cw{M~sGlhfc<ySnOntJJW#1LcuSkpO83zcTo>NFdq*QY1wRG21)B4}y^MXVEFNBb!w(6QtJT0Af!9x>ES+G#1qx5DeloSi^xIgT)Ckj1@tV;vcnO#MW3&4yGAXEjBM~B(|Jg^VqhaBg(C+>G&XwB#&zd4RH>OCYJdDW@NF8yG)jLBd%wl!>JgzlB)dbJ+TcMc?)UJz}^%0?@rp${Uztv+LUI<D|NJZVmYlzjYObc0%id_CM@^W42Te*kk9~^c9-2XqQ2K`>wCaI)V$vdPGbnmXU`>S;6^%<ppSrnDZfJPO>Hi8Nb~GC%nxkqmen`mm1&cSg?}oN7zD0>-r&Faks)DLPeO({s}frpTjtbIjGe|P8FkVa(<WUDVBp{bb^|9K)X8tm2Yamnvde>V`Q(FXpakCl!tRu?4JT>@TX|Nbn0KLP=gJioAF)khtx{?UMSoyDxj|LcNnJDT)Rhb-4^g9bt*P9<snR*qO8Gc7?OTC2&Af+hH;TsJ;90#|9{A25CP3+Bl4ao@Z~Hj#BS2T={yr!ztaAua-$<-^$#UrjBAILV9JJ0)i-eL%0G(a&PA{S59iV8z@R52-lfCL`j>3uF9c&~#AQ>t8Rj}t$2Fm-uiB0H7A+Ln8%Z6Tkiksl$4+PAcfl7rL^JE4r0}U$Qfk#!K@aXx+AB<q7ct(TE%dlVs<gthkGefN|ahsx%z-3b(+j<q7`w7K3j01TxqRyP!E*5xND{UIylrg{z2s!0Z;$0ERSalSeO;t)DLBrytsDF4YJ9<`20iu4v5goe`-S{vrWak)@HyvXYskNfO8Ct3#lU*vnkN{i-j%@deP}Zik&Ta$(A1-Z6yvkptUFwT#1C<Q*sL$Df4;%hC4A_j7-Fvk=QFo0lrt>q{#!&>G%k0302bs<MC2D#<#q(h6%z}Rbd7GxCrqTHhEo1jKFmXi7U8nF%!s+c%S1K)yd>KZ!_3T%eyIV@ua9B|V;hHuLW4g<YTE9C;!2kqBbj;*|l7zSvw_u+kQ*z9^11+tMk0e;IJrNrdJEFqP$Ur+@@daqDh;G?GKD#qI|NEcgzmBGJFRJTgmZ(!;I7PkO{WK|Bj@R0yqdEZybfk&DuOe^j7u=Faguk=3J1XaL*2rfQJ3n9#>c{9l{h0p!IsNl<>t;M@s3%j8IO}y%-6|<dMCYO{HQA>c8UWCYwUYpr`;#P$ZH1^)vv5(79kfg*pJCV3=d^*jss7bGbf#{&0_X)iR-34D1js=8x<XH~uo6glg27;z!+UTF_R-L&(GZiw5T?Kw3{x;bS>pq6&2EOyHI^YvQGbzfq-p{6SUE4$(DEB<QC&OsLzWm_RGkJJM$<2<!DM_iT@^l9x2f87Q!BwisnMY9Nk@&kl?sPzK0gEF0)#pwE@P&jdj%FasfR558TmnqxwsqP|67gGbRf(XnA3)vXFFH)nyTrBtR1LBEuBzxc~6uXwri#p$`k3ti~Mw7S{+lAhqk2H%lN29^5(QG=M8GOwBE)-3?k!F@$DKEG~pZbkrT3%rFX*cv~%Kg`%-#LhvCuhy7XMBD;g+Nc<MrR#9jev*<9rs5=s9`B*zp_O=#=X7`0Gd$0Y{mbg0OdQY3@l(u{q;NsT(!T507*8#99*Q~J0o;n^!V^%<0$C^2c5oUJ4HmEEIK0Xd!IH>09%s{FseOJ$F-1SHForFBh3lY{qx>C3>Yxs0_WrhnYnzpd@7wl4H+ZzwETQtvRNq&IXd;an3{h&7eT?Z>s9_P}BkK%dIGqQnm}8!*{H&CNdcCjMl6z#rqJvWKC3<{c!-;k2G^CL5Q@GD$l%GqxR>lOJMQ<{F8Ub*m?{OxfM;Y>8rmVM=lB%8()(GMQ5o-Jv<NsNm2#zabu7)aOdbDbajK!LLiJY3J!?N@s>q!`Y!9yX%&ypimA?i`rPc%eI+bI`}l+e(Q$oL>L}rW4mmy;m=^1D)};Y-8}-=iag>nwoq8TC&t&60i!n6I|`GCa@bbKl^VTYxi25Q>EszWM!KZj!aSPgG#FEJ^;mdF(buJ|JZdrZ5v3$C`wjsLEpyUo;v4*Hh$uEG5heV<K$gW<EpfdrE1OD{%Mh#Lt|{TY!!v_I;HPT--OCol04Zawi#64mW792HqQVR#^M{?^n3i00Zm`xOK8%y&m^7s2T!w79uKrB_WfPVlyhV}a-k#Q!&B@!EnNxXqd>MEq1B?n>1HX3ZEwC+$l4CFSV^xdW6I~i<WJ(<C24nrrbR4ViGKKwGbO{nL61hjI4sTt$yV_QbT3J%19wo-O+`{GC4F~eX9&bB%%6+<|Q{8HlugzCf{U&;sl@+;_tWVnPIX`c^p5`HD6*t!?Gr3x%TSbr~&L?BqYVObQLTGhMiA#E0L79TIHc;)E?RueeGZ<_k$|%&ZMTOkzhxcL{i!xnleRYxvRbJ^c)(yRom{jj_o!b)?y-eE*N+B&~>gtW%s2sp5cdD;YcbRLqJoFjC<W<}VW$2<bN-xGasC?+sEZ3lq)ZvKCm@lq)LPx_OL*YW*j@DfQea4G-qLu0K(=<GiFswNz>_gC}pkE=f@Y7THogL$J$7z_$su}4HYA*$46`i^uw0J3_kXf$9goAML^vTD6NA<<?1oaK(lA1GWX9$z!!0b2?3qL&!KoN5mG9zZENucP9j7Zg?G@>zSLL5@)OZo5tUmBV0oDFb?4km-gKYIA+CD*w;dHBiW!DvwK&%xwua41iq6CDT+&d+zxQE!lg+nfTJ`mofysJ(&6T*k~Q9Ba;Ep!$N)Oo#?$xwEcx7C!(rNC&6oE5*&0C?G$XcNs8G3h=2?m=(*l$x&rHSxRAshxa*U&SnRGyf0aJw6L`&_<q6%#L4nh36Ek+R$XT(5deN9;xs8zB_3{@1wbFZ22Sb%cm!>RaWWl1V5sF6dD66c0K^r~v;tzkb}50Ppa}woh-V!wj}h0=Wzz`WM{`l#Ybt|r6nfI(fzaB0gbNg({NTmQO0<!rNC+l3ubqlK@PMvG(%MupB_4JC2E*fR>VhQcnki;~TNTu3XK1d@TQ$|tRyECt7Rk3_MrFN<_CC3Y1Q(<gX4A(`BB^W%6?E``9Shsh;p1m^k5w-&PwO}?EI)t%MlYlgkn<QOjOuPzXLh~}b#}XpEVMVR(KNvA_9Xi?_e)>4H1@miFzt4@9ej&jJVn><wb$DXw%dU#FLgB?IF7X|(1r_r)gZdVBfCaGeZ8s#{_I4EWgqqH9{sM`Yq`~zWA<SmMy0A&TDtE{kEEpXB$b!fWOl>jt2{lY`wU!i#geTL)ODN61v-`Ks@<exk)1G7-8bpF%@iNe*1j|{>BnqZpH=14P;HQ>Tkal@{OZ=G!sgu`*V%NFxt6tiIJ)CnaZEH~=jWHGIa57hrW!BwS?fas(pVFv&^o4c8hJu?n&|s7RF$~3tF<1HmOs~Eb*8VWubyES`ES^1BkR>Z<5ozAc-uU;L9R=@^@KIt4X|q?4ecX0z7Ya`vid-Xfrg)*#xv>-u@gppw{IUFgPgbOO4Ka1$mInUbJt*xgc{z$uTk-C`^yk3LZ=`sc%#bJ<1O{V;({IL^6#^N1C&pj;H#U7S^FI=b;^J6>UdQLN;Nuk+%v^fva%kXo@jrnBSy~UtA_%OY3-<y%GW_w+h`Ftr#OQFUKheo%NF%*BA${BA(w&Is<c|*$sft4JG=ZP2tdoce9ekzr#Xs{ovIpqUYM%HpYjuCe|e4cuhU!k%@WZc(e9;TurFJ}(hOI1H})b`UwYsHK-g|b&BImyxCD}9GEff?>CopcRQZcKm2Ve_d7h75`>M|jF!b!DMQl6Wr%Af625;;;#H@P)M!I$IufEIBb=|_&%kD_Wmgt%SQ9D`EJzReu*All2w)8dWT4!E?(_R`8q`9(^gJ}J2gQ<<Ox3U<PZ%dT7Zb`!NvEvH?EiaNGQ+Y8}<kA*3IaL1`4tM9P&H6sGd4Q7Se&j7FSAxH0)h{0+zMx(Ljf()yCh@}<SV50bn!Vk3V8^`fJ-ThMp^PV{=7wqJRW|!SMO3a-wOjPLAG*WRreB>P>f0kF?M4+k?VM^S0QywWwUdV62Xh^%`u<DPwIjbdRbLI$l_|DK9y1H3DP|_aRGX1!Gg_-uS7TnCyK3;FnbK;W=))%Us4!EjTotsneQDCUBzF93)>*dKC4%I4AoV&&bO$Y3gBTx0D3!2_rq(q~tK0M%I=*N@>VWI9!M2tuHkhKn<gauJa0u*m{?>%rzn4Y~&x;tuUMjhHroTO??w)}V(H$#HgE8Em7=g{_w1o_{TP<bMSVGJAt}p%6lh82KZuCVRy=T;9^$)33a)G*wp4{3n=UOwizvZxI)>&=V*3dOG^S4bhgRY%R_Ef+1bgl_L;-g`z(YP#nT`g&g5*9skQ)llW%$xnU`r=4-xH_any(x*vUlm#xB&!iOE*;h9tr`#nChwGvs5<Rb*D5=67?|>%Htu8^1SRjV3`f+mddO0`u?Vnnsgpsii^~ma>S+xde+7ch(;7oq#alJc_R{@Z`rNis&s6zKL`qU)fz%_VxA5nUsnX_-b6q|4D2eA0_(TYF+0a=!ue+v1nNsEJW>n@z$H<M6wk~PF#5~??Fb-%s%i;RDPr)#P=taBiy9W1L;v>eR0t_n2kKi#l<=bE~&>uQM(?$8(^|ZLLglfD^7?U=6Ywy>9;x8<zxU&j3FB^I}!`G)I>z7>Eb-EI7Rj#qmO#^d}T`rkf`y|lwswg%y%nf4bj`aO3f?j@IZS4d#@>AGf)lv5q*r$`qW1FY#erS0--aquy6t!v}aZO?8-IMyLNuP|=yR895O6#hWSuZy|GNWg4uEM0rwW<EvLbq1nLS30zU4W-*K`<HW3t5%j^X6fc<K5w&$*$sn@_hw73{46=B;q8y@o`5yAC;YMX+LxD7J=q&<*YF}lE3iK<5A#8naO|B9OWuiWyU(nQeKA{m+pKMp{98Ul<?Yf2k2|2L^@)f%fqf^>DA-UW>W1sk#^TSGb6k!=b5dUM}gPZKS~4CbjftmVyM2NInrxz-YL@<&3Civ9Xr=m2X1Ip-|9Td=2U+IR6}ZCc4>)e=a$r|lPN^B>|H6HtBZM6x?a!xp4jS<xi$w-wkZ9yaH=n{x4Z3L6<+%Y!0y*Y)~ooLzBf8c(v&|aG$H3@naZOuDX5HNiC>|m>-oTd>RLW%CoyCq>aSxAh2^x4r)yKzKZqj(S3IMF3t6h4YQnOR0}+xZ{w!D5k~PwFimNIddM0&xH+N6`(yOR+Y^2q~q}$#a>Z>a6?>C7(lG3(I*xBj$06{-CH5i<}-#N4BIxd~z&}H7+xAD!ndB0a5W>@!n%UPUGmC<p!P>Z0aYUhtcD?C@PW>@_7eP>|aK2<RT?Ww6gnkuPAqWZZ)Z#Q+`Vg`aWPOx_DG+HWy`oEb*cC`'
FILES = ['backend/server.py', 'backend/developer_api.py', 'backend/requirements.txt', 'backend/requirements.lock', 'backend/tool_compat.py']

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',default='.')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    root=Path(args.project).expanduser().resolve()
    if not (root/'deploy/compose.selfhost.yaml').is_file():
        raise SystemExit('Run inside RSVX7-AI or pass --project /absolute/path')
    patch=zlib.decompress(base64.b85decode(PAYLOAD))
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    parent=root/'.rsvx7-backups'
    parent.mkdir(exist_ok=True,mode=0o700)
    backup=parent/('tool-compat-'+stamp)
    backup.mkdir(mode=0o700)
    stage=backup/'stage';stage.mkdir(mode=0o700)
    originals={}
    for rel in FILES:
        source=root/rel
        if source.is_symlink():raise SystemExit('Refusing symlink: '+rel)
        originals[rel]=source.read_bytes() if source.exists() else None
        if source.exists():
            dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    def apply(*flags):
        return subprocess.run(['git','apply',*flags,'-'],input=patch,cwd=stage,capture_output=True)
    check=apply('--check')
    if check.returncode:
        if apply('--reverse','--check').returncode==0:
            shutil.rmtree(backup);print('Tool compatibility update is already applied.');return
        print(check.stderr.decode(errors='replace'))
        raise SystemExit('Source differs from the tested baseline. No project files changed. Diagnostics: '+str(backup))
    result=apply()
    if result.returncode:raise SystemExit('Staging patch failed; project unchanged: '+str(backup))
    for rel in FILES:
        if rel.endswith(".py"): ast.parse((stage/rel).read_text(), filename=rel)
    if args.check:
        shutil.rmtree(backup);print('Patch and Python syntax verified; no project files changed.');return
    old=backup/'original';old.mkdir(mode=0o700)
    for rel,data in originals.items():
        if data is not None:
            target=old/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,target)
    manifest={'project':str(root),'files':{rel:hashlib.sha256(data).hexdigest() if data is not None else None for rel,data in originals.items()}}
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2))
    changed=[]
    try:
        for rel in FILES:
            target=root/rel
            if (target.read_bytes() if target.exists() else None)!=originals[rel]:
                raise RuntimeError('Source changed during update: '+rel)
            staged=stage/rel
            if originals[rel] is not None:os.chmod(staged,(old/rel).stat().st_mode & 0o777)
            os.replace(staged,target);changed.append(rel)
    except BaseException:
        for rel in reversed(changed):
            target=root/rel
            if originals[rel] is None:target.unlink()
            else:shutil.copy2(old/rel,target)
        raise
    shutil.rmtree(stage)
    print('Backend sources updated. Backup: '+str(backup))
    print('Rebuild the app container to activate; no environment, volumes, gateway or UI changed.')

if __name__=='__main__':main()
