#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
python "$ROOT/scripts/manage_database.py" migrate
exec python "$ROOT/scripts/run_services.py"
