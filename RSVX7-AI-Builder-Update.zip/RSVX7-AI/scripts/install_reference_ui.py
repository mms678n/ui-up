#!/usr/bin/env python3
"""Install the reference chat frontend without replacing server settings."""
import argparse, hashlib, json, os, shutil, tempfile
from datetime import datetime, timezone
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', required=True, type=Path)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    source, target = Path(__file__).resolve().parents[1], args.target.expanduser().resolve()
    if source == target: raise SystemExit('Extract the update to a separate temporary folder first.')
    if not (target/'deploy/compose.selfhost.yaml').is_file() or not (target/'backend/server.py').is_file(): raise SystemExit('Target is not the existing RSVX7-AI project.')
    files = json.loads((source/'REFERENCE-UI-MANIFEST.json').read_text())['files']
    for name, digest in files.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts or relative.parts[0]!='frontend': raise SystemExit('Invalid frontend update path.')
        if hashlib.sha256((source/name).read_bytes()).hexdigest()!=digest: raise SystemExit('Update verification failed: '+name)
        if not (target/name).resolve().is_relative_to(target): raise SystemExit('Target contains a symlink outside the project: '+name)
    source_files=[name for name in files if not name.startswith('frontend/build/')]
    build_files={name.removeprefix('frontend/build/') for name in files if name.startswith('frontend/build/')}
    actual={p.relative_to(source/'frontend/build').as_posix() for p in (source/'frontend/build').rglob('*') if p.is_file()}
    if not build_files or actual!=build_files: raise SystemExit('Build is missing or contains unverified files.')
    if args.check: print(f'Verified {len(files)} frontend files. Target: {target}');return
    backup=target/'.rsvx7-backups'/('reference-ui-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
    backup.mkdir(parents=True,mode=0o700);existed=[]
    for name in source_files:
        p=target/name
        if p.exists():
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,saved);existed.append(name)
    state={'target':str(target),'source_files':source_files,'existed':existed,'had_build':(target/'frontend/build').exists()}
    (backup/'restore.json').write_text(json.dumps(state,indent=2))
    stage=Path(tempfile.mkdtemp(prefix='.reference-ui-stage-',dir=target));moved=installed=False
    try:
        shutil.copytree(source/'frontend/build',stage/'build')
        for name in source_files:
            dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True);temporary=stage/'source-file';shutil.copy2(source/name,temporary);os.replace(temporary,dst)
        if state['had_build']:
            (backup/'frontend').mkdir(parents=True,exist_ok=True);os.replace(target/'frontend/build',backup/'frontend/build');moved=True
        os.replace(stage/'build',target/'frontend/build');installed=True
    except BaseException:
        for name in source_files:
            if name in existed: shutil.copy2(backup/name,target/name)
            else: (target/name).unlink(missing_ok=True)
        if installed: shutil.rmtree(target/'frontend/build')
        if moved: os.replace(backup/'frontend/build',target/'frontend/build')
        raise
    finally: shutil.rmtree(stage,ignore_errors=True)
    print('Reference chat frontend installed. Backend and environment files were not changed.')
    print('Backup: '+str(backup));print('Rebuild/restart the app container to publish this frontend.')
if __name__=='__main__': main()
