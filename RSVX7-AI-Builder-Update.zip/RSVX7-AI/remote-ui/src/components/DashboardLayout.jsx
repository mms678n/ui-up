import { useEffect, useState, useCallback } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Server, TerminalSquare, FolderTree, Activity,
  Boxes, ScrollText, LogOut, Terminal, ChevronDown, Circle, MonitorSmartphone, Download, Menu, ArrowLeft, RefreshCw,
} from "lucide-react";
import { api } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  DropdownMenuLabel, DropdownMenuSeparator,
} from "./ui/dropdown-menu";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";

const NAV = [
  { to: "/app", icon: LayoutDashboard, label: "Dashboard", end: true },
  { to: "/app/servers", icon: Server, label: "Servers" },
  { to: "/app/devices", icon: MonitorSmartphone, label: "Devices" },
  { to: "/app/agent-downloads", icon: Download, label: "Agent Downloads" },
  { to: "/app/workspace", icon: TerminalSquare, label: "Workspace" },
  { to: "/app/files", icon: FolderTree, label: "Files" },
  { to: "/app/monitor", icon: Activity, label: "Monitor" },
  { to: "/app/docker", icon: Boxes, label: "Docker" },
  { to: "/app/logs", icon: ScrollText, label: "Logs" },
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const { pathname } = useLocation();
  const [navigationOpen, setNavigationOpen] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [servers, setServers] = useState([]);
  const [activeServerId, setActiveServerId] = useState(localStorage.getItem("rgpt_active_server") || null);

  const refreshServers = useCallback(async () => {
    const { data } = await api.get("/servers");
    setLoadError(false);
    setServers(data);
    if (data.length && !data.find((s) => s.id === localStorage.getItem("rgpt_active_server"))) {
      selectServer(data[0].id);
    }
    return data;
  }, []);

  const selectServer = (id) => {
    setActiveServerId(id);
    if (id) localStorage.setItem("rgpt_active_server", id);
  };

  useEffect(() => { refreshServers().catch(() => setLoadError(true)); }, [refreshServers]);
  useEffect(() => { setNavigationOpen(false); }, [pathname]);

  const activeServer = servers.find((s) => s.id === activeServerId) || null;

  return (
    <div className="remote-shell min-h-screen text-white flex">
      <a href="#remote-main" className="remote-skip-link">Skip to workspace</a>
      {/* Sidebar */}
      <aside className="remote-sidebar hidden md:flex w-60 shrink-0 border-r border-white/8 bg-black flex flex-col fixed inset-y-0 z-40">
        <SidebarContent user={user} logout={logout} />
      </aside>

      {/* Main */}
      <div className="flex-1 md:ml-60 flex flex-col min-w-0">
        <header className="remote-topbar min-h-16 border-b border-white/8 glass-strong sticky top-0 z-30 flex items-center justify-between gap-3 px-4 md:px-6 py-2.5">
          <button onClick={() => setNavigationOpen(true)} aria-label="Open navigation" aria-expanded={navigationOpen} className="remote-icon-button md:hidden shrink-0" data-testid="mobile-nav-open"><Menu className="w-5 h-5" /></button>
          <ServerSelector servers={servers} activeServer={activeServer} onSelect={selectServer} />
          <div className="text-xs text-white/40 font-mono hidden sm:block">
            {servers.length} server{servers.length !== 1 ? "s" : ""} · {servers.filter((s) => s.status === "online").length} online
          </div>
        </header>
        <Dialog open={navigationOpen} onOpenChange={setNavigationOpen}>
          <DialogContent className="remote-navigation-drawer" aria-describedby="remote-navigation-description">
            <DialogHeader className="sr-only"><DialogTitle>Workspace navigation</DialogTitle><DialogDescription id="remote-navigation-description">Open a workspace section or manage your account.</DialogDescription></DialogHeader>
            <SidebarContent user={user} logout={logout} onNavigate={() => setNavigationOpen(false)} />
          </DialogContent>
        </Dialog>
        <main id="remote-main" tabIndex={-1} className="flex-1 min-w-0 outline-none">
          <div className="remote-breadcrumb px-4 md:px-6 border-b border-white/10"><a href="/#chat" target="_top" className="inline-flex min-h-11 items-center gap-2 text-sm text-gold"><ArrowLeft className="w-4 h-4" aria-hidden="true" /> العودة إلى rsvx7</a><span className="text-xs text-white/50">{NAV.find(n => n.end ? pathname === n.to : pathname.startsWith(n.to))?.label || "Device details"}</span></div>
          {loadError && <div role="alert" className="mx-4 mt-4 rounded-xl border border-red-400/25 bg-red-500/10 px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-sm"><span>Could not load your servers. Check your connection and try again.</span><button className="inline-flex items-center gap-2 min-h-11 text-gold" onClick={() => refreshServers().catch(() => setLoadError(true))}><RefreshCw className="w-4 h-4" />Retry</button></div>}<Outlet context={{ servers, activeServer, selectServer, refreshServers, setServers }} />
        </main>
      </div>
    </div>
  );
}

function SidebarContent({ user, logout, onNavigate }) {
  return <>        <div className="h-16 shrink-0 flex items-center px-5 border-b border-white/8">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center mr-2"><Terminal className="w-5 h-5 text-black" /></div>
          <span className="font-display font-semibold tracking-tight">Hacker rsvx7 Ai</span>
        </div>
        <nav aria-label="Workspace" className="flex-1 p-3 space-y-1 overflow-y-auto">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} onClick={onNavigate} data-testid={`nav-${n.label.toLowerCase()}`}
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${isActive ? "bg-white/8 text-white border border-white/10" : "text-white/50 hover:text-white hover:bg-white/5 border border-transparent"}`}>
              <n.icon className="w-[18px] h-[18px] shrink-0" aria-hidden="true" /> {n.label}
            </NavLink>
          ))}
          
        </nav>
        <div className="p-3 border-t border-white/8">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 transition-colors" data-testid="user-menu">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent-ai to-indigo-500 flex items-center justify-center text-black text-sm font-semibold">{user?.username?.[0]?.toUpperCase()}</div>
                <div className="flex-1 min-w-0 text-left"><div className="text-sm font-medium truncate">{user?.username}</div><div className="text-xs text-white/40">{user?.plan}</div></div>
                <ChevronDown className="w-4 h-4 text-white/40" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52 bg-[#0A0A0B] border-white/10">
              <DropdownMenuLabel className="text-white/40 text-xs">Signed in as {user?.username}</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem onClick={() => { void logout(); }} className="text-red-400 focus:text-red-400 focus:bg-red-500/10" data-testid="logout-btn">
                <LogOut className="w-4 h-4 mr-2" /> Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
</>;
}

function ServerSelector({ servers, activeServer, onSelect }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex min-w-0 max-w-full min-h-11 items-center gap-2 px-3 py-2 rounded-xl glass hover:border-white/20 transition-all" data-testid="active-server-selector">
          {activeServer ? (
            <>
              <Circle className={`w-2.5 h-2.5 ${activeServer.status === "online" ? "fill-[#22C55E] text-[#22C55E] pulse-dot" : "fill-white/30 text-white/30"}`} />
              <span className="text-sm font-medium truncate max-w-[12rem]">{activeServer.nickname}</span>
              <span className="text-xs text-white/40 font-mono truncate max-w-[12rem] hidden lg:inline">{activeServer.host}</span>
            </>
          ) : (
            <span className="text-sm text-white/50">No server selected</span>
          )}
          <ChevronDown className="w-4 h-4 text-white/40" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-80 max-w-[calc(100vw-2rem)] bg-[#0A0A0B] border-white/10">
        <DropdownMenuLabel className="text-white/40 text-xs">Active server</DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-white/10" />
        {servers.length === 0 && <div className="px-2 py-3 text-sm text-white/40">No servers yet</div>}
        {servers.map((s) => (
          <DropdownMenuItem key={s.id} onClick={() => onSelect(s.id)} className="focus:bg-white/10" data-testid={`select-server-${s.id}`}>
            <Circle className={`w-2 h-2 mr-2 ${s.status === "online" ? "fill-[#22C55E] text-[#22C55E]" : "fill-white/30 text-white/30"}`} />
            <span className="flex-1 min-w-0 truncate">{s.nickname}</span>
            <span className="text-xs text-white/40 font-mono max-w-32 truncate">{s.host}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
