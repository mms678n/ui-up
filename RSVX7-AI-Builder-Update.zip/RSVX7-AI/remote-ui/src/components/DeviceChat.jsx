import AutonomousChat from "./AutonomousChat";

export default function DeviceChat({ device, terminalRef }) {
  return <AutonomousChat targetType="device" targetId={device.id} targetName={device.name}
    online={device.status === "online"} terminalRef={terminalRef} />;
}
