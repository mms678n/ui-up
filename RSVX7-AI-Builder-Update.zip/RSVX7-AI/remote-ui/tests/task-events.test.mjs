import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const source = await readFile(new URL('../src/lib/task-events.js', import.meta.url), 'utf8');
const {newTask, reduceTask, taskFromMessage, consumeSSE} = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));

test('keeps separate command outputs and exit codes across repairs', () => {
  let turn = newTask('نزلي برنامج');
  turn = reduceTask(turn, {type:'task_started', task_id:'one'});
  turn = reduceTask(turn, {type:'command', task_id:'one', step_id:1, command:'install', stage:'execute'});
  turn = reduceTask(turn, {type:'output', step_id:1, data:'failed dependency'});
  turn = reduceTask(turn, {type:'exit', step_id:1, exit_code:1});
  turn = reduceTask(turn, {type:'command', step_id:2, command:'fix', stage:'repair'});
  turn = reduceTask(turn, {type:'output', step_id:2, data:'fixed'});
  turn = reduceTask(turn, {type:'exit', step_id:2, exit_code:0});
  assert.equal(turn.language, 'ar');
  assert.equal(turn.steps[0].output, 'failed dependency');
  assert.equal(turn.steps[0].exit_code, 1);
  assert.equal(turn.steps[1].output, 'fixed');
  assert.equal(turn.steps[1].status, 'success');
  assert.equal(reduceTask(turn, {type:'output', task_id:'old', step_id:2, data:'WRONG'}), turn);
});

test('a blocked result and cancellation never turn into success', () => {
  let turn = reduceTask(newTask(), {type:'error', message:'offline'});
  turn = reduceTask(turn, {type:'done'});
  assert.equal(turn.status, 'blocked');
  assert.equal(turn.verified, false);
  let cancel = reduceTask(newTask(), {type:'command', step_id:1, command:'slow'});
  cancel = reduceTask(cancel, {type:'done', status:'cancelled'});
  assert.equal(cancel.steps[0].status, 'cancelled');
});

test('history restoration renders the saved task without generating commands', () => {
  const turn = taskFromMessage({role:'assistant', content:'old text', task:{status:'success', verified:true,
    summary:'Done', steps:[{step_id:1, command:'already executed', output:'actual output', status:'success'}]}});
  assert.equal(turn.phase, 'success');
  assert.equal(turn.answer, 'Done');
  assert.equal(turn.steps[0].output, 'actual output');
});

test('SSE parser handles split UTF-8, CRLF, keepalive and trailing frames', async () => {
  const encoder = new TextEncoder();
  const data = encoder.encode(': keepalive\r\n\r\ndata: {"type":"delta","content":"تم"}\r\n\r\ndata: {"type":"done"}');
  const body = new ReadableStream({start(controller) {for(let i=0;i<data.length;i+=3) controller.enqueue(data.slice(i,i+3)); controller.close();}});
  const events=[];
  await consumeSSE(body, event=>events.push(event));
  assert.deepEqual(events,[{type:'delta',content:'تم'},{type:'done'}]);
});
