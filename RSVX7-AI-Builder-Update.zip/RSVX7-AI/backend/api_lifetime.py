"""HTTP API owns its generation, unlike reconnectable web chat."""
import asyncio
from contextlib import suppress
import anyio
from fastapi import HTTPException
from starlette.responses import JSONResponse, Response
from stream_buffer import cancel_stream

async def close_generation(source):
    with anyio.CancelScope(shield=True):
        state = getattr(source, '_rsvx7_stream_state', None)
        if state is not None:
            if not state.get('finalizing'):
                cancel_stream(state)
            with suppress(asyncio.CancelledError):
                await asyncio.shield(state['task'])
        await source.body_iterator.aclose()

class APIResponse(Response):
    def __init__(self, source, *, stream=None, collect=None):
        super().__init__()
        self.source, self.stream, self.collect = source, stream, collect

    async def __call__(self, scope, receive, send):
        try:
            if self.stream is not None:
                await self.stream(scope, receive, send)
            else:
                async with anyio.create_task_group() as group:
                    async def disconnect():
                        while True:
                            if (await receive())['type'] == 'http.disconnect':
                                group.cancel_scope.cancel()
                                return
                    group.start_soon(disconnect)
                    try:
                        response = JSONResponse(await self.collect())
                    except HTTPException as error:
                        response = JSONResponse({'detail': error.detail},
                            status_code=error.status_code, headers=error.headers)
                    await response(scope, receive, send)
                    group.cancel_scope.cancel()
        finally:
            await close_generation(self.source)
