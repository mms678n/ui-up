"""Unbuffered application SSE with bounded backpressure and cancellation cleanup."""
import asyncio
import anyio
from contextlib import suppress


async def with_heartbeats(source, interval: float = 12.0, capacity: int = 8):
    # One producer task owns the generator's cancellation scopes for its lifetime.
    # Creating a new anext task for each event would break AnyIO scope ownership.
    queue = asyncio.Queue(maxsize=capacity)

    async def pump():
        try:
            async for event in source:
                await queue.put(("event", event))
        except asyncio.CancelledError:
            raise
        except Exception as error:
            await queue.put(("error", error))
        else:
            await queue.put(("end", None))
        finally:
            await source.aclose()

    producer = asyncio.create_task(pump(), name="rsvx7-sse-producer")
    try:
        while True:
            try:
                kind, value = await asyncio.wait_for(queue.get(), timeout=interval)
            except asyncio.TimeoutError:
                if producer.done() and queue.empty():
                    producer.result()
                    break
                yield ": keep-alive\n\n"
                continue
            if kind == "end":
                break
            if kind == "error":
                raise value
            yield value
    finally:
        if not producer.done():
            producer.cancel()
        # ASGI uses level-triggered AnyIO cancellation. Awaiting the task
        # unshielded would cancel it again while it releases the Mongo lease.
        with anyio.CancelScope(shield=True):
            with suppress(asyncio.CancelledError):
                await asyncio.shield(producer)
