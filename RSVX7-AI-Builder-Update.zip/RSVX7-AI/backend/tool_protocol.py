"""Validated tool wire protocol. Tools execute in the calling client, never here."""
import json
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from fastapi import HTTPException

class FunctionCall(BaseModel):
    model_config=ConfigDict(extra='forbid')
    name: str=Field(min_length=1,max_length=64,pattern=r'^[A-Za-z0-9_-]+$')
    arguments: str=Field(max_length=2000000)

class ToolCall(BaseModel):
    model_config=ConfigDict(extra='forbid')
    id: str=Field(min_length=1,max_length=256)
    type: Literal['function']='function'
    function: FunctionCall

class FunctionDefinition(BaseModel):
    model_config=ConfigDict(extra='forbid')
    name: str=Field(min_length=1,max_length=64,pattern=r'^[A-Za-z0-9_-]+$')
    description: str | None=Field(default=None,max_length=60000)
    parameters: dict=Field(default_factory=lambda:{'type':'object','properties':{}})
    strict: bool | None=None

class ToolDefinition(BaseModel):
    model_config=ConfigDict(extra='forbid')
    type: Literal['function']='function'
    function: FunctionDefinition

class ToolMessage(BaseModel):
    model_config=ConfigDict(extra='forbid')
    role: Literal['user','assistant','tool','system','developer']
    content: str | None=Field(default=None,max_length=16000000)
    tool_calls: list[ToolCall] | None=Field(default=None,max_length=128)
    tool_call_id: str | None=Field(default=None,min_length=1,max_length=256)
    name: str | None=Field(default=None,max_length=64)
    reasoning_content: str | None=Field(default=None,max_length=16000000)

    @field_validator('content',mode='before')
    @classmethod
    def text_parts(cls,value):
        if isinstance(value,list):
            if any(not isinstance(p,dict) or p.get('type')!='text' or not isinstance(p.get('text'),str) for p in value):
                raise ValueError('Only text message content is supported')
            return ''.join(p['text'] for p in value)
        return value

    @model_validator(mode='after')
    def valid_shape(self):
        if self.role=='assistant':
            if not self.content and not self.tool_calls:raise ValueError('Assistant needs content or tool_calls')
        elif self.content is None or (not self.content and self.role!='tool'):
            raise ValueError('Message content is required')
        if self.tool_calls and self.role!='assistant':raise ValueError('Only assistant messages may contain tool_calls')
        if (self.role=='tool') != bool(self.tool_call_id):raise ValueError('tool_call_id is required only for tool messages')
        if self.reasoning_content is not None and self.role!='assistant':raise ValueError('Reasoning belongs to assistant messages')
        return self


def validate_tools(messages,tools,choice):
    names=[t.function.name for t in (tools or [])]
    if len(names)!=len(set(names)):raise HTTPException(400,'Duplicate tool names')
    if choice is not None:
        if isinstance(choice,str):
            if choice not in ('auto','none','required'):raise HTTPException(400,'Invalid tool_choice')
            if choice!='none' and not tools:raise HTTPException(400,'tool_choice requires tools')
        elif not (isinstance(choice,dict) and choice.get('type')=='function' and isinstance(choice.get('function'),dict) and choice['function'].get('name') in names):
            raise HTTPException(400,'Unknown tool_choice function')
    pending=set()
    for message in messages:
        if message.role=='tool':
            if message.tool_call_id not in pending:raise HTTPException(400,'Orphan or duplicate tool result')
            pending.remove(message.tool_call_id)
        else:
            if pending:raise HTTPException(400,'Missing tool results before next message')
            if message.tool_calls:
                ids=[t.id for t in message.tool_calls]
                if len(ids)!=len(set(ids)):raise HTTPException(400,'Duplicate tool call IDs')
                pending.update(ids)
    if pending:raise HTTPException(400,'Tool results are required before requesting the next completion')

class ToolAccumulator:
    def __init__(self,tools):
        self.calls={};self.names={t.function.name for t in (tools or [])};self.size=0
    def push(self,deltas):
        result=[]
        for delta in deltas:
            item=delta.model_dump(exclude_none=True) if hasattr(delta,'model_dump') else dict(delta)
            index=item.get('index')
            if type(index) is not int or not 0<=index<128:raise ValueError('Invalid tool index')
            call=self.calls.setdefault(index,{'id':'','type':'function','function':{'name':'','arguments':''}})
            if item.get('type','function')!='function':raise ValueError('Invalid tool type')
            for field in ('id',):
                value=item.get(field,'');call[field]+=value;self.size+=len(value)
            function=item.get('function') or {}
            for field in ('name','arguments'):
                value=function.get(field,'');call['function'][field]+=value;self.size+=len(value)
            if self.size>2000000:raise ValueError('Tool output too large')
            result.append(item)
        return result
    def finish(self,reason):
        if reason=='tool_calls' and not self.calls:raise ValueError('Missing tool calls')
        if self.calls and reason not in ('tool_calls','length'):raise ValueError('Invalid tool finish reason')
        if reason=='tool_calls':
            ids=[]
            for call in self.calls.values():
                parsed=ToolCall.model_validate(call)
                if parsed.function.name not in self.names:raise ValueError('Provider called an unknown tool')
                if not isinstance(json.loads(parsed.function.arguments),dict):raise ValueError('Tool arguments must be a JSON object')
                ids.append(parsed.id)
            if len(ids)!=len(set(ids)):raise ValueError('Duplicate provider tool IDs')
    def values(self):return [self.calls[i] for i in sorted(self.calls)]
