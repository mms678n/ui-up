"""Private attachments on durable storage with publicly addressable asset keys.

Only ciphertext is uploaded. Per-file keys live in server-only SQL metadata;
all file API representations must exclude payload_encryption. No environment
key or container filesystem is needed to survive a restart.
"""
from __future__ import annotations

import base64
import secrets

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import HTTPException

AAD = b"RSVX7-private-attachment-v1"
ALGORITHM = "AES-256-GCM"
TAG_BYTES = 16


def encrypt_payload(data: bytes) -> tuple[bytes, dict[str, str]]:
    key = AESGCM.generate_key(bit_length=256)
    nonce = secrets.token_bytes(12)
    encrypted = AESGCM(key).encrypt(nonce, data, AAD)
    return encrypted, {
        "algorithm": ALGORITHM,
        "key_b64": base64.b64encode(key).decode("ascii"),
        "nonce_b64": base64.b64encode(nonce).decode("ascii"),
    }


def decrypt_payload(data: bytes, metadata: dict) -> bytes:
    try:
        if not isinstance(metadata, dict) or metadata.get("algorithm") != ALGORITHM:
            raise ValueError("Unsupported envelope")
        key = base64.b64decode(metadata["key_b64"], validate=True)
        nonce = base64.b64decode(metadata["nonce_b64"], validate=True)
        if len(key) != 32 or len(nonce) != 12:
            raise ValueError("Invalid envelope")
        return AESGCM(key).decrypt(nonce, data, AAD)
    except Exception:
        # Avoid including any key, nonce, URL, plaintext or provider error.
        raise HTTPException(502, "Stored attachment could not be verified") from None
