"""Application persistence selection, lifecycle and domain transactions.

Managed Manus runs use MySQL only. Mongo remains an explicitly selected,
separate self-host/test profile; it is never an automatic production fallback.
"""
from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import Mapping

_database = None
_client = None


def selected_backend(environ: Mapping[str, str] | None = None) -> str:
    env = os.environ if environ is None else environ
    choice = env.get("RSVX7_DATA_BACKEND", "auto").strip().lower()
    if choice not in {"auto", "mysql", "mongo"}:
        raise RuntimeError("RSVX7_DATA_BACKEND must be mysql, mongo or auto")
    if choice != "auto":
        return choice
    if env.get("DATABASE_URL") or env.get("RSVX7_RUNTIME_ENV", "development").lower() == "production":
        return "mysql"
    return "mongo"


def get_database():
    global _database, _client
    if _database is not None:
        return _database
    backend = selected_backend()
    if backend == "mysql":
        url = os.environ.get("DATABASE_URL")
        if not url:
            raise RuntimeError("Managed persistence requires server-only DATABASE_URL")
        from mysql_repository import MySQLDatabase
        allow_test = os.environ.get("RSVX7_SQL_TEST_ALLOW_PLAINTEXT") == "1"
        if allow_test:
            from urllib.parse import urlsplit
            parsed = urlsplit(url)
            if parsed.hostname not in {"127.0.0.1", "localhost", "::1"} or not parsed.path.lstrip("/").startswith("rsvx7_test_"):
                raise RuntimeError("Plaintext is limited to explicitly isolated localhost test databases")
        _database = MySQLDatabase(url, allow_local_plaintext=allow_test)
        _client = _database
    else:
        from motor.motor_asyncio import AsyncIOMotorClient
        url = os.environ.get("MONGO_URL")
        name = os.environ.get("DB_NAME")
        if not url or not name:
            raise RuntimeError("Explicit local Mongo profile requires MONGO_URL and DB_NAME")
        _client = AsyncIOMotorClient(url)
        _database = _client[name]
    return _database


def get_client():
    get_database()
    return _client


def uses_mysql(database=None) -> bool:
    database = get_database() if database is None else database
    # Check the type, not a Mongo attribute lookup: Motor synthesizes arbitrary
    # collection names and would make a generic hasattr test a false positive.
    return getattr(type(database), "backend_name", None) == "mysql"


async def initialize_database():
    database = get_database()
    if uses_mysql(database):
        await database.initialize()


async def verify_database():
    database = get_database()
    if uses_mysql(database):
        await database.verify_schema()
    else:
        await get_client().admin.command("ping")


async def ping_database():
    database = get_database()
    if uses_mysql(database):
        await database.ping()
    else:
        await get_client().admin.command("ping")


async def close_database():
    database = get_database()
    if uses_mysql(database):
        await database.close()
    else:
        get_client().close()


@asynccontextmanager
async def database_transaction(database, *, collections=()):
    """Cross-repository SQL transaction; retain the explicit legacy CAS path."""
    if uses_mysql(database):
        async with database.transaction(collections=tuple(sorted(set(collections)))):
            yield
    else:
        yield
