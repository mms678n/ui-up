"""Integrated remote systems workspace."""
