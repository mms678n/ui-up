"""Loopback-only vertical Builder tests: real Node, HTTP, SDK and SSE decoding."""
import asyncio
import copy
import json
import os
from pathlib import Path
import socket
import subprocess
from unittest.mock import AsyncMock

import httpx
import pytest
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI

from tests.test_builder import setup, run, builder, ai_settings, auth, SETTINGS, SOURCE

ROOT = Path(__file__).resolve().parents[1]
PLAN = {'kind': 'proposal', 'title': 'Greeting', 'summary': 'A greeting page',
    'pages': [{'name': 'Home', 'purpose': 'Show greeting'}], 'features': ['Arabic heading'],
    'design': 'Readable RTL', 'steps': ['Implement'], 'acceptanceChecks': ['Show أهلاً']}
CONTENT = '<!doctype html><html lang="ar" dir="rtl"><h1>أهلاً</h1><!--' + 'compact source ' * 36 + '--></html>'


@pytest.fixture(scope='module')
def real_engine(tmp_path_factory):
    output = tmp_path_factory.mktemp('builder-engine') / 'service.mjs'
    script = """const {createRequire}=require('node:module');
const path=require('node:path'),root=process.argv[1],out=process.argv[2];
const local=createRequire(path.join(root,'frontend/package.json'));
local('esbuild').buildSync({entryPoints:[path.join(root,'builder/service.ts')],outfile:out,
 bundle:true,platform:'node',format:'esm',target:'es2022',
 alias:{'~':path.join(root,'builder/vendor/darkforge/app')},
 nodePaths:[path.join(root,'frontend/node_modules')],define:{'import.meta.env':'{}'}});"""
    subprocess.run(['node', '-e', script, str(ROOT), str(output)], check=True, capture_output=True)
    return output


def listener():
    value = socket.socket()
    value.bind(('127.0.0.1', 0))
    value.listen()
    return value


async def until(predicate, timeout=10):
    async def waiting():
        while not predicate(): await asyncio.sleep(.01)
    await asyncio.wait_for(waiting(), timeout)


async def vertical(db, monkeypatch, compiled, cancel=False):
    api_socket, engine_socket = listener(), listener()
    api_port, engine_port = api_socket.getsockname()[1], engine_socket.getsockname()[1]
    engine_socket.close()
    origin = f'http://127.0.0.1:{api_port}'
    engine_origin = f'http://127.0.0.1:{engine_port}'
    settings = {**SETTINGS, 'context_length': 8192, 'max_completion_tokens': 256}
    monkeypatch.setattr(builder, 'current_settings', AsyncMock(return_value=settings))
    monkeypatch.setattr(builder, 'ENGINE_URL', engine_origin)
    sdk = AsyncOpenAI(api_key='local-fixture-only', base_url=origin + '/v1', max_retries=0,
        http_client=httpx.AsyncClient(trust_env=False), timeout=5)
    monkeypatch.setattr(ai_settings, 'client', sdk)
    monkeypatch.setattr(ai_settings, 'request_client', lambda fallback: fallback)
    app = FastAPI()
    app.include_router(builder.router)
    calls, completed, stages = [], [], []
    writing_started, provider_closed = asyncio.Event(), asyncio.Event()

    @app.post('/v1/chat/completions')
    async def provider(request: Request):
        body = await request.json()
        calls.append(body)
        system = body['messages'][0]['content']
        if 'CURRENT BATCH (data):\n' in system:
            batch = json.loads(system.split('CURRENT BATCH (data):\n')[1].split('\nPROJECT CONTEXT')[0])
            stage = batch['stage']
        else: stage = 'planning'
        stages.append(stage)
        if stage == 'planning': text, finish = json.dumps(PLAN, ensure_ascii=False), 'stop'
        elif stage == 'structure': text, finish = '{"files":["index.html"]}', 'stop'
        elif stage == 'reviewing': text, finish = '{"actions":[],"remainingFiles":[]}', 'stop'
        else:
            assert batch['requiredFiles'] == ['index.html']
            whole = json.dumps({'actions': [{'type': 'file', 'filePath': 'index.html', 'content': CONTENT}],
                'remainingFiles': []}, ensure_ascii=False, separators=(',', ':'))
            prefix = next((m['content'] for m in reversed(body['messages'])
                if m['role'] == 'assistant' and whole.startswith(m['content'])), '')
            offset, segment = len(prefix), (len(whole) + 3) // 4
            text = whole[offset:offset + segment]
            finish = 'stop' if offset + segment >= len(whole) else 'length'

        async def stream():
            try:
                # Network fragments deliberately split JSON tokens and UTF-8 characters.
                for offset in range(0, len(text), 23):
                    frame = {'id': 'local', 'object': 'chat.completion.chunk', 'created': 0, 'model': settings['model'],
                        'choices': [{'index': 0, 'delta': {'content': text[offset:offset + 23]}, 'finish_reason': None}]}
                    raw = ('data: ' + json.dumps(frame, ensure_ascii=False) + '\n\n').encode()
                    for byte in range(0, len(raw), 17):
                        yield raw[byte:byte + 17]
                        await asyncio.sleep(0)
                    if cancel and stage == 'writing':
                        writing_started.set()
                        await asyncio.Event().wait()
                final = {'id': 'local', 'object': 'chat.completion.chunk', 'created': 0, 'model': settings['model'],
                    'choices': [{'index': 0, 'delta': {}, 'finish_reason': finish}]}
                usage = {**final, 'choices': [], 'usage': {'prompt_tokens': 100, 'completion_tokens': 20, 'total_tokens': 120}}
                yield ('data: ' + json.dumps(final) + '\n\n').encode()
                yield ('data: ' + json.dumps(usage) + '\n\ndata: [DONE]\n\n').encode()
                completed.append(stage)
            finally:
                if cancel and stage == 'writing': provider_closed.set()
        return StreamingResponse(stream(), media_type='text/event-stream')

    serving = uvicorn.Server(uvicorn.Config(app, log_level='error', lifespan='off', timeout_graceful_shutdown=1))
    serving_task = asyncio.create_task(serving.serve(sockets=[api_socket]))
    engine = await asyncio.create_subprocess_exec('node', str(compiled), env={**os.environ,
        'BUILDER_ENGINE_SECRET': builder.engine_secret(), 'BUILDER_ENGINE_PORT': str(engine_port),
        'BUILDER_API_ORIGIN': origin}, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
    headers = {'Authorization': 'Bearer ' + auth.make_token('alice', 'user')}
    try:
        await until(lambda: serving.started)
        async with httpx.AsyncClient(base_url=origin, headers=headers, timeout=10, trust_env=False) as client:
            for _ in range(100):
                try:
                    health = await client.get(engine_origin + '/health', headers={'Authorization': 'Bearer ' + builder.engine_secret()})
                    if health.status_code == 200: break
                except httpx.HTTPError: pass
                await asyncio.sleep(.02)
            else: raise AssertionError('Real Node engine did not become ready')

            if cancel:
                db.projects.rows['p_owned']['builder'] = {**builder._empty(), 'files': copy.deepcopy(SOURCE), 'approvedPlan': PLAN}
                body = {'requestId': 'vertical-cancel', 'revision': 0, 'text': 'Update the Arabic greeting'}
            else:
                response = await client.post('/api/builder/projects/p_owned/run', json={
                    'requestId': 'vertical-plan', 'revision': 0, 'text': 'Build an Arabic greeting'})
                assert response.status_code == 202, response.text
                await until(lambda: db.projects.rows['p_owned']['builder']['job']['status'] != 'running')
                planned = (await client.get('/api/builder/projects/p_owned')).json()
                assert planned['job']['status'] == 'completed', planned['job']
                assert planned['plan']['kind'] == 'proposal' and planned['files'] == {}
                body = {'requestId': 'vertical-approved', 'revision': 0, 'action': 'approve', 'proposalId': planned['proposalId']}
            response = await client.post('/api/builder/projects/p_owned/run', json=body)
            assert response.status_code == 202, response.text
            if cancel:
                await asyncio.wait_for(writing_started.wait(), 10)
                assert db.projects.rows['p_owned']['builder']['files'] == SOURCE
                stopped = await client.post('/api/builder/projects/p_owned/cancel')
                assert stopped.status_code == 200
                await asyncio.wait_for(provider_closed.wait(), 5)
            else:
                await until(lambda: db.projects.rows['p_owned']['builder']['job']['status'] != 'running')
            saved = (await client.get('/api/builder/projects/p_owned')).json()
            assert saved['job']['status'] == ('cancelled' if cancel else 'completed'), saved['job']
            if cancel:
                assert saved['files'] == SOURCE and saved['revision'] == 0
                assert completed == ['structure']
            else:
                assert saved['files']['/home/project/index.html']['content'] == CONTENT
                assert saved['revision'] == 1 and saved['job']['pipeline'] == {'stage': 'reviewing', 'completed': 1, 'total': 1}
                assert saved['messages'][-1]['annotations'][0]['type'] == 'studioReviewedBuild'
                assert stages == ['planning', 'structure', 'writing', 'writing', 'writing', 'writing', 'reviewing']
            before = len(calls)
            repeated = await client.post('/api/builder/projects/p_owned/run', json=body)
            assert repeated.json()['job']['id'] == response.json()['job']['id']
            assert len(calls) == before
            assert len(db.token_usage_history.rows) == len(completed)
            assert db.users.rows['alice']['token_balance'] == 100000 - 180 * len(completed)
            assert all(0 < request['max_tokens'] <= 256 for request in calls)
            assert not db.ai_request_leases.rows
    finally:
        for task in list(builder._tasks.values()): task.cancel()
        await asyncio.gather(*list(builder._tasks.values()), return_exceptions=True)
        if engine.returncode is None:
            engine.terminate()
            await asyncio.wait_for(engine.wait(), 5)
        serving.should_exit = True
        await asyncio.wait_for(serving_task, 5)
        await sdk.close()


def test_http_run_uses_real_engine_sdk_sse_continuations_review_and_accounting(setup, monkeypatch, real_engine):
    run(vertical(setup, monkeypatch, real_engine))


def test_http_cancel_closes_real_provider_preserves_source_and_debits_only_completed_calls(setup, monkeypatch, real_engine):
    run(vertical(setup, monkeypatch, real_engine, cancel=True))
