"""Paid API key lifecycle and OpenAI-style response contracts."""
import asyncio
import copy
import json
from collections import defaultdict, deque
from unittest.mock import AsyncMock

import httpx
import pytest
from openai import AsyncOpenAI
from starlette.responses import StreamingResponse
from tests.test_builder import MemoryDB, USER
import auth, server, tokens
from tests.test_hf_chat_stream import sdk_chunk


@pytest.fixture
def env(monkeypatch):
    db = MemoryDB()
    monkeypatch.setattr(server, '_rate_hits', defaultdict(deque))
    db.users.rows['alice'] = copy.deepcopy(USER)
    db.users.rows['free'] = {'_id': 'free', 'role': 'user', 'username': 'free', 'token_balance': 10000}
    monkeypatch.setattr(auth, 'db', db)
    monkeypatch.setattr(server, 'db', db)
    import ai_settings
    monkeypatch.setattr(ai_settings, 'db', db)
    return db


def test_paid_key_lifecycle_and_downgrade_denial(env, monkeypatch):
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url='https://test.local') as c:
            alice = {'Authorization': 'Bearer ' + auth.make_token('alice', 'user')}
            free = {'Authorization': 'Bearer ' + auth.make_token('free', 'user')}
            assert (await c.post('/api/developer/key', headers=free)).status_code == 403
            created = await c.post('/api/developer/key', headers=alice)
            assert created.status_code == 200
            key = created.json()['key']
            assert key.startswith('rsvx7_') and key not in json.dumps(env.users.rows)
            assert 'api_access' not in (await c.get('/api/auth/me', headers=alice)).json()
            assert (await c.get('/api/v1/models', headers={'Authorization': 'Bearer ' + key})).status_code == 200
            env.users.rows['alice']['monthly']['plan'] = 'free'
            assert (await c.get('/api/v1/models', headers={'Authorization': 'Bearer ' + key})).status_code == 403
            env.users.rows['alice']['monthly']['plan'] = 'max'
            assert (await c.delete('/api/developer/key', headers=alice)).status_code == 200
            assert (await c.get('/api/v1/models', headers={'Authorization': 'Bearer ' + key})).status_code == 401
    asyncio.run(scenario())


def test_key_changes_reject_foreign_browser_origins(env):
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://test.local') as c:
            session={'Authorization':'Bearer '+auth.make_token('alice','user'),'Origin':'https://attacker.test'}
            assert (await c.post('/api/developer/key',headers=session)).status_code == 403
            assert (await c.delete('/api/developer/key',headers=session)).status_code == 403
            session['Origin']='http://[invalid'
            assert (await c.post('/api/developer/key',headers=session)).status_code == 403
    asyncio.run(scenario())


def test_admin_user_lists_never_expose_key_hashes(env, monkeypatch):
    from types import SimpleNamespace
    from sql_document_ops import apply_projection
    async def rows(projection):
        return [apply_projection(copy.deepcopy(row), projection) for row in env.users.rows.values()]
    monkeypatch.setattr(env.users, 'find', lambda query, projection: SimpleNamespace(to_list=lambda limit: rows(projection)), raising=False)
    async def scenario():
        env.users.rows['owner']={'_id':'owner','username':'owner','role':'super_admin'}
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://test.local') as c:
            session={'Authorization':'Bearer '+auth.make_token('alice','user')}
            assert (await c.post('/api/developer/key',headers=session)).status_code == 200
            admin={'Authorization':'Bearer '+auth.make_token('owner','super_admin')}
            result=await c.get('/api/admin/users',headers=admin)
            assert result.status_code == 200
            assert 'api_access' not in json.dumps(result.json())
    asyncio.run(scenario())


def test_rotation_expiry_model_restrictions_and_suspension(env):
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://test.local') as c:
            session={'Authorization':'Bearer '+auth.make_token('alice','user')}
            old=(await c.post('/api/developer/key',headers=session)).json()['key']
            new=(await c.post('/api/developer/key',headers=session)).json()['key']
            assert (await c.get('/api/v1/models',headers={'Authorization':'Bearer '+old})).status_code == 401
            headers={'Authorization':'Bearer '+new}
            env.users.rows['alice']['monthly']['plan']='pro'
            models=(await c.get('/api/v1/models',headers=headers)).json()['data']
            assert {x['id'] for x in models} == {'kaligpt','deepdark'}
            denied=await c.post('/api/v1/chat/completions',headers=headers,json={'model':'rsvx7-ai','messages':[{'role':'user','content':'hello'}]})
            assert denied.status_code == 403
            env.users.rows['alice']['status']='suspended'
            assert (await c.get('/api/v1/models',headers=headers)).status_code == 403
            env.users.rows['alice']['status']='active'
            env.users.rows['alice']['monthly']['ends_at']='2020-01-01T00:00:00+00:00'
            assert (await c.get('/api/v1/models',headers=headers)).status_code == 403
    asyncio.run(scenario())


def test_generation_error_is_not_a_successful_completion(env,monkeypatch):
    async def fake_chat(req,user):
        async def frames():
            yield 'data: {"error":{"code":"provider_unavailable"}}\n\n'
            yield 'data: [DONE]\n\n'
        return StreamingResponse(frames())
    monkeypatch.setattr(server,'chat_stream',AsyncMock(side_effect=fake_chat))
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://test.local') as c:
            session={'Authorization':'Bearer '+auth.make_token('alice','user')}
            key=(await c.post('/api/developer/key',headers=session)).json()['key']
            payload={'model':'kaligpt','messages':[{'role':'user','content':'hello'}]}
            headers={'Authorization':'Bearer '+key}
            assert (await c.post('/api/v1/chat/completions',headers=headers,json=payload)).status_code == 502
            streamed=await c.post('/api/v1/chat/completions',headers=headers,json={**payload,'stream':True})
            assert 'provider_unavailable' in streamed.text and 'finish_reason": "stop' not in streamed.text
    asyncio.run(scenario())


@pytest.mark.parametrize('stream', [False, True])
def test_completions_transform_existing_billed_stream(env, monkeypatch, stream):
    async def fake_chat(req, user):
        assert req.personality == 'kaligpt' and user['_id'] == 'alice'
        async def frames():
            for event in ({'t':'hello'}, {'usage': {'input': 3, 'output': 2, 'total': 5, 'prompt_tokens': 9}}, {'finish':'stop'}):
                yield 'data: ' + json.dumps(event) + '\n\n'
            yield 'data: [DONE]\n\n'
        return StreamingResponse(frames(), media_type='text/event-stream')
    monkeypatch.setattr(server, 'chat_stream', AsyncMock(side_effect=fake_chat))
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url='https://test.local') as c:
            session = {'Authorization': 'Bearer ' + auth.make_token('alice', 'user')}
            key = (await c.post('/api/developer/key', headers=session)).json()['key']
            result = await c.post('/api/v1/chat/completions', headers={'Authorization': 'Bearer ' + key},
                json={'model':'kaligpt','messages':[{'role':'user','content':'hello'}], 'stream':stream})
            assert result.status_code == 200
            if stream:
                assert 'chat.completion.chunk' in result.text and 'hello' in result.text and '[DONE]' in result.text
            else:
                body = result.json()
                assert body['choices'][0]['message']['content'] == 'hello'
                assert body['usage']['completion_tokens'] == 2
                assert body['usage']['prompt_tokens'] == 9
                assert body['usage']['total_tokens'] == 11
    asyncio.run(scenario())


def test_external_system_prompt_and_max_tokens_reach_existing_chat(env, monkeypatch):
    async def fake_chat(req, user):
        assert req.api_system == 'Be concise' and req.max_tokens == 123
        async def frames():
            yield 'data: {"t":"ok"}\n\n'
            yield 'data: {"finish":"stop"}\n\n'
            yield 'data: [DONE]\n\n'
        return StreamingResponse(frames())
    monkeypatch.setattr(server, 'chat_stream', AsyncMock(side_effect=fake_chat))
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url='https://test.local') as c:
            session={'Authorization': 'Bearer ' + auth.make_token('alice','user')}
            key=(await c.post('/api/developer/key',headers=session)).json()['key']
            res=await c.post('/api/v1/chat/completions',headers={'Authorization':'Bearer '+key},json={
                'model':'kaligpt','messages':[{'role':'system','content':'Be concise'},{'role':'user','content':'Hi'}], 'max_tokens':123})
            assert res.status_code == 200
    asyncio.run(scenario())


def test_openai_sdk_stream_gets_finish_then_usage(env, monkeypatch):
    async def fake_chat(req, user):
        async def frames():
            yield 'data: {"t":"ok"}\n\n'
            yield 'data: {"usage":{"input":1,"output":2,"total":3,"prompt_tokens":7}}\n\n'
            yield 'data: {"finish":"stop"}\n\n'
            yield 'data: [DONE]\n\n'
        return StreamingResponse(frames())
    monkeypatch.setattr(server, 'chat_stream', AsyncMock(side_effect=fake_chat))
    async def scenario():
        transport=httpx.ASGITransport(app=server.app)
        async with httpx.AsyncClient(transport=transport, base_url='https://test.local') as http:
            session={'Authorization': 'Bearer ' + auth.make_token('alice','user')}
            key=(await http.post('/api/developer/key',headers=session)).json()['key']
            sdk=AsyncOpenAI(api_key=key,base_url='https://test.local/api/v1',http_client=http)
            stream=await sdk.chat.completions.create(model='kaligpt', messages=[{'role':'user','content':'Hi'}],stream=True,stream_options={'include_usage':True})
            chunks=[chunk async for chunk in stream]
            assert chunks[-2].choices[0].finish_reason == 'stop'
            assert chunks[-1].usage.prompt_tokens == 7 and chunks[-1].choices == []
    asyncio.run(scenario())


def test_external_api_uses_real_chat_pipeline_and_wallet_once(env, monkeypatch):
    monkeypatch.setattr(tokens, 'db', env)
    monkeypatch.setattr(server, 'require_membership', AsyncMock())
    monkeypatch.setattr(server, 'claim_generation', AsyncMock(return_value='api-fixture-lease'))
    monkeypatch.setattr(server, 'release_generation', AsyncMock())
    monkeypatch.setattr(server, 'current_settings', AsyncMock(return_value={
        'model':'fixture/model', 'context_length':32000, 'max_completion_tokens':100,
        'supported_parameters':[], 'reasoning':None}))
    async def handler(request):
        chunks=[sdk_chunk({'content':'answer'},'stop'), sdk_chunk(usage={'prompt_tokens':23,'completion_tokens':4,'total_tokens':27})]
        return httpx.Response(200,headers={'content-type':'text/event-stream'},
                              content=''.join('data: '+json.dumps(x)+'\n\n' for x in chunks)+'data: [DONE]\n\n')
    provider=AsyncOpenAI(api_key='fixture',base_url='https://fixture.test/v1',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)),max_retries=0)
    monkeypatch.setattr(server, 'request_client', lambda _: provider)
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://test.local') as c:
            session={'Authorization':'Bearer '+auth.make_token('alice','user')}
            key=(await c.post('/api/developer/key',headers=session)).json()['key']
            before=env.users.rows['alice']['token_balance']
            result=await c.post('/api/v1/chat/completions',headers={'Authorization':'Bearer '+key},
                                json={'model':'kaligpt','messages':[{'role':'user','content':'hello'}]})
            assert result.status_code == 200, result.text
            assert result.json()['choices'][0]['message']['content'] == 'answer'
            assert result.json()['usage']['prompt_tokens'] == 23
            assert len(env.token_usage_history.rows)==1
            row=next(iter(env.token_usage_history.rows.values()))
            assert row['full_prompt_tokens']==23 and row['assistant_output_tokens']==4
            assert env.users.rows['alice']['token_balance']==before-row['billable_tokens']
        await provider.close()
    asyncio.run(scenario())
