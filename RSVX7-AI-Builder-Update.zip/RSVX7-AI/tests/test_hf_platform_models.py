"""HF-compatible SDK envelopes through Builder and Hacker using the native wallet."""
import asyncio
import json
from contextlib import asynccontextmanager
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from openai import AsyncOpenAI
from fastapi import HTTPException
from tests.test_builder import setup, builder, ai_settings, tokens
from tests.test_builder_streaming import context, read
from tests.test_hf_chat_stream import sdk_chunk
from remote_control import platform_model, ai_service

SETTINGS = {'model': 'fixture/coder:fastest', 'context_length': 32000,
            'max_completion_tokens': 512, 'supported_parameters': [], 'reasoning': None}
MESSAGES = [{'role': 'user', 'content': 'write code'}]
ANSWER = '```python\nprint(1)\n```'
PARTS = [{'type': 'text', 'text': '```python\n'}, {'type': 'image_url', 'image_url': 'private'},
         {'type': 'text', 'text': 'print(1)\n```'}]


@asynccontextmanager
async def provider(monkeypatch, payload, streaming=True):
    requests = []
    async def handle(request):
        requests.append(json.loads(request.content))
        if not streaming:
            return httpx.Response(200, json=payload)
        wire = ''.join('data: ' + json.dumps(c) + '\n\n' for c in payload) + 'data: [DONE]\n\n'
        return httpx.Response(200, headers={'content-type': 'text/event-stream'}, content=wire.encode())
    client = AsyncOpenAI(api_key='fixture-only', base_url='https://router.huggingface.co/v1',
                         http_client=httpx.AsyncClient(transport=httpx.MockTransport(handle)), max_retries=0)
    monkeypatch.setattr(ai_settings, 'request_client', lambda fallback: client)
    monkeypatch.setattr(ai_settings, 'current_settings', AsyncMock(return_value=SETTINGS.copy()))
    monkeypatch.setattr(builder, 'current_settings', AsyncMock(return_value=SETTINGS.copy()))
    try:
        yield requests
    finally:
        await client.close()


def wallet_assert(db, prompt, completion):
    assert len(db.token_usage_history.rows) == 1
    row = next(iter(db.token_usage_history.rows.values()))
    assert row['full_prompt_tokens'] == prompt
    assert row['assistant_output_tokens'] == completion
    assert db.users.rows['alice']['token_balance'] == 100000 - int(round((prompt + completion) * tokens.BILLING_MULTIPLIER))
    assert not db.ai_request_leases.rows


@pytest.mark.parametrize('usage', [{}, {'prompt_tokens': 23}, {'completion_tokens': 4},
                                    {'prompt_tokens': 23, 'completion_tokens': 4}])
def test_builder_sdk_content_arrays_and_partial_usage_preserve_deltas_and_wallet(setup, monkeypatch, usage):
    body, request, _, _ = context(setup, monkeypatch, [])
    async def scenario():
        chunks = [sdk_chunk({'role': 'assistant'}), sdk_chunk({}),
                  sdk_chunk({'reasoning_content': 'plan'}), sdk_chunk({'content': PARTS}, 'stop'),
                  sdk_chunk(usage=usage)]
        async with provider(monkeypatch, chunks) as calls:
            _, events = await read(await builder.model_call(body, request))
            assert ''.join(e.get('text', '') for e in events) == ANSWER
            assert events[-1] == {'type': 'result', 'finishReason': 'stop'}
            assert 'private' not in json.dumps(events)
            # A replayed worker call uses its existing stable debit key.
            await read(await builder.model_call(body, request))
            assert len(calls) == 2
            assert calls[0]['model'] == SETTINGS['model']
            assert calls[0]['stream_options'] == {'include_usage': True}
        wallet_assert(setup, usage.get('prompt_tokens', tokens.estimate_messages_tokens(body.messages)),
                      usage.get('completion_tokens', tokens.estimate_messages_tokens([{'role': 'assistant', 'content': 'plan' + ANSWER}])))
    asyncio.run(scenario())


@pytest.mark.parametrize('tail', [sdk_chunk({'content': PARTS}), sdk_chunk({'reasoning_content': 'late'})])
def test_builder_sdk_rejects_post_terminal_content_parts_or_reasoning_without_debit(setup, monkeypatch, tail):
    body, request, _, _ = context(setup, monkeypatch, [])
    async def scenario():
        async with provider(monkeypatch, [sdk_chunk({'content': 'answer'}, 'stop'), tail]):
            _, events = await read(await builder.model_call(body, request))
            assert events[-1]['type'] == 'error'
            assert not any(e['type'] == 'result' for e in events)
        assert not setup.token_usage_history.rows and not setup.ai_request_leases.rows
    asyncio.run(scenario())


def remote_context(db, monkeypatch):
    monkeypatch.setattr(platform_model, 'db', db)
    monkeypatch.setattr(platform_model, 'require_membership', AsyncMock())
    return platform_model.actor.set(db.users.rows['alice'])


@pytest.mark.parametrize('usage', [None, {}, {'prompt_tokens': 23}, {'completion_tokens': 4},
                                    {'prompt_tokens': 23, 'completion_tokens': 4}])
def test_remote_sdk_consumer_normalizes_content_parts_and_bills_reasoning_once(setup, monkeypatch, usage):
    async def scenario():
        marker = remote_context(setup, monkeypatch)
        chunks = [sdk_chunk({'role': 'assistant'}), sdk_chunk({'reasoning_content': 'plan'}),
                  sdk_chunk({'content': PARTS}, 'stop')]
        if usage is not None:
            chunks.append(sdk_chunk(usage=usage))
        try:
            async with provider(monkeypatch, chunks) as calls:
                output = [part async for part in ai_service.stream_chat(MESSAGES)]
                assert output == [ANSWER]
                assert len(calls) == 1
                prompt = tokens.estimate_messages_tokens(calls[0]['messages'])
            reported = usage or {}
            wallet_assert(setup, reported.get('prompt_tokens', prompt), reported.get('completion_tokens',
                          tokens.estimate_messages_tokens([{'role': 'assistant', 'content': 'plan' + ANSWER}])))
        finally:
            platform_model.actor.reset(marker)
    asyncio.run(scenario())


@pytest.mark.parametrize('usage', [None, {}, {'prompt_tokens': 23}, {'completion_tokens': 4}])
def test_remote_nonstream_sdk_normalizes_content_parts_and_partial_usage(setup, monkeypatch, usage):
    async def scenario():
        marker = remote_context(setup, monkeypatch)
        payload = {'id': 'fixture', 'object': 'chat.completion', 'created': 1, 'model': SETTINGS['model'],
                   'choices': [{'index': 0, 'finish_reason': 'stop', 'message': {
                       'role': 'assistant', 'content': PARTS, 'reasoning_content': 'plan'}}], 'usage': usage}
        try:
            async with provider(monkeypatch, payload, streaming=False):
                response = await platform_model.client.create(messages=MESSAGES)
                assert response.choices[0].message.content == ANSWER
            reported = usage or {}
            wallet_assert(setup, reported.get('prompt_tokens', tokens.estimate_messages_tokens(MESSAGES)),
                          reported.get('completion_tokens', tokens.estimate_messages_tokens([
                              {'role': 'assistant', 'content': 'plan' + ANSWER}])))
        finally:
            platform_model.actor.reset(marker)
    asyncio.run(scenario())


@pytest.mark.parametrize('tail', [None, sdk_chunk({'reasoning_content': 'late'})])
def test_remote_sdk_interruption_or_late_reasoning_never_debits(setup, monkeypatch, tail):
    async def scenario():
        marker = remote_context(setup, monkeypatch)
        chunks = [sdk_chunk({'content': 'partial'}, 'stop' if tail else None)]
        if tail:
            chunks.append(tail)
        try:
            async with provider(monkeypatch, chunks):
                with pytest.raises(RuntimeError):
                    async for _ in ai_service.stream_chat(MESSAGES):
                        pass
            assert not setup.token_usage_history.rows and not setup.ai_request_leases.rows
        finally:
            platform_model.actor.reset(marker)
    asyncio.run(scenario())


def test_remote_sdk_native_tool_calls_survive_content_normalization(setup, monkeypatch):
    async def scenario():
        marker = remote_context(setup, monkeypatch)
        monkeypatch.setenv('AI_EXECUTION_PROTOCOL', 'native')
        tool = {'id': 'call-fixture', 'type': 'function',
                'function': {'name': 'run_command', 'arguments': '{"command":"pwd"}'}}
        payload = {'id': 'fixture', 'object': 'chat.completion', 'created': 1, 'model': SETTINGS['model'],
                   'choices': [{'index': 0, 'finish_reason': 'tool_calls', 'message': {
                       'role': 'assistant', 'content': PARTS, 'tool_calls': [tool]}}],
                   'usage': {'prompt_tokens': 23, 'completion_tokens': 4}}
        try:
            async with provider(monkeypatch, payload, streaming=False):
                result = await ai_service.request_task_turn(MESSAGES, [])
                assert result['content'] == ANSWER
                assert result['tool_calls'] == [tool]
                assert result['execution_protocol'] == 'native'
            wallet_assert(setup, 23, 4)
        finally:
            platform_model.actor.reset(marker)
    asyncio.run(scenario())


def test_remote_normalization_copies_sdk_content_envelopes_and_preserves_tool_deltas():
    from openai.types.chat.chat_completion_chunk import ChatCompletionChunk, Choice, ChoiceDelta
    tool_delta = [{'index': 0, 'id': 'call-fixture', 'type': 'function',
                   'function': {'name': 'run_command', 'arguments': '{'}}]
    delta = ChoiceDelta.model_construct(content=PARTS, tool_calls=tool_delta, reasoning_content='plan')
    choice = Choice.model_construct(index=0, delta=delta, finish_reason=None)
    chunk = ChatCompletionChunk.model_construct(id='fixture', choices=[choice], created=1,
                                               object='chat.completion.chunk', model=SETTINGS['model'])
    normalized = platform_model.normalize_content_parts(chunk, 'delta')
    assert chunk.choices[0].delta.content == PARTS
    assert normalized is not chunk
    assert normalized.choices[0] is not choice
    assert normalized.choices[0].delta is not delta
    assert normalized.choices[0].delta.content == ANSWER
    assert normalized.choices[0].delta.tool_calls is delta.tool_calls
    assert normalized.choices[0].delta.reasoning_content == 'plan'


def test_builder_job_snapshot_cannot_change_next_jobs_current_model_limits(setup, monkeypatch):
    from tests.test_builder_streaming import frame
    body, request, _, _ = context(setup, monkeypatch, [frame('complete', finish='stop')])
    shared_settings = SETTINGS.copy()
    monkeypatch.setattr(builder, 'current_settings', AsyncMock(return_value=shared_settings))
    job = setup.projects.rows['p_owned']['builder']['job']
    job['modelSettings'] = {'context_length': 1}
    async def scenario():
        _, rejected = await read(await builder.model_call(body, request))
        assert rejected[-1]['type'] == 'error' and rejected[-1]['code'] == 'context'
        job.pop('modelSettings')
        _, next_job = await read(await builder.model_call(body, request))
        assert next_job[-1] == {'type': 'result', 'finishReason': 'stop'}
    asyncio.run(scenario())
