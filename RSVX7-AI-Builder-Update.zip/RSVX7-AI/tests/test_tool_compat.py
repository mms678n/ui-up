"""Real SDK + API fixtures for textual tool compatibility, never live credits."""
import asyncio
import copy
import importlib.util
import json
from unittest.mock import AsyncMock

import httpx
import pytest
from openai import AsyncOpenAI
from tests.test_developer_api import env
from tests.test_builder import auth, server, tokens
from tests.test_hf_chat_stream import sdk_chunk
from tests.test_tools_api import TOOL

OPEN = '<rsvx7_tool_call>'
CLOSE = '</rsvx7_tool_call>'
ENVELOPE = OPEN + json.dumps({'calls': [{'name': 'read_file', 'arguments': {'path': 'demo.txt'}}]}) + CLOSE

@pytest.mark.parametrize('preamble', [False, True])
@pytest.mark.parametrize('streaming', [False, True])
@pytest.mark.parametrize('repair', [False, True])
@pytest.mark.parametrize('keep_tools', [False, True])
def test_compat_api_roundtrip_preserves_tools_results_and_charges_all_attempts(env, monkeypatch, streaming, repair, keep_tools, preamble):
    env.users.rows['alice']['token_balance'] = 1000000
    monkeypatch.setattr(tokens, 'db', env)
    monkeypatch.setattr(server, 'require_membership', AsyncMock())
    monkeypatch.setattr(server, 'current_settings', AsyncMock(return_value={
        'model': 'fixture/text-only', 'context_length': 131072,
        'max_completion_tokens': 8192, 'supported_parameters': [], 'reasoning': None,
    }))
    monkeypatch.setattr(server, 'claim_generation', AsyncMock(side_effect=['compat-one', 'compat-two']))
    monkeypatch.setattr(server, 'release_generation', AsyncMock())
    requests = []
    async def handler(request):
        body = json.loads(request.content); requests.append(body)
        assert not {'tools', 'tool_choice', 'parallel_tool_calls'} & body.keys()
        if 'tool_result' in body['messages'][-1]['content']:
            output = 'File has hello'
        elif repair and len(requests) == 1:
            output = ('I will read the file.\n\n' + ENVELOPE) if preamble else OPEN + '{broken' + CLOSE
        else:
            output = OPEN + json.dumps({'calls': {'name': 'read_file', 'arguments': {'path': 'demo.txt'}}}) + CLOSE
        chunks = [sdk_chunk({'content': output[i:i+5]}) for i in range(0, len(output), 5)]
        chunks += [sdk_chunk({}, 'stop'), sdk_chunk(usage={'prompt_tokens': 23, 'completion_tokens': 7, 'total_tokens': 30})]
        return httpx.Response(200, headers={'content-type':'text/event-stream'}, content=''.join('data: '+json.dumps(c)+'\n\n' for c in chunks)+'data: [DONE]\n\n')
    provider = AsyncOpenAI(api_key='fixture', base_url='https://fixture.test/v1', http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)), max_retries=0)
    monkeypatch.setattr(server, 'request_client', lambda _: provider)
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url='https://fixture.test') as client:
            key = (await client.post('/api/developer/key', headers={'Authorization':'Bearer '+auth.make_token('alice','user')})).json()['key']
            headers = {'Authorization':'Bearer '+key}
            payload = {'model':'kaligpt','messages':[{'role':'user','content':'Read demo.txt'}], 'tools':[TOOL], 'stream':streaming, 'max_tokens':2048, 'stream_options':{'include_usage':True}}
            result = await client.post('/api/v1/chat/completions', headers=headers, json=payload)
            assert result.status_code == 200, result.text
            if streaming:
                frames = [json.loads(line[6:]) for line in result.text.splitlines() if line.startswith('data: ') and line != 'data: [DONE]']
                assert not any('error' in x for x in frames), result.text
                call = next(x['choices'][0]['delta']['tool_calls'][0] for x in frames if x.get('choices') and x['choices'][0]['delta'].get('tool_calls'))
                call = {k:v for k,v in call.items() if k != 'index'}
                assert frames[-1]['usage']['prompt_tokens'] == 23 * (2 if repair else 1)
                assert any(x.get('choices') and x['choices'][0]['finish_reason']=='tool_calls' for x in frames)
                assert OPEN not in result.text and '{broken' not in result.text
            else:
                data = result.json(); assert data['choices'][0]['finish_reason']=='tool_calls'
                call = data['choices'][0]['message']['tool_calls'][0]
                assert data['usage']['prompt_tokens'] == 23 * (2 if repair else 1)
                assert data['usage']['completion_tokens'] == 7 * (2 if repair else 1)
            assert call['id'].startswith('call_')
            assert call['function']['name']=='read_file'
            assert json.loads(call['function']['arguments'])=={'path':'demo.txt'}
            assert len(env.token_usage_history.rows)==1
            first_usage=next(iter(env.token_usage_history.rows.values()))
            assert first_usage['full_prompt_tokens']==23*(2 if repair else 1)
            assert first_usage['assistant_output_tokens']==7*(2 if repair else 1)
            assert env.users.rows['alice']['token_balance']==1000000-round(30*(2 if repair else 1)*tokens.BILLING_MULTIPLIER)
            follow=copy.deepcopy(payload);follow['stream']=False
            if not keep_tools:follow.pop('tools')
            follow['messages'] += [{'role':'assistant','content':None,'tool_calls':[call]}, {'role':'tool','tool_call_id':call['id'],'content':'hello'}]
            result=await client.post('/api/v1/chat/completions',headers=headers,json=follow)
            assert result.status_code==200,result.text
            assert result.json()['choices'][0]['message']['content']=='File has hello'
            assert len(env.token_usage_history.rows)==2
            assert all(m['role'] != 'tool' for m in requests[-1]['messages'])
            assert len(requests)==(3 if repair else 2)
        await provider.close()
    asyncio.run(scenario())


def test_envelope_holds_partial_tools_but_streams_ordinary_text_immediately():
    assert importlib.util.find_spec('tool_compat') is not None, 'compatibility module not implemented'
    from tool_compat import ToolEnvelope
    from tool_protocol import ToolDefinition
    parser=ToolEnvelope([ToolDefinition.model_validate(TOOL)])
    assert parser.feed('Hello')=='Hello'
    assert parser.feed(' world')==' world'
    assert parser.finish('stop')==[]
    parser=ToolEnvelope([ToolDefinition.model_validate(TOOL)])
    for char in ENVELOPE:
        assert parser.feed(char)==''
    assert parser.finish('stop')[0]['function']['name']=='read_file'

@pytest.mark.parametrize('output,reason', [
    (OPEN+'{"calls":[{"name":"unknown","arguments":{}}]}'+CLOSE,'stop'),
    (OPEN+'{"calls":[{"name":"read_file","arguments":{"path":3}}]}'+CLOSE,'stop'),
    (OPEN+'{"calls":[{"name":"read_file","arguments":{}}]}'+CLOSE,'stop'),
    (OPEN+'{"calls":[{"name":"read_file","arguments":{}}]}','length'),
    (ENVELOPE+'unexpected trailing command','stop'),
    (OPEN+'{"calls":[],"calls":[]}'+CLOSE,'stop'),
])
def test_invalid_tools_never_become_executable_calls(output, reason):
    assert importlib.util.find_spec('tool_compat') is not None, 'compatibility module not implemented'
    from tool_compat import ToolEnvelope, CompatibilityFormatError
    from tool_protocol import ToolDefinition
    parser=ToolEnvelope([ToolDefinition.model_validate(TOOL)])
    assert parser.feed(output)==''
    with pytest.raises(CompatibilityFormatError): parser.finish(reason)

@pytest.mark.parametrize('choice,parallel,body', [
    ('required',None,'A normal answer'),
    ('none',None,ENVELOPE),
    ({'type':'function','function':{'name':'other'}},None,ENVELOPE),
    ('auto',False,OPEN+json.dumps({'calls':[{'name':'read_file','arguments':{'path':'one'}},{'name':'read_file','arguments':{'path':'two'}}]})+CLOSE),
])
def test_choice_and_parallel_constraints(choice,parallel,body):
    from tool_compat import ToolEnvelope, CompatibilityFormatError
    from tool_protocol import ToolDefinition
    parser=ToolEnvelope([ToolDefinition.model_validate(TOOL)],choice,parallel)
    parser.feed(body)
    with pytest.raises(CompatibilityFormatError):parser.finish('stop')


def test_code_fences_or_embedded_tags_are_text_not_executable_calls():
    from tool_compat import ToolEnvelope
    from tool_protocol import ToolDefinition
    for output in ('Example: '+ENVELOPE, '```json\n'+ENVELOPE+'\n```'):
        parser=ToolEnvelope([ToolDefinition.model_validate(TOOL)])
        visible = parser.feed(output)
        assert visible + parser.flush_text() == output
        assert parser.finish('stop')==[]


def test_schemas_are_validated_and_remote_references_never_fetched():
    from tool_compat import ToolEnvelope
    from tool_protocol import ToolDefinition
    from fastapi import HTTPException
    for schema in ({'type':'invalid'}, {'$ref':'http://127.0.0.1/private'}):
        tool=copy.deepcopy(TOOL);tool['function']['parameters']=schema
        with pytest.raises(HTTPException):ToolEnvelope([ToolDefinition.model_validate(tool)])
    tool=copy.deepcopy(TOOL)
    tool['function']['parameters']={'type':'object','$defs':{'path':{'type':'string','enum':['demo.txt']}},'properties':{'path':{'$ref':'#/$defs/path'}},'required':['path'],'additionalProperties':False}
    parser=ToolEnvelope([ToolDefinition.model_validate(tool)])
    parser.feed(ENVELOPE)
    assert parser.finish('stop')[0]['function']['arguments']=='{"path": "demo.txt"}'


def test_required_tool_repairs_once_without_leaking_plain_text_and_uses_shared_output_budget():
    from tool_compat import ToolCompatibility
    from tool_protocol import ToolDefinition
    from types import SimpleNamespace
    requests=[]
    class Raw:
        def __init__(self, text):self.text=text;self.closed=False
        def __aiter__(self):return self.generate()
        async def generate(self):
            yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content=self.text,tool_calls=[]),finish_reason='stop')],usage=None)
            yield SimpleNamespace(choices=[],usage=SimpleNamespace(prompt_tokens=10,completion_tokens=5,prompt_tokens_details=None))
        async def close(self):self.closed=True
    raws=[]
    async def create(**kwargs):
        requests.append(kwargs);raw=Raw('incorrect plain answer' if len(requests)==1 else ENVELOPE);raws.append(raw);return raw
    bridge=ToolCompatibility([ToolDefinition.model_validate(TOOL)],'required',False,server._ThinkSplitter,8192)
    client=SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
    async def run():
        stream=await bridge.wrap_client(client).chat.completions.create(messages=bridge.prepare([{'role':'user','content':'Read file'}]),max_tokens=50,stream=True)
        frames=[x async for x in stream]
        assert not any(getattr(c.delta,'content',None) for x in frames for c in x.choices)
        assert any(c.delta.tool_calls for x in frames for c in x.choices)
        usage=next(x.usage for x in frames if x.usage)
        assert usage.prompt_tokens==20 and usage.completion_tokens==10
        assert requests[0]['max_tokens']==50 and requests[1]['max_tokens']==45
        assert all(r.closed for r in raws)
    asyncio.run(run())


def test_two_invalid_attempts_or_truncation_never_publish_a_tool():
    from tool_compat import ToolCompatibility, CompatibilityFormatError
    from tool_protocol import ToolDefinition
    from types import SimpleNamespace
    for reason, expected in [('stop',2),('length',1)]:
        requests=[]
        class Raw:
            def __aiter__(self):return self.generate()
            async def generate(self):
                yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content=OPEN+'{"calls":[]}',tool_calls=[]),finish_reason=reason)],usage=None)
            async def close(self):pass
        async def create(**kwargs):requests.append(kwargs);return Raw()
        bridge=ToolCompatibility([ToolDefinition.model_validate(TOOL)],'auto',True,server._ThinkSplitter,8192)
        client=SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
        async def run():
            stream=await bridge.wrap_client(client).chat.completions.create(messages=bridge.prepare([{'role':'user','content':'Read file'}]),max_tokens=1024,stream=True)
            frames=[]
            with pytest.raises(CompatibilityFormatError):
                async for frame in stream:frames.append(frame)
            assert not any(c.delta.tool_calls for x in frames for c in x.choices)
            assert len(requests)==expected
        asyncio.run(run())


def test_compat_reserves_repair_prompt_budget_before_spending_provider_credits(env, monkeypatch):
    from types import SimpleNamespace
    env.users.rows['alice']['token_balance']=100
    monkeypatch.setattr(tokens,'db',env)
    monkeypatch.setattr(server,'require_membership',AsyncMock())
    monkeypatch.setattr(server,'current_settings',AsyncMock(return_value={'model':'fixture/text','context_length':8192,'max_completion_tokens':4096,'supported_parameters':[]}))
    create=AsyncMock()
    provider=SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
    monkeypatch.setattr(server,'request_client',lambda _:provider)
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://fixture.test') as client:
            key=(await client.post('/api/developer/key',headers={'Authorization':'Bearer '+auth.make_token('alice','user')})).json()['key']
            result=await client.post('/api/v1/chat/completions',headers={'Authorization':'Bearer '+key},json={'model':'kaligpt','messages':[{'role':'user','content':'Read file'}],'tools':[TOOL]})
            assert result.status_code==402,result.text
            assert env.users.rows['alice']['token_balance']==100
            assert not env.token_usage_history.rows
            create.assert_not_awaited()
    asyncio.run(scenario())


def test_tool_compatibility_can_be_disabled_without_disabling_native_tools(monkeypatch):
    from tool_compat import tool_mode
    monkeypatch.setenv('RSVX7_TOOL_COMPAT','false')
    assert tool_mode({'supported_parameters':[]})=='unavailable'
    assert tool_mode({'supported_parameters':['tools']})=='native'


def test_cancellation_closes_upstream_without_publishing_partial_calls():
    from tool_compat import ToolCompatibility
    from tool_protocol import ToolDefinition
    from types import SimpleNamespace
    async def scenario():
        entered,closed=asyncio.Event(),asyncio.Event()
        class Raw:
            def __aiter__(self):return self.generate()
            async def generate(self):
                yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content=OPEN+'{',tool_calls=[]),finish_reason=None)],usage=None)
                entered.set()
                await asyncio.Event().wait()
            async def close(self):closed.set()
        async def create(**kwargs):return Raw()
        bridge=ToolCompatibility([ToolDefinition.model_validate(TOOL)],'auto',False,server._ThinkSplitter,8192)
        client=SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
        stream=await bridge.wrap_client(client).chat.completions.create(messages=bridge.prepare([{'role':'user','content':'Read file'}]),max_tokens=1024,stream=True)
        frames=[]
        async def consume():
            async for chunk in stream:frames.append(chunk)
        task=asyncio.create_task(consume())
        await asyncio.wait_for(entered.wait(),1)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):await task
        assert closed.is_set()
        assert not frames
    asyncio.run(scenario())


def test_numeric_overflow_is_a_repairable_format_error_not_a_raw_serializer_crash():
    from tool_compat import ToolEnvelope, CompatibilityFormatError
    from tool_protocol import ToolDefinition
    tool=copy.deepcopy(TOOL)
    tool['function']['parameters']={'type':'object','properties':{'n':{'type':'number'}},'required':['n']}
    parser=ToolEnvelope([ToolDefinition.model_validate(tool)])
    parser.feed(OPEN+'{"calls":[{"name":"read_file","arguments":{"n":1e999}}]}'+CLOSE)
    with pytest.raises(CompatibilityFormatError):parser.finish('stop')


@pytest.mark.parametrize('step', [1, 2, 5, 4096])
@pytest.mark.parametrize('prefix', ['I will inspect.\n\n', 'سأفحص الملف.\r\n'])
def test_standalone_tag_after_prose_is_repaired_not_published(step, prefix):
    from tool_compat import ToolEnvelope, CompatibilityFormatError
    from tool_protocol import ToolDefinition
    parser = ToolEnvelope([ToolDefinition.model_validate(TOOL)])
    text = prefix + ENVELOPE
    visible = ''
    with pytest.raises(CompatibilityFormatError) as error:
        for i in range(0, len(text), step):
            visible += parser.feed(text[i:i+step])
    assert error.value.reason == 'tool_envelope_after_text'
    assert OPEN not in visible

@pytest.mark.parametrize('step', [1, 5, 4096])
@pytest.mark.parametrize('text', [
    'Example: '+ENVELOPE,
    '> '+ENVELOPE,
    '```json\n'+ENVELOPE+'\n```',
    '~~~~json\r\n'+ENVELOPE+'\r\n~~~~',
    'Hello\n<rs',
    'Hello\n   ',
])
def test_text_guard_preserves_examples_and_partial_text(step, text):
    from tool_compat import ToolEnvelope
    from tool_protocol import ToolDefinition
    parser = ToolEnvelope([ToolDefinition.model_validate(TOOL)])
    output = ''.join(parser.feed(text[i:i+step]) for i in range(0, len(text), step))
    assert parser.finish('stop') == []
    assert output + parser.flush_text() == text

def test_single_object_still_validates_arguments():
    from tool_compat import ToolEnvelope, CompatibilityFormatError
    from tool_protocol import ToolDefinition
    for path in ('demo.txt', 3):
        parser = ToolEnvelope([ToolDefinition.model_validate(TOOL)])
        parser.feed(OPEN+json.dumps({'calls': {'name': 'read_file', 'arguments': {'path': path}}})+CLOSE)
        if isinstance(path, str):
            assert parser.finish('stop')[0]['function']['name'] == 'read_file'
        else:
            with pytest.raises(CompatibilityFormatError): parser.finish('stop')

def test_tag_after_closed_fence_needs_repair():
    from tool_compat import ToolEnvelope, CompatibilityFormatError
    from tool_protocol import ToolDefinition
    parser = ToolEnvelope([ToolDefinition.model_validate(TOOL)])
    text = 'Example:\n```json\n'+ENVELOPE+'\n```\n'+ENVELOPE
    with pytest.raises(CompatibilityFormatError) as error:
        for char in text: parser.feed(char)
    assert error.value.reason == 'tool_envelope_after_text'
