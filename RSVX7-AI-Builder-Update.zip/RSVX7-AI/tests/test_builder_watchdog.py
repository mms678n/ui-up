"""Silent keepalives must not masquerade as project generation progress."""
import asyncio, copy, json
import pytest
from unittest.mock import AsyncMock
from tests.test_builder import setup, builder, USER, SOURCE, run

def job_state(db):
    state={**builder._empty(),'files':copy.deepcopy(SOURCE),'messages':[],
           'job':{'id':'watch-job','status':'running','mode':'build','model':'synthetic/model'}}
    db.projects.rows['p_owned']['builder']=copy.deepcopy(state)
    return state

def engine(monkeypatch,events):
    class Response:
        status_code=200
        async def aiter_lines(self):
            async for event in events():yield json.dumps(event) if event is not None else ''
    class Context:
        async def __aenter__(self):return Response()
        async def __aexit__(self,*args):pass
    class Client:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        def stream(self,*args,**kwargs):return Context()
    monkeypatch.setattr(builder.httpx,'AsyncClient',Client)

def activity(chars=0,phase='receiving',call_id='watch-call-0001'):
    return {'type':'activity','callId':call_id,'phase':phase,'chars':chars,'reasoningChars':0}

async def finish():
    files={'/home/project/index.html':{'type':'file','content':'complete','isBinary':False}}
    for stage in ('structure','writing','reviewing'):
        yield {'type':'pipeline','stage':stage,'completed':1,'total':1,'files':files}
    yield {'type':'files','files':files,'annotation':{'type':'studioReviewedBuild'}}
    yield {'type':'done'}

def execute(state):return builder._run_job(USER,'p_owned','watch-job',state,builder.RunBody(requestId='watch-request',revision=0,text='Synthetic greeting'))

def test_heartbeats_without_data_stop_with_a_saved_diagnostic(setup,monkeypatch):
    state=job_state(setup);monkeypatch.setattr(builder,'JOB_STALL_SECONDS',.03)
    async def events():
        yield activity(phase='waiting_provider')
        while True:
            await asyncio.sleep(.01);yield None
    engine(monkeypatch,events);run(asyncio.wait_for(execute(state),.5))
    saved=setup.projects.rows['p_owned']['builder']
    assert saved['job']['status']=='failed' and saved['job']['errorCode']=='generation_stalled'
    assert saved['job']['modelCall']['phase']=='waiting_provider'
    assert saved['files']==SOURCE and not setup.token_usage_history.rows

def test_repeated_status_with_unchanged_character_count_is_not_progress(setup,monkeypatch):
    state=job_state(setup);monkeypatch.setattr(builder,'JOB_STALL_SECONDS',.03)
    async def events():
        yield activity(phase='waiting_provider');yield activity(1)
        while True:
            await asyncio.sleep(.01);yield activity(1)
    engine(monkeypatch,events);run(asyncio.wait_for(execute(state),.5))
    assert setup.projects.rows['p_owned']['builder']['job']['errorCode']=='generation_stalled'

def test_actual_stream_data_extends_idle_time_and_saves_progress_before_publication(setup,monkeypatch):
    state=job_state(setup);monkeypatch.setattr(builder,'JOB_STALL_SECONDS',.1)
    async def events():
        yield activity(phase='waiting_provider')
        for count in range(1,8):
            await asyncio.sleep(.02);yield activity(count)
        yield {'type':'generation','files':4,'batches':2}
        async for event in finish():yield event
    engine(monkeypatch,events);run(execute(state))
    saved=setup.projects.rows['p_owned']['builder']
    assert saved['job']['status']=='completed' and saved['job']['modelCall']['chars']==7
    assert saved['job']['generation']=={'files':4,'batches':2}
    assert saved['files']['/home/project/index.html']['content']=='complete'

def test_the_whole_job_deadline_still_applies_to_continuous_model_data(setup,monkeypatch):
    state=job_state(setup);monkeypatch.setattr(builder,'JOB_TOTAL_SECONDS',.05)
    async def events():
        yield activity(phase='waiting_provider')
        count=0
        while True:
            await asyncio.sleep(.005);count+=1;yield activity(count)
    engine(monkeypatch,events);run(asyncio.wait_for(execute(state),.5))
    saved=setup.projects.rows['p_owned']['builder']
    assert saved['job']['status']=='failed' and saved['job']['errorCode']=='job_timeout'
    assert saved['files']==SOURCE

def test_a_partial_batch_does_not_replace_existing_source_after_timeout(setup,monkeypatch):
    state=job_state(setup);monkeypatch.setattr(builder,'JOB_STALL_SECONDS',.02)
    async def events():
        yield {'type':'generation','files':3,'batches':1}
        while True:
            await asyncio.sleep(.01);yield None
    engine(monkeypatch,events);run(execute(state))
    saved=setup.projects.rows['p_owned']['builder']
    assert saved['files']==SOURCE and saved['job']['generation']['files']==3
    assert saved['job']['errorCode']=='generation_stalled'

def test_format_feedback_remains_available_after_a_failed_request(setup,monkeypatch):
    state=job_state(setup)
    async def events():
        yield activity(phase='waiting_provider');yield activity(120)
        yield {'type':'validation','batch':1,'attempt':2,'reason':'Missing string content for synthetic file'}
        yield {'type':'error','code':'file_format','message':'Synthetic format rejected'}
    engine(monkeypatch,events);run(execute(state))
    job=setup.projects.rows['p_owned']['builder']['job']
    assert job['status']=='failed' and job['errorCode']=='file_format'
    assert job['modelCall']['phase']=='retrying_format'
    assert job['validation']['attempt']==2 and 'Missing string' in job['validation']['reason']

def test_invalid_counter_cannot_publish_generated_source(setup,monkeypatch):
    state=job_state(setup)
    async def events():
        yield activity(phase='waiting_provider');yield activity(12);yield activity(3)
        async for event in finish():yield event
    engine(monkeypatch,events);run(execute(state))
    saved=setup.projects.rows['p_owned']['builder']
    assert saved['job']['status']=='failed' and saved['files']==SOURCE


@pytest.mark.parametrize('batches,completed',[(101,True),(200,True),(201,False)])
def test_generation_accepts_every_supported_pipeline_batch(setup,monkeypatch,batches,completed):
    state=job_state(setup)
    async def events():
        yield {'type':'generation','files':batches,'batches':batches}
        async for event in finish():yield event
    engine(monkeypatch,events);run(execute(state))
    saved=setup.projects.rows['p_owned']['builder']
    assert saved['job']['status']==('completed' if completed else 'failed')
