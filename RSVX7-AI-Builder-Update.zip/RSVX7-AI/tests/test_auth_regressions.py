"""Regression tests for auth changes.

The environment is deliberately pinned before importing backend.auth so this
module cannot connect to preview/production data. Telegram HTTP is mocked.
"""
import asyncio
import os
import sys
from pathlib import Path

import pytest
from fastapi import HTTPException
from starlette.requests import Request
from motor.motor_asyncio import AsyncIOMotorClient

os.environ["DB_NAME"] = "rsvx7ai_test_auth"
os.environ["MONGO_URL"] = "mongodb://localhost:27017"
os.environ["JWT_SECRET"] = "auth-regression-test-secret"
os.environ["COOKIE_SECURE"] = "false"
os.environ["OWNER_USERNAME"] = "test-owner-never-seeded"
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
import auth  # noqa: E402


_LOOP = asyncio.new_event_loop()


def run(awaitable):
    # Motor 3.x creates its futures on the loop active at import time; reuse
    # that loop rather than passing a Motor Future to asyncio.run().
    return _LOOP.run_until_complete(awaitable)


def request_for(path, *, bearer=None, cookie=None):
    headers = []
    if bearer is not None:
        headers.append((b"authorization", f"Bearer {bearer}".encode()))
    if cookie is not None:
        headers.append((b"cookie", f"access_token={cookie}".encode()))
    return Request({
        "type": "http", "method": "GET", "path": path,
        "scheme": "http", "server": ("localhost", 8000),
        "headers": headers, "query_string": b"",
    })


@pytest.fixture(autouse=True)
def clean_test_data(monkeypatch):
    client = AsyncIOMotorClient("mongodb://127.0.0.1:27017", io_loop=_LOOP)
    monkeypatch.setattr(auth, "db", client["rsvx7ai_test_auth"])
    uid = "auth-regression-user"
    run(auth.db.users.delete_many({"_id": uid}))
    run(auth.db.settings.delete_many({"_id": "global"}))

    async def no_external_bot(*args, **kwargs):
        return None

    monkeypatch.setattr(auth, "_bot_send", no_external_bot)
    yield
    run(auth.db.users.delete_many({"_id": uid}))
    run(auth.db.settings.delete_many({"_id": "global"}))
    client.close()


def insert_user(**overrides):
    doc = {
        "_id": "auth-regression-user",
        "username": "regression",
        "password_hash": auth.hash_pw("OldPass1!"),
        "recovery_hash": auth.hash_pw("AAAA-BBBB-CCCC-DDDD"),
        "role": "user", "status": "active", "must_change_password": False,
        "session_version": 0,
        "telegram": {},
    }
    doc.update(overrides)
    run(auth.db.users.insert_one(doc))
    return doc


def test_password_validation_is_72_utf8_bytes_before_bcrypt():
    # 24 Arabic characters are 48 bytes and valid; 25 is 50, while 37 is 74.
    valid = auth.RegisterBody(username="valid-user", password="أ" * 36)
    assert len(valid.password.encode("utf-8")) == 72
    with pytest.raises(ValueError):
        auth.RegisterBody(username="too-long", password="أ" * 37)
    assert auth.verify_pw("أ" * 37, auth.hash_pw("OldPass1!")) is False


def test_token_contains_version_and_authorization_wins_over_cookie():
    insert_user(_id="auth-regression-user")
    bearer = auth.make_token("auth-regression-user", "user", session_version=0)
    other = auth.make_token("other-user", "user", session_version=0)
    user = run(auth.current_user(request_for("/api/auth/me", bearer=bearer, cookie=other)))
    assert user["_id"] == "auth-regression-user"

    run(auth.db.users.update_one({"_id": "auth-regression-user"}, {"$set": {"session_version": 1}}))
    with pytest.raises(HTTPException) as exc:
        run(auth.current_user(request_for("/api/auth/me", bearer=bearer)))
    assert exc.value.status_code == 401


def test_must_change_is_backend_enforced_except_me_and_change_password():
    insert_user(must_change_password=True)
    token = auth.make_token("auth-regression-user", "user", session_version=0)
    assert run(auth.current_user(request_for("/api/auth/me", bearer=token)))["must_change_password"] is True
    with pytest.raises(HTTPException) as exc:
        run(auth.current_user(request_for("/api/workspace", bearer=token)))
    assert exc.value.status_code == 403
    assert exc.value.detail["code"] == "must_change_password"


def test_change_password_bumps_version_and_returns_current_session_token():
    insert_user(must_change_password=True)
    old_token = auth.make_token("auth-regression-user", "user", session_version=0)
    response = __import__("fastapi").Response()
    result = run(auth.change_pw(
        auth.ChangePwBody(old_password="OldPass1!", new_password="NewPass1!"),
        response,
        {"_id": "auth-regression-user", "username": "regression", "role": "user", "session_version": 0},
        __import__("fastapi").BackgroundTasks(),
    ))
    assert result["session_version"] == 1
    assert result["token"] != old_token
    assert run(auth.db.users.find_one({"_id": "auth-regression-user"}))["must_change_password"] is False
    with pytest.raises(HTTPException) as exc:
        run(auth.current_user(request_for("/api/auth/me", bearer=old_token)))
    assert exc.value.status_code == 401


def test_settings_get_hides_token_and_blank_post_preserves_it():
    run(auth.db.settings.insert_one({"_id": "global", "telegram_bot_token": "secret-token", "telegram_chat_id": "1"}))
    got = run(auth.get_settings({}))
    assert "telegram_bot_token" not in got
    assert got["telegram_bot_token_configured"] is True
    run(auth.set_settings(auth.SettingsBody(telegram_bot_token=""), {}))
    stored = run(auth.db.settings.find_one({"_id": "global"}))
    assert stored["telegram_bot_token"] == "secret-token"


def test_legacy_verify_by_id_never_links_a_seen_record():
    with pytest.raises(HTTPException) as exc:
        run(auth.tg_verify_by_id(auth.TgVerifyByIdBody(telegram_id=123456789), {
            "_id": "auth-regression-user", "telegram": {},
        }))
    assert exc.value.status_code == 400
    assert "challenge" in str(exc.value.detail).lower()


def test_nonce_is_consumed_atomically_for_private_chat_and_sets_completion():
    now = auth.datetime.now(auth.timezone.utc)
    user = insert_user(telegram={
        "verified": False,
        "challenge_nonce": "nonce-for-test",
        "challenge_expires_at": (now + auth.timedelta(minutes=5)).isoformat(),
        "challenge_completed": False,
    })
    linked = run(auth._tg_complete_challenge(
        "unused-in-test", {"id": 999, "type": "private"},
        {"id": 999, "username": "tester", "first_name": "Test"}, "nonce-for-test",
    ))
    assert linked["_id"] == user["_id"]
    stored = run(auth.db.users.find_one({"_id": user["_id"]}))
    assert stored["telegram"]["verified"] is True
    assert stored["telegram"]["challenge_completed"] is True
    assert stored["telegram"]["telegram_id"] == 999
    second = run(auth._tg_complete_challenge(
        "unused-in-test", {"id": 999, "type": "private"},
        {"id": 999, "username": "tester"}, "nonce-for-test",
    ))
    assert second is None


def test_telegram_start_reuses_active_nonce_under_concurrent_mounts():
    user = insert_user()
    async def scenario():
        first, second = await asyncio.gather(
            auth.tg_link_start(auth.TgLinkStartBody(), user),
            auth.tg_link_start(auth.TgLinkStartBody(), user),
        )
        assert first["challenge_nonce"] == second["challenge_nonce"]
        assert first["deep_link"] == second["deep_link"]
        assert first["telegram_bot_configured"] is False
        fresh = await auth.db.users.find_one({"_id": user["_id"]})
        third = await auth.tg_link_start(auth.TgLinkStartBody(), fresh)
        assert third["challenge_nonce"] == first["challenge_nonce"]
        status = await auth.tg_link_status(await auth.db.users.find_one({"_id": user["_id"]}))
        assert status["challenge_active"] is True
    run(scenario())


def test_telegram_start_rotates_expired_challenge_and_handles_legacy_null():
    user = insert_user(telegram=None)
    async def scenario():
        first = await auth.tg_link_start(auth.TgLinkStartBody(), user)
        await auth.db.users.update_one({"_id": user["_id"]}, {"$set": {"telegram.challenge_expires_at": "2000-01-01T00:00:00+00:00"}})
        fresh = await auth.db.users.find_one({"_id": user["_id"]})
        second = await auth.tg_link_start(auth.TgLinkStartBody(), fresh)
        assert first["challenge_nonce"] != second["challenge_nonce"]
        assert second["deep_link"].startswith("https://t.me/")
    run(scenario())
