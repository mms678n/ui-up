"""Opt-in bounded live Builder smoke test. Synthetic input; credentials never saved.
Run: python -m tests.live_builder_smoke --live
Requires dev test dependencies. Uses real engine + real provider SDK, isolated in-memory records.
"""
import argparse, asyncio, copy, getpass, json, os, re, secrets, socket
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock
import httpx, jwt, pytest, uvicorn
from fastapi import FastAPI
from openai import AsyncOpenAI
from tests.test_builder import setup, builder, ai_settings, auth, USER

async def main(key, model, scenario="greeting", deep_think=False, output_dir=None):
    patch = pytest.MonkeyPatch()
    db = setup.__wrapped__(patch)
    db.users.rows['alice']['role'] = 'admin'
    db.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job': {'id':'live-smoke','status':'running'}}
    async with httpx.AsyncClient(timeout=30) as catalog:
        reply = await catalog.get('https://openrouter.ai/api/v1/models'); reply.raise_for_status()
        selected = next((item for item in reply.json()['data'] if item['id']==model),None)
    if selected is None: raise RuntimeError('Requested smoke-test model is not in the provider catalog')
    settings = {'model':model,'key_configured':True,'context_length':selected['context_length'],
                'max_completion_tokens':min(32768,selected.get('top_provider',{}).get('max_completion_tokens') or 32768),'supported_parameters':selected.get('supported_parameters',[]),'reasoning':selected.get('reasoning')}
    prices = selected.get('pricing',{})
    price_in,price_out = float(prices['prompt']),float(prices['completion'])
    print('Live model:',model,flush=True)
    patch.setattr(builder,'current_settings',AsyncMock(return_value=settings))
    client = AsyncOpenAI(api_key=key,base_url='https://openrouter.ai/api/v1',max_retries=0,timeout=150)
    requests, ceiling = 0, 0.0
    async def create(**kwargs):
        nonlocal requests,ceiling
        # Conservative byte-based prompt upper bound + output cap. Stop before excess spend.
        estimate = sum(len(m['content'].encode())+20 for m in kwargs['messages'])*price_in + kwargs['max_tokens']*price_out
        if requests >= 12 or ceiling+estimate>0.75: raise RuntimeError('Live smoke-test budget reached')
        requests+=1;ceiling+=estimate
        role = 'builder' if kwargs['messages'][0]['content'].startswith('You implement the user') else 'planning'
        print('Provider call',requests,role,'output cap:',kwargs['max_tokens'],'reasoning:',kwargs.get('extra_body',{}),flush=True)
        original = await client.chat.completions.create(**kwargs)
        label = role
        class ObservedStream:
            async def close(self): await original.close()
            def __aiter__(self): return self.events()
            async def events(self):
                parts=[];ending=None
                async for chunk in original:
                    for choice in chunk.choices or []:
                        if choice.delta.content: parts.append(choice.delta.content)
                        if choice.finish_reason: ending=choice.finish_reason
                    yield chunk
                text=''.join(parts)
                try:
                    parsed=json.loads(text)
                    detail={k:parsed.get(k) for k in ('verdict','remainingFiles') if k in parsed}
                    if 'actions' in parsed: detail['paths']=[x.get('filePath') for x in parsed['actions']]
                    if 'coverage' in parsed: detail['coverage']=parsed['coverage']
                    if 'issues' in parsed: detail['issues']=parsed['issues']
                except Exception: detail={'json':'invalid'}
                print('Provider result',label,'finish:',ending,'chars:',len(text),'summary:',json.dumps(detail,ensure_ascii=False)[:3000],flush=True)
        return ObservedStream()
    patch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    patch.setattr(ai_settings,'request_client',lambda value:value)
    listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen();api_port=listener.getsockname()[1]
    reserve=socket.socket();reserve.bind(('127.0.0.1',0));engine_port=reserve.getsockname()[1];reserve.close()
    app=FastAPI();app.include_router(builder.router)
    server=uvicorn.Server(uvicorn.Config(app,log_level='error',lifespan='off'))
    serving=asyncio.create_task(server.serve(sockets=[listener]))
    secret=secrets.token_hex(32)
    engine=await asyncio.create_subprocess_exec('node',str(Path(__file__).resolve().parents[1]/'builder/dist/service.mjs'),env={**os.environ,'BUILDER_ENGINE_SECRET':secret,'BUILDER_ENGINE_PORT':str(engine_port),'BUILDER_API_ORIGIN':f'http://127.0.0.1:{api_port}'},stdout=asyncio.subprocess.DEVNULL)
    try:
        async with httpx.AsyncClient(timeout=900, trust_env=False) as local:
            base=f'http://127.0.0.1:{engine_port}'
            for _ in range(100):
                try:
                    if (await local.get(base+'/health',headers={'Authorization':'Bearer '+secret})).status_code==200: break
                except httpx.HTTPError: pass
                await asyncio.sleep(.05)
            ticket=jwt.encode({'sub':'alice','pid':'p_owned','job':'live-smoke','aud':'rsvx7-builder-model','deepThink':deep_think},auth.JWT_SECRET,algorithm='HS256')
            proposal={'kind':'proposal','title':'Greeting','summary':'A tiny static Arabic greeting page','pages':[{'name':'Home','purpose':'Show greeting'}],
                      'features':['Display أهلاً وسهلاً as the main heading','Provide static preview tooling and meaningful heading tests'],'design':'Readable centered Arabic heading on a light background','steps':['Implement static HTML/CSS with development preview and test tooling'],
                      'acceptanceChecks':['The Arabic heading أهلاً وسهلاً is visible.']}
            payload={'ticket':ticket,'mode':'build','files':{},'approvedPlan':proposal,'messages':[{'role':'user','content':'Build the approved tiny static Arabic greeting page. No application JavaScript, forms, API backend, external services or images. Development tooling (Vite/static preview and Node tests) is allowed. Keep files small. This is a synthetic protocol smoke test.'}]}
            if scenario == 'portfolio':
                proposal={'kind':'proposal','title':'Arabic portfolio','summary':'An Arabic RTL portfolio with local messages and project filtering',
                    'pages':[{'name':'Home','purpose':'Profile, projects and contact'}],
                    'features':['Filter projects by category','Validate and save contact messages locally','Persist theme preference'],
                    'design':'Responsive Arabic RTL, light/dark toggle, red accent, readable project cards',
                    'steps':['Create Vite app with modular source','Add meaningful Node tests and build script'],
                    'acceptanceChecks':['Project category filter updates the visible projects.', 'Invalid contact inputs are rejected and valid messages persist locally.', 'Theme preference persists after reload.', 'The interface is responsive and supports Arabic RTL.']}
                payload.update(approvedPlan=proposal,messages=[{'role':'user','content':'Build the approved Arabic portfolio with real working project filters, validated local contact form, persisted light/dark preference and meaningful behavior tests. Use Vite vanilla JavaScript with small imported modules, no external API or backend. Include package.json with dev/build/test scripts. Keep every source file compact. This is a synthetic integration test.'}])
            elif scenario == 'calculator':
                proposal={'kind':'proposal','title':'Arabic calculator','summary':'A compact Arabic calculator with validated arithmetic and saved history',
                    'pages':[{'name':'Home','purpose':'Calculate and inspect recent results'}],
                    'features':['Add, subtract, multiply and divide finite numbers','Reject invalid input and division by zero','Persist and clear calculation history'],
                    'design':'Accessible responsive Arabic RTL with clear input labels and result/error messages',
                    'steps':['Implement compact vanilla JavaScript modules with Vite','Add actual Node behavior tests for arithmetic, invalid input and history'],
                    'acceptanceChecks':['Arithmetic operations return the correct result.', 'Invalid input and division by zero are rejected.', 'History persists and can be cleared.']}
                payload.update(approvedPlan=proposal,messages=[{'role':'user','content':'Build the approved Arabic calculator. Use Vite with small vanilla JavaScript modules and Node built-in tests. No account, network request or external API. Handle finite numeric inputs and division by zero; persist history locally with a clear-history action. Provide dev/build/test scripts and actual behavior tests. Keep every file compact.'}])
            events=[]
            async with local.stream('POST',base+'/generate',headers={'Authorization':'Bearer '+secret},json=payload) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.strip(): continue
                    event=json.loads(line);events.append(event)
                    if event['type']=='error': print('ENGINE ERROR:',event.get('code'),event['message'],flush=True)
            result=next((event for event in events if event['type']=='files'),None)
            assert result and events[-1]['type']=='done','Live Builder did not finish'
            assert result['annotation']['type']=='studioReviewedBuild'
            assert not any(event['type']=='agents' for event in events)
            activity=[event for event in events if event['type']=='activity']
            assert any(event['phase']=='waiting_provider' for event in activity)
            assert any(event['phase']=='receiving' and event['chars']>0 for event in activity)
            assert activity[-1]['phase']=='validating'
            if scenario == 'greeting': assert any('أهلاً وسهلاً' in file['content'] for name,file in result['files'].items() if name.endswith('.html'))
            else: assert '/home/project/package.json' in result['files']
            assert not result['annotation'].get('salvaged')
            if output_dir:
                destination=Path(output_dir).resolve();destination.mkdir(parents=True,exist_ok=True)
                for name,file in result['files'].items():
                    path=(destination/name.removeprefix('/home/project/')).resolve()
                    assert path.is_relative_to(destination) and not file.get('isBinary')
                    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(file['content'])
            print('PASS live direct generation and stream bridge; files:',len(result['files']),'calls:',requests,'reserved USD upper bound:',round(ceiling,4),flush=True)
    finally:
        if engine.returncode is None: engine.terminate();await engine.wait()
        server.should_exit=True;await serving
        await client.close();patch.undo()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--live',action='store_true');parser.add_argument('--model',default='deepseek/deepseek-v4-flash');parser.add_argument('--scenario',choices=['greeting','portfolio','calculator'],default='greeting');parser.add_argument('--deep-think',action='store_true');parser.add_argument('--output-dir');args=parser.parse_args()
    if not args.live: parser.error('Explicit --live is required; this test calls a paid provider')
    secret=os.environ.get('OPENROUTER_API_KEY') or getpass.getpass('OpenRouter test key (not saved): ')
    asyncio.run(main(secret,args.model,args.scenario,args.deep_think,args.output_dir))
