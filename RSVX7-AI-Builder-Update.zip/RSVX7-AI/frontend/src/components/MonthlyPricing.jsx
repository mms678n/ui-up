import React, { useEffect, useRef, useState } from "react";
import { Check, Crown, Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/monthly";
import "./monthly-pricing.css";

const benefits = {
  free: ["الوصول إلى KaliGPT", "تجديد الرصيد المجاني كل شهر", "شحن رصيد إضافي عند الحاجة"],
  pro: ["الوصول إلى KaliGPT وDeepDark", "الوصول إلى Builder", "واجهة المطورين API", "شحن رصيد إضافي عند الحاجة"],
  max: ["الوصول إلى جميع النماذج", "الوصول إلى Builder", "الوصول إلى Hacker rsvx7 Ai", "واجهة المطورين API", "شحن رصيد إضافي عند الحاجة"],
};
// Three equal cards, a highlighted Pro tier, badges and a feature checklist:
// adapted to monthly-only billing from Shadcn Blocks' free Pricing 4 layout.
export default function MonthlyPricing({ wallet }) {
  const { user, authFetch } = useAuth() || {};
  const { t, dir, formatNumber, formatDate } = useI18n("monthly");
  const [plans, setPlans] = useState([]), [error, setError] = useState(""), [busy, setBusy] = useState(null), [notice, setNotice] = useState("");
  const pending = useRef(false);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    if (typeof fetch !== "function") return () => controller.abort();
    fetch(`${process.env.REACT_APP_BACKEND_URL || ""}/api/memberships/plans`, { signal: controller.signal })
      .then(async response => { if (!response.ok) throw Error(); const data = await response.json(); if (!Array.isArray(data.plans) || data.plans.length !== 3) throw Error(); if (!controller.signal.aborted) { setPlans(data.plans); setError(""); } })
      .catch(() => { if (!controller.signal.aborted) setError(t("تعذّر تحميل الباقات.")); });
    return () => controller.abort();
  }, [attempt, t]);
  const account = wallet || user || {}, current = account.entitlements?.plan || account.plan || (user ? "free" : null);
  const request = async plan => {
    if (!user) { window.location.hash = "#register"; return; }
    if (pending.current) return;
    pending.current = true; setBusy(plan); setError(""); setNotice("");
    try {
      const response = await authFetch("/memberships/request", { method: "POST", body: JSON.stringify({ plan }) });
      const data = await response.json();
      if (!response.ok || !data.request?.id) throw Error(typeof data.detail === "string" ? data.detail : t("تعذّر إرسال الطلب."));
      setNotice(t("تم إرسال طلب الاشتراك للإدارة. يبدأ الشهر بعد تأكيد الدفع والتفعيل."));
    } catch (error) { setError(error.message || t("تعذّر إرسال الطلب.")); }
    finally { pending.current = false; setBusy(null); }
  };
  return <section className="monthly-pricing" dir={dir} aria-labelledby="monthly-title" data-testid="monthly-pricing">
    <header className="monthly-heading"><span><Sparkles size={15} />{t("باقات شهرية")}</span><h2 id="monthly-title">{t("اختر المساحة التي تناسب طموحك")}</h2><p>{t("رصيد شهري واضح، وإمكانية شحن رصيد إضافي في أي وقت.")}</p></header>
    {error && <div role="alert" className="monthly-notice monthly-error">{error} <button onClick={() => setAttempt(value => value + 1)}>{t("إعادة المحاولة")}</button></div>}
    {notice && <p role="status" className="monthly-notice">{notice}</p>}
    <div className="monthly-grid">{plans.map(plan => <Card key={plan.id} className={`monthly-card ${plan.id === "pro" ? "monthly-featured" : ""}`} data-testid={`monthly-plan-${plan.id}`}>
      <CardHeader><div className="monthly-card-top"><Badge variant={plan.id === "pro" ? "default" : "secondary"}>{plan.name}</Badge>{plan.id === "pro" && <span className="monthly-recommended"><Crown size={13} />{t("الخيار المتوازن")}</span>}</div>
        <CardTitle className="monthly-price"><span dir="ltr">${plan.usd}</span><small>{t("/ شهريًا")}</small></CardTitle>
        <CardDescription className="monthly-allowance">{formatNumber(plan.tokens)} {t("توكن كل شهر")}</CardDescription>
      </CardHeader>
      <CardContent><ul>{(benefits[plan.id] || []).map(text => <li key={text}><Check size={17} aria-hidden="true" /><span>{t(text)}</span></li>)}</ul></CardContent>
      <CardFooter><Button className="monthly-cta" variant={plan.id === "pro" ? "default" : "outline"} disabled={(plan.id === "free" && !!user) || current === "admin" || busy !== null} onClick={() => request(plan.id)} data-testid={`request-monthly-${plan.id}`}>
        {busy === plan.id ? t("جارٍ إرسال الطلب…") : current === plan.id ? (plan.id === "free" ? t("باقتك الحالية") : t("طلب تجديد شهر")) : plan.id === "free" ? t("تبدأ مجانًا") : t("طلب الاشتراك")}
      </Button></CardFooter>
    </Card>)}</div>
    <p className="monthly-policy">{t("يُستهلك الرصيد الشهري أولًا، ثم الرصيد المشحون الدائم. الرصيد الشهري غير قابل للتراكم؛ عند انتهاء الباقة المدفوعة تعود إلى Free، ويبقى رصيد الشحن محفوظًا.")}</p>
    {account.monthly?.ends_at && <p className="monthly-current">{t("الباقة الحالية")}: <strong dir="ltr">{current}</strong> · {t("نهاية الفترة")}: {formatDate(account.monthly.ends_at)} · {t("شهري متبقٍ")}: {formatNumber(account.monthly_remaining ?? account.monthly.remaining ?? 0)} · {t("رصيد دائم")}: {formatNumber(account.purchased_remaining ?? 0)}</p>}
  </section>;
}
