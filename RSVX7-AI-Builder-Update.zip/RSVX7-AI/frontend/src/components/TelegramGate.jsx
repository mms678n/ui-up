import React, { useCallback, useEffect, useRef, useState } from "react";
import { CheckCircle2, ExternalLink, RefreshCw, Send } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { ActionButton, LoadingState, Panel, StatusNote } from "@/components/design/Primitives";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/auth";
import "@/components/auth-ui.css";

const BACKEND = process.env.REACT_APP_BACKEND_URL || "";

async function readResponse(response, fallback) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : data.detail?.message || fallback);
  return data;
}

/** Voluntary nonce-based linking, shown from account settings only. */
export function TelegramLinking() {
  const { authFetch, refresh } = useAuth();
  const { t, dir } = useI18n("auth");
  const [status, setStatus] = useState(null);
  const [challenge, setChallenge] = useState(null);
  const [loading, setLoading] = useState(true);
  const [starting, setStarting] = useState(false);
  const [checking, setChecking] = useState(false);
  const [botConfigured, setBotConfigured] = useState(null);
  const [error, setError] = useState("");
  const startingRef = useRef(false);
  const checkingRef = useRef(false);
  const verifiedRef = useRef(null);
  const mountedRef = useRef(false);

  const applyStatus = useCallback((next) => {
    setStatus(next);
    if (next.verified) {
      setChallenge(null);
      if (verifiedRef.current === false && refresh) void Promise.resolve(refresh()).catch(() => {});
    }
    verifiedRef.current = Boolean(next.verified);
  }, [refresh]);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    const results = await Promise.allSettled([
      authFetch("/auth/telegram/status").then((response) => readResponse(response, t("تعذّر تحميل حالة الربط."))),
      fetch(`${BACKEND}/api/settings/public`).then((response) => readResponse(response, t("تعذّر تحميل حالة الربط."))),
    ]);
    if (!mountedRef.current) return;
    if (results[0].status === "fulfilled") applyStatus(results[0].value);
    if (results[1].status === "fulfilled") setBotConfigured(results[1].value.telegram_bot_configured === true);
    const failed = results.find((result) => result.status === "rejected");
    if (failed) setError(failed.reason?.message || t("تعذّر الاتصال بالخادم. أعد المحاولة."));
    setLoading(false);
  }, [authFetch, applyStatus, t]);

  useEffect(() => {
    mountedRef.current = true;
    void load();
    return () => { mountedRef.current = false; };
  }, [load]);

  const checkStatus = useCallback(async () => {
    if (checkingRef.current) return;
    checkingRef.current = true;
    setChecking(true);
    try {
      const next = await readResponse(await authFetch("/auth/telegram/status"), t("تعذّر تحميل حالة الربط."));
      if (mountedRef.current) { applyStatus(next); setError(""); }
    } catch (requestError) {
      if (mountedRef.current) setError(requestError?.message || t("تعذّر الاتصال بالخادم. أعد المحاولة."));
    } finally {
      checkingRef.current = false;
      if (mountedRef.current) setChecking(false);
    }
  }, [authFetch, applyStatus, t]);

  const startChallenge = async () => {
    if (startingRef.current || botConfigured !== true) return;
    startingRef.current = true;
    setStarting(true);
    setError("");
    try {
      const next = await readResponse(await authFetch("/auth/telegram/start", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: "{}",
      }), t("تعذّر إنشاء رابط Telegram."));
      if (!mountedRef.current) return;
      setBotConfigured(next.telegram_bot_configured !== false);
      setChallenge(next);
      applyStatus({ ...next, challenge_active: Boolean(next.deep_link) });
    } catch (requestError) {
      if (mountedRef.current) setError(requestError?.message || t("تعذّر إنشاء رابط الربط."));
    } finally {
      startingRef.current = false;
      if (mountedRef.current) setStarting(false);
    }
  };

  const expiresAt = challenge?.expires_at || status?.expires_at;
  const activeChallenge = !status?.verified && Boolean(challenge?.deep_link || status?.challenge_active) && (!expiresAt || Date.parse(expiresAt) > Date.now());
  useEffect(() => {
    if (loading || !activeChallenge || botConfigured !== true) return undefined;
    let timer;
    const schedule = () => {
      window.clearInterval(timer);
      if (document.visibilityState === "visible") timer = window.setInterval(() => { void checkStatus(); }, 5000);
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible") void checkStatus();
      schedule();
    };
    schedule();
    document.addEventListener("visibilitychange", onVisibility);
    return () => { window.clearInterval(timer); document.removeEventListener("visibilitychange", onVisibility); };
  }, [loading, activeChallenge, botConfigured, checkStatus]);

  const botUrl = activeChallenge && botConfigured && challenge?.deep_link;
  return <Panel className="auth-ui-card auth-ui-gate-card auth-ui-gate" data-testid="telegram-linking" dir={dir}>
    <h3 className="auth-ui-section-label">{t("ربط حساب Telegram")}</h3>
    <p className="auth-ui-note">{t("ربط Telegram اختياري. يمكنك استخدام المنصة دون ربطه.")}</p>
    {loading ? <LoadingState label={t("جارٍ تحميل حالة Telegram…")} /> : <>
      {error && <StatusNote tone="error">{t(error)}</StatusNote>}
      {status?.verified ? <div className="auth-ui-status" role="status" data-testid="tg-linked-status"><CheckCircle2 size={17} aria-hidden="true" /><span>{t("تم ربط حساب Telegram.")}</span></div> : <>
        {botConfigured === false && <p role="alert" className="auth-ui-warning">{t("مفتاح بوت Telegram غير مهيّأ. يمكنك متابعة استخدام المنصة وإعادة المحاولة لاحقًا.")}</p>}
        {botUrl && <>
          <a href={botUrl} target="_blank" rel="noopener noreferrer" data-testid="tg-bot-link" className="auth-ui-link-card" dir="ltr">
            <Send size={17} aria-hidden="true" />
            <span className="auth-ui-link-card-copy"><strong>@{String(challenge.telegram_bot_username || "Telegram").replace(/^@/, "")}</strong><span>{botUrl}</span></span>
            <ExternalLink size={16} aria-hidden="true" />
          </a>
          <p className="auth-ui-note">{t("افتح الرابط واضغط {command}. الرابط لمرة واحدة ويعمل داخل محادثة خاصة فقط.", { command: "Start" })}</p>
          <div className="auth-ui-status" role="status" data-testid="tg-poll-status"><RefreshCw size={16} aria-hidden="true" />{t("بانتظار تأكيد Telegram…")}</div>
        </>}
        {challenge && !activeChallenge && <p className="auth-ui-note" role="status">{t("انتهت صلاحية الرابط. أنشئ رابطًا جديدًا.")}</p>}
        {!botUrl && <ActionButton type="button" tone="primary" loading={starting} disabled={botConfigured !== true || !status} onClick={startChallenge} data-testid="tg-new-challenge-btn">{starting ? t("جارٍ التجهيز…") : t("إنشاء رابط آمن")}</ActionButton>}
        {activeChallenge && <ActionButton type="button" tone="ghost" loading={checking} onClick={checkStatus} data-testid="tg-check-status-btn">{t("التحقق من الربط")}</ActionButton>}
      </>}
      {(error || botConfigured !== true) && <ActionButton type="button" tone="ghost" onClick={load}>{t("إعادة المحاولة")}</ActionButton>}
    </>}
  </Panel>;
}

/** Compatibility for older callers: account access never waits for Telegram. */
export default function TelegramGate({ children, showLinking = false }) {
  return showLinking ? <TelegramLinking /> : <>{children}</>;
}
