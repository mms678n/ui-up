import React, { useSyncExternalStore } from "react";
import { Moon, Sun } from "lucide-react";
import { useI18n } from "@/i18n";
import "./theme-switcher.css";

export const THEME_KEY = "rsvx7_theme";
const listeners = new Set();
function readTheme() {
  try { return localStorage.getItem(THEME_KEY) === "light" ? "light" : "dark"; }
  catch { return "dark"; }
}
let current = readTheme();
function apply(theme) {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.theme = theme;
  document.documentElement.classList.toggle("dark", theme === "dark");
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = theme === "dark" ? "#070709" : "#faf7f9";
}
apply(current);
export function setTheme(value) {
  const next = value === "light" ? "light" : "dark";
  current = next;
  try { localStorage.setItem(THEME_KEY, next); } catch { /* In-memory fallback. */ }
  apply(next);
  listeners.forEach((listener) => listener());
}
function subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); }
if (typeof window !== "undefined") {
  window.addEventListener("storage", (event) => {
    if (event.key !== THEME_KEY && event.key !== null) return;
    current = readTheme(); apply(current); listeners.forEach((listener) => listener());
  });
}
export function useTheme() {
  return useSyncExternalStore(subscribe, () => current, () => "dark");
}
export default function ThemeSwitcher({ className = "" }) {
  const theme = useTheme();
  const { t } = useI18n();
  const label = theme === "dark" ? t("التبديل إلى المظهر الفاتح") : t("التبديل إلى المظهر الداكن");
  return <button type="button" className={`theme-switcher ${className}`} data-testid="theme-switcher" aria-label={label} title={label}
    aria-pressed={theme === "light"} onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
    {theme === "dark" ? <Sun size={16} aria-hidden="true" /> : <Moon size={16} aria-hidden="true" />}
  </button>;
}
