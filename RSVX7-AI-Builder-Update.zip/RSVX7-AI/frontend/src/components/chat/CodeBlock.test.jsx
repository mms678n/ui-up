import React, { act } from "react";
import { createRoot } from "react-dom/client";
import CodeBlock from "./CodeBlock";
import StreamCodeBlock from "./StreamCodeBlock";
import HighlightedCode from "./HighlightedCode";
import { setLanguage } from "@/i18n";

let container;
let root;
let writeText;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  setLanguage("en");
  container = document.createElement("div");
  container.dir = "rtl";
  document.body.appendChild(container);
  root = createRoot(container);
  writeText = jest.fn().mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText } });
});
afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  setLanguage("ar");
  jest.useRealTimers();
});
const render = async (element) => act(async () => root.render(element));
const click = async (selector) => act(async () => container.querySelector(selector).click());

test.each(["first\n\n\n", "\t  const arabic = 'مرحبا';  \r\n", "", "\n"])("renders and copies the exact code payload %p", async (value) => {
  await render(<CodeBlock value={value} language="unknown-language" streaming />);
  expect(container.querySelector("pre code").textContent).toBe(value);
  await click('[data-testid="code-copy-btn"]');
  expect(writeText).toHaveBeenLastCalledWith(value);
});

test("plain and highlighted code preserve identical whitespace", async () => {
  const value = "const x = 1;\n\n\n";
  await render(<StreamCodeBlock value={value} />);
  expect(container.querySelector("code").textContent).toBe(value);
  await render(<HighlightedCode language="javascript" value={value} />);
  expect(container.querySelector("code").textContent).toBe(value);
});

test("announces successful and failed copy attempts and resets feedback", async () => {
  jest.useFakeTimers();
  await render(<CodeBlock value="answer" streaming />);
  await click('[data-testid="code-copy-btn"]');
  expect(container.querySelector('[role="status"]').textContent).toBe("Copied");
  expect(container.querySelector('[data-testid="code-copy-btn"]').getAttribute("aria-label")).toBe("Copied");
  await act(async () => jest.advanceTimersByTime(2000));
  expect(container.querySelector('[role="status"]').textContent).toBe("");
  writeText.mockRejectedValueOnce(new Error("denied"));
  await click('[data-testid="code-copy-btn"]');
  expect(container.querySelector('[role="status"]').textContent).toBe("Could not copy code. Try again.");
});

test("exposes keyboard scroll, collapse and wrapping state with readable language labels", async () => {
  await render(<CodeBlock value="const result = true" language="JS" streaming />);
  expect(container.querySelector(".code-language").textContent).toBe("JavaScript");
  const scroll = container.querySelector(".code-block-scroll");
  expect(scroll.getAttribute("dir")).toBe("ltr");
  expect(scroll.getAttribute("tabindex")).toBe("0");
  expect(scroll.getAttribute("role")).toBe("region");
  const toggle = container.querySelector('[data-testid="code-toggle-btn"]');
  expect(toggle.getAttribute("aria-controls")).toBe(scroll.id);
  expect(toggle.getAttribute("aria-expanded")).toBe("true");
  await click('[data-testid="code-wrap-btn"]');
  expect(container.querySelector('[data-testid="code-wrap-btn"]').getAttribute("aria-pressed")).toBe("true");
  expect(container.querySelector("pre").classList.contains("is-wrapped")).toBe(true);
  await click('[data-testid="code-toggle-btn"]');
  expect(toggle.getAttribute("aria-expanded")).toBe("false");
  expect(container.querySelector(".code-block-scroll").hidden).toBe(true);
  await click('[data-testid="code-toggle-btn"]');
  expect(container.querySelector("pre code").textContent).toBe("const result = true");
});

test("download preserves payload and uses an appropriate safe filename", async () => {
  const createObjectURL = jest.fn().mockReturnValue("blob:snippet");
  const revokeObjectURL = jest.fn();
  Object.assign(URL, { createObjectURL, revokeObjectURL });
  const anchorClick = jest.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});
  await render(<CodeBlock value={"hello\n\n"} language="python" streaming />);
  await click('[data-testid="code-download-btn"]');
  expect(createObjectURL.mock.calls[0][0].size).toBe(new Blob(["hello\n\n"]).size);
  expect(anchorClick.mock.instances[0].download).toBe("snippet.py");
  anchorClick.mockRestore();
});
