// Run with: node --test src/components/chat/Markdown.integration.test.mjs
// Bundle the real ESM Markdown stack because CRA's Jest 27 cannot load it.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { build } from "esbuild";

import React, { act } from "react";
import { createRoot } from "react-dom/client";

const require = createRequire(import.meta.url);
const scriptsRequire = createRequire(require.resolve("react-scripts/package.json"));
const { JSDOM } = createRequire(scriptsRequire.resolve("jest-environment-jsdom"))("jsdom");
const src = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
let Markdown;
let dom;
before(async () => {
  const result = await build({ entryPoints: [path.join(src, "components/chat/Markdown.jsx")], alias: { "@": src }, bundle: true, platform: "node", format: "cjs", write: false, external: ["react", "react-dom"], loader: { ".css": "empty" } });
  const mod = { exports: {} };
  new Function("require", "module", "exports", result.outputFiles[0].text)(require, mod, mod.exports);
  Markdown = mod.exports.default;
  dom = new JSDOM("<!doctype html><html><body></body></html>", { url: "https://example.test" });
  for (const name of ["window", "document", "navigator", "localStorage"]) Object.defineProperty(globalThis, name, { configurable: true, value: dom.window[name] });
  globalThis.IS_REACT_ACT_ENVIRONMENT = true;
});
after(() => dom.window.close());

async function checkCode(source, expected, streamFirst = false) {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  let copied;
  Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText: async (value) => { copied = value; } } });
  try {
    for (const streaming of streamFirst ? [true, false] : [false]) {
      await act(async () => root.render(React.createElement(Markdown, { streaming }, source)));
      assert.equal(container.querySelectorAll('[data-testid="code-block"]').length, 1);
      assert.equal(container.querySelector("pre code").textContent, expected);
      await act(async () => container.querySelector('[data-testid="code-copy-btn"]').click());
      assert.equal(copied, expected);
    }
  } finally {
    await act(async () => root.unmount());
    container.remove();
  }
}

test("historical closed fences retain internal CRLF and blank lines in display and clipboard", async () => {
  const payload = "const arabic = 'مرحبا';  \r\n\r\n";
  await checkCode("```unknown\r\n" + payload + "\r\n```", payload);
});

test("historical open fences preserve every received terminal newline in display and clipboard", async () => {
  for (const payload of ["first\n\n", "first\r\n\r\n", "", "\n"]) {
    await checkCode("```unknown\r\n" + payload, payload);
  }
});

test("historical open code after prose keeps literal URLs and markup characters", async () => {
  const payload = "const url = 'https://example.test/path';\n<b>raw</b>\n\n";
  await checkCode("Read https://example.test first.\n\n```unknown\n" + payload, payload);
});

test("nested fenced code keeps literal URLs and Markdown indentation behavior", async () => {
  await checkCode("> ```unknown\n> const url = 'https://example.test/path';\n> ```", "const url = 'https://example.test/path';");
  await checkCode("- ```unknown\n  const url = 'https://example.test/path';\n  ```", "const url = 'https://example.test/path';");
});

test("prose keeps GFM formatting and unsafe URLs and raw HTML stay inert", async () => {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);
  try {
    const source = "## Heading\n\n**bold** and www.example.test\n\n[bad](javascript:alert(1))\n\n<img src=x onerror=alert(1)>\n\n| a | b |\n| - | - |\n| 1 | 2 |";
    await act(async () => root.render(React.createElement(Markdown, null, source)));
    assert.equal(container.querySelector("h2").textContent, "Heading");
    assert.equal(container.querySelector("strong").textContent, "bold");
    assert.ok(container.querySelector('a[href="http://www.example.test"]'));
    assert.equal(container.querySelector("table tbody td").textContent, "1");
    assert.equal(container.querySelector('a[href^="javascript:"]'), null);
    assert.equal(container.querySelector("img"), null);
  } finally {
    await act(async () => root.unmount());
    container.remove();
  }
});

test("unfinished indented and nested fences retain terminal newlines after history reload", async () => {
  for (const streamFirst of [false, true]) {
    await checkCode("  ```unknown\n  first\n  \n", "first\n\n", streamFirst);
    await checkCode("> ```unknown\n> first\n> \n", "first\n\n", streamFirst);
  }
  await checkCode("- ```unknown\n  first\n  \n", "first\n\n");
  await checkCode("> ```unknown\r\n> first\r\n> second\r\n> \r\n", "first\r\nsecond\r\n\r\n");
});


test("unfinished indented fence-looking code stays literal while closed controls remain unchanged", async () => {
  await checkCode("```unknown\nfirst\n    ```\n", "first\n    ```\n");
  await checkCode("```unknown\nfirst\n    ```\n```\n", "first\n    ```");
  await checkCode("  ```unknown\n  first\n  ```\n", "first");
  await checkCode("> ```unknown\n> first\n> ```\n", "first");
  await checkCode("- item\n\n  ```unknown\n  first\n    ```\n", "first");
});

test("list fences render one identical code block live, done and in history", async () => {
  for (const streamFirst of [true, false]) {
    await checkCode("- ```unknown\n  first\n  ```\n", "first", streamFirst);
    await checkCode("- ```unknown\n  first\n  \n  \n", "first\n\n\n", streamFirst);
  }
});

test("shared reference definitions never enter a later unfinished nested-Markdown code block", async () => {
  const source = "[docs]: https://example.test\n\n- ```unknown\n  first\n  ```\n\nAFTER\n\nSee [docs].\n\n```unknown\nsecond\n";
  for (const variant of [source, source + "\n```\n\nAfter [docs]."]) {
    for (const initialStreaming of [true, false]) {
      const container = document.createElement("div");
      document.body.append(container);
      const root = createRoot(container);
      let copied;
      Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText: async (value) => { copied = value; } } });
      try {
        for (const streaming of initialStreaming ? [true, false] : [false]) {
          await act(async () => root.render(React.createElement(Markdown, { streaming }, variant)));
          assert.deepEqual(Array.from(container.querySelectorAll("pre code"), (code) => code.textContent), ["first", "second\n"]);
          assert.equal(container.querySelector('a[href="https://example.test"]').textContent, "docs");
          assert.equal(container.querySelectorAll('a[href="https://example.test"]').length, variant === source ? 1 : 2);
          assert.ok(container.textContent.includes("AFTER"));
          const copyButtons = container.querySelectorAll('[data-testid="code-copy-btn"]');
          await act(async () => copyButtons[1].click());
          assert.equal(copied, "second\n");
        }
      } finally {
        await act(async () => root.unmount());
        container.remove();
      }
    }
  }
});
