import React, { useCallback, useEffect, useId, useRef, useState } from "react";
import TextareaAutosize from "react-textarea-autosize";
import { ArrowUp, Atom, Globe2, Image as ImageIcon, MoreHorizontal, Paperclip, Square, Hammer } from "lucide-react";
import { useChat } from "@/context/ChatContext";
import { handleSubscriptionError, useSubscription } from "@/context/SubscriptionContext";
import { Panel, StatusNote } from "@/components/design/Primitives";
import { processFile } from "@/lib/aiClient";
import FileChip from "@/components/chat/FileChip";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";
import { registerTranslations } from "@/i18n/runtime";
import "./deepseek-composer.css";

const ACCEPTED = ".png,.jpg,.jpeg,.gif,.webp,.heic,.heif,.bmp,.svg,.pdf,.txt,.docx,.csv,.json,.zip,.py,.js,.ts,.tsx,.jsx,.html,.css,.c,.cpp,.h,.java,.php,.go,.rs,.kt,.swift,.sql,.xml,.yaml,.yml,.md";
const MAX_FILES = 8;
const MAX_BYTES = 25 * 1024 * 1024;
registerTranslations("chat", { "Enter للإرسال · Shift+Enter لسطر جديد": "Enter to send · Shift+Enter for a new line", "جارٍ الإرسال…": "Sending…", "{count} من {max} مرفقات": "{count} of {max} attachments", "جارٍ تجهيز المرفقات…": "Preparing attachments…" });

export default function ChatInput({ suggestion, controller, active = true }) {
  const nativeChat = useChat();
  const { sendMessage, isStreaming, messagesLoading, saveErrors, retrySave, stop, prefs = {}, activeChat, reasoningSupported = false, reasoningMandatory = false, setDeepThink, webSearchSupported = false, setWebSearch } = controller ? { ...nativeChat, ...controller } : nativeChat;
  const { openRenewalModal } = useSubscription();
  const { t, dir, formatNumber } = useI18n("chat");
  const [text, setText] = useState("");
  const [files, setFiles] = useState([]);
  const [dragging, setDragging] = useState(false);
  const [sending, setSending] = useState(false);
  const sendingRef = useRef(false);
  const hintId = useId();
  const fileRef = useRef(null);
  const filesRef = useRef(files);
  const dragCounter = useRef(0);
  filesRef.current = files;


  useEffect(() => {
    if (typeof suggestion === "string") setText(suggestion);
  }, [suggestion]);

  const addFiles = useCallback((list) => {
    const accepted = [];
    for (const file of Array.from(list || [])) {
      if (filesRef.current.length + accepted.length >= MAX_FILES) { toast.error(t("الحد الأقصى {count} ملفات", { count: formatNumber(MAX_FILES) })); break; }
      if (file.size > MAX_BYTES) { toast.error(t("الملف يتجاوز {size} ميجابايت", { size: formatNumber(MAX_BYTES / (1024 * 1024)) })); continue; }
      const entry = { id: Math.random().toString(36).slice(2), name: file.name, size: file.size, type: file.type, status: "uploading", text: "", kind: "", truncated: false };
      if (file.type?.startsWith("image/")) entry.previewUrl = URL.createObjectURL(file);
      accepted.push({ entry, raw: file });
    }
    if (!accepted.length) return;
    setFiles((current) => [...current, ...accepted.map(({ entry }) => entry)]);
    accepted.forEach(({ entry, raw }) => {
      processFile(raw).then((result) => {
        setFiles((current) => current.map((item) => item.id === entry.id ? { ...item, status: "ready", text: result.text || "", kind: result.kind, truncated: !!result.truncated, note: result.note } : item));
        if (result.kind === "unsupported") toast.message(t("{name}: مرفق (لا يتوفر استخراج نص)", { name: entry.name }));
        else if (result.truncated) toast.message(t("{name}: ملف كبير، تم اقتطاعه ليلائم السياق", { name: entry.name }));
      }).catch((error) => {
        setFiles((current) => current.map((item) => item.id === entry.id ? { ...item, status: "error" } : item));
        if (!handleSubscriptionError(error, { openRenewalModal })) toast.error(`${entry.name}: ${error.message || t("تعذّر رفع الملف")}`);
      });
    });
  }, [formatNumber, openRenewalModal, t]);
  const removeFile = (file) => { if (file.previewUrl) URL.revokeObjectURL(file.previewUrl); setFiles((current) => current.filter((item) => item.id !== file.id)); };
  const onSubmit = async () => {
    if (isStreaming || sendingRef.current) return;
    if (messagesLoading || activeChat?.messagesLoading || activeChat?.messagesLoaded === false) { toast.message(t("سجل المحادثة ما زال قيد التحميل — يرجى الانتظار لحظة")); return; }
    if (!text.trim() && files.length === 0) return;
    if (files.some((file) => file.status === "uploading")) { toast.message(t("الملفات ما زالت قيد المعالجة — يرجى الانتظار لحظة")); return; }
    const submittedText = text;
    const submittedFiles = files;
    sendingRef.current = true; setSending(true);
    try {
      const sent = await sendMessage(submittedText.trim(), submittedFiles);
      if (sent === false) return;
      setText((current) => current === submittedText ? "" : current);
      setFiles((current) => current.filter((file) => !submittedFiles.some((submitted) => submitted.id === file.id)));
    } catch (error) { toast.error(error.message || t("تعذّر إرسال الطلب")); }
    finally { sendingRef.current = false; setSending(false); }
  };
  const onKeyDown = (event) => { if (event.nativeEvent?.isComposing || event.keyCode === 229) return; if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); onSubmit(); } };
  useEffect(() => {
    if (!active) return undefined;
    const onDragEnter = (event) => { if (event.dataTransfer?.types?.includes("Files")) { dragCounter.current += 1; setDragging(true); } };
    const onDragLeave = () => { dragCounter.current = Math.max(0, dragCounter.current - 1); if (!dragCounter.current) setDragging(false); };
    const onDragOver = (event) => { if (event.dataTransfer?.types?.includes("Files")) event.preventDefault(); };
    const onDrop = (event) => { event.preventDefault(); dragCounter.current = 0; setDragging(false); if (event.dataTransfer?.files?.length) addFiles(event.dataTransfer.files); };
    window.addEventListener("dragenter", onDragEnter); window.addEventListener("dragleave", onDragLeave); window.addEventListener("dragover", onDragOver); window.addEventListener("drop", onDrop);
    return () => { window.removeEventListener("dragenter", onDragEnter); window.removeEventListener("dragleave", onDragLeave); window.removeEventListener("dragover", onDragOver); window.removeEventListener("drop", onDrop); };
  }, [addFiles, active]);
  const historyLoading = messagesLoading || activeChat?.messagesLoading || activeChat?.messagesLoaded === false;
  const deepThinkActive = !!prefs.deepThink || !!reasoningMandatory;
  const searchActive = !!prefs.webSearch;
  const supportsReasoning = reasoningSupported === true;
  const supportsWebSearch = webSearchSupported === true;
  const processingFiles = files.some((file) => file.status === "uploading");
  return (
    <div className="chat-input-shell deepseek-composer-shell" dir={dir}>
      {dragging && <div className="chat-drag-overlay" data-testid="drag-overlay"><div className="text-center"><ImageIcon size={38} className="mx-auto mb-2" aria-hidden="true" /><strong className="block">{t("أفلت الملفات لإرفاقها")}</strong><span className="mt-1 block text-xs">{t("صور وPDF وملفات كود وغيرها")}</span></div></div>}
      {saveErrors?.length > 0 && <div data-testid="chat-save-error"><StatusNote tone="error" className="chat-save-note"><div className="chat-save-row"><span>{saveErrors.length === 1 ? t("لم تُحفظ هذه الرسالة بعد.") : t("{count} رسائل لم تُحفظ بعد.", { count: formatNumber(saveErrors.length) })}</span><div className="chat-save-actions">{saveErrors.map((item) => <button key={item.key} onClick={() => retrySave(item.key)} className="chat-retry-button" data-testid={`retry-save-${item.key}`}>{t("إعادة المحاولة")}</button>)}</div></div></StatusNote></div>}
      {files.length > 0 && <div className="chat-file-list">{files.map((file) => <FileChip key={file.id} file={file} onRemove={removeFile} compact />)}</div>}
      {prefs.autoSuffix?.enabled && prefs.autoSuffix?.text?.trim() && <div className="chat-suffix-preview" data-testid="auto-suffix-preview"><span className="font-medium">{t("إضافة تلقائية:")}</span> {prefs.autoSuffix.text.trim()}</div>}
      <Panel className="chat-input-panel deepseek-composer" data-testid="chat-input-container">
        <TextareaAutosize minRows={1} maxRows={8} value={text} onChange={(event) => setText(event.target.value)} onKeyDown={onKeyDown} placeholder={t("اسأل أي شيء...")} dir={text ? "auto" : dir} data-testid="chat-input" className="chat-input w-full resize-none bg-transparent outline-none" aria-label={t("رسالتك")} aria-describedby={hintId} />
        <div className="chat-input-toolbar" dir="ltr">
          <div className="deepseek-composer-actions">
            <DropdownMenu><DropdownMenuTrigger asChild><button type="button" className="deepseek-more-button" data-testid="chat-tools-btn" aria-label={t("أدوات إضافية")} title={t("أدوات إضافية")}><MoreHorizontal size={18} aria-hidden="true" /></button></DropdownMenuTrigger><DropdownMenuContent forceMount align="end" sideOffset={8} className="deepseek-tools-menu" data-testid="chat-tools-menu"><div className="deepseek-tools-label">{t("أدوات المحادثة")}</div><button type="button" onClick={() => supportsReasoning && setDeepThink?.(!deepThinkActive)} disabled={!supportsReasoning} aria-pressed={deepThinkActive} data-testid="deepthink-btn" className="deepseek-composer-pill deepseek-menu-control" title={supportsReasoning ? (reasoningMandatory ? t("التفكير العميق مفروض لهذا النموذج") : t("التفكير قبل الإجابة")) : t("التفكير العميق غير مدعوم لهذا النموذج")}><Atom size={16} aria-hidden="true" /><span>{t("التفكير العميق")}</span></button><button type="button" onClick={() => supportsWebSearch && setWebSearch?.(!searchActive)} disabled={!supportsWebSearch} aria-pressed={searchActive} data-testid="web-search-btn" className="deepseek-composer-pill deepseek-menu-control" title={supportsWebSearch ? t("البحث على الويب") : t("البحث غير مهيأ على الخادم بعد؛ لن يُرسل طلب بحث وهمي")}><Globe2 size={16} aria-hidden="true" /><span>{t("البحث")}</span></button><DropdownMenuSeparator /><DropdownMenuItem onClick={() => { window.location.hash = controller ? "#chat" : "#builder"; }} data-testid="builder-mode-btn"><Hammer size={16} aria-hidden="true" /><span>{controller ? t("العودة إلى الدردشة") : "Builder"}</span></DropdownMenuItem><DropdownMenuSeparator /></DropdownMenuContent></DropdownMenu>
            <TooltipProvider delayDuration={200}><Tooltip><TooltipTrigger asChild><button type="button" onClick={() => fileRef.current?.click()} className="deepseek-attach-button" data-testid="attach-file-btn" aria-label={t("إرفاق ملف")} title={t("إرفاق ملفات")}><Paperclip size={18} aria-hidden="true" /></button></TooltipTrigger><TooltipContent side="top">{t("إرفاق ملفات")}</TooltipContent></Tooltip></TooltipProvider>
            <input ref={fileRef} type="file" multiple accept={ACCEPTED} className="deepseek-file-picker" data-testid="file-picker-input" onChange={(event) => { addFiles(event.target.files); event.target.value = ""; }} />
            {isStreaming ? <button type="button" onClick={stop} className="chat-send-button deepseek-send-button" data-testid="stop-btn" aria-label={t("إيقاف التوليد")}><Square size={15} fill="currentColor" aria-hidden="true" /></button> : <button type="button" onClick={onSubmit} disabled={sending || processingFiles || historyLoading || (!text.trim() && files.length === 0)} className="chat-send-button deepseek-send-button" data-testid="send-btn" aria-label={t(sending ? "جارٍ الإرسال…" : "إرسال الرسالة")} aria-busy={sending}><ArrowUp size={18} strokeWidth={2} aria-hidden="true" /></button>}
          </div>
        </div>
      </Panel>
      <div className="chat-composer-help" id={hintId}><span className="chat-keyboard-hint">{t("Enter للإرسال · Shift+Enter لسطر جديد")}</span>{files.length > 0 && <span role="status">{processingFiles ? t("جارٍ تجهيز المرفقات…") : t("{count} من {max} مرفقات", { count: formatNumber(files.length), max: formatNumber(MAX_FILES) })}</span>}</div>
      <div className="chat-input-note">{t("تحقّق من المعلومات المهمة قبل الاعتماد عليها.")}</div>
    </div>
  );
}
