import React, { useCallback, useEffect, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import {
  Settings as Cog, StickyNote, FileText, Plus, Trash2, Pencil, Save, X,
  UploadCloud, Download, File as FileIcon, Image as ImageIcon, Code2, Eye, EyeOff, RefreshCw, Copy, Ban,
} from "lucide-react";
import { toast } from "sonner";
import { ProjectIcon, WORKSPACE_BRAND_COLOR } from "@/components/workspace/ProjectSwitcher";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/workspace";
import { useWorkspace } from "@/context/WorkspaceContext";
import { useSubscription, handleSubscriptionError } from "@/context/SubscriptionContext";
import {
  wsListNotes, wsCreateNote, wsUpdateNote, wsDeleteNote,
  wsListFiles, wsUploadFile, wsUpdateFile, wsDeleteFile, wsFileDownloadUrl,
} from "@/lib/workspacePhase2Client";
import {
  ActionButton, EmptyState, LoadingState, Panel, StatusNote,
} from "@/components/design/Primitives";
import "./workspace-ui.css";

const isAbortError = (error) => error?.name === "AbortError" || error?.code === 20;
function humanBytes(value, formatNumber) {
  const bytes = Number(value) || 0;
  if (bytes < 1024) return `${formatNumber(bytes)} B`;
  if (bytes < 1024 * 1024) return `${formatNumber(bytes / 1024, { maximumFractionDigits: 1 })} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${formatNumber(bytes / (1024 * 1024), { maximumFractionDigits: 1 })} MB`;
  return `${formatNumber(bytes / (1024 * 1024 * 1024), { maximumFractionDigits: 1 })} GB`;
}

function InstructionsTab({ project }) {
  const { updateProject } = useWorkspace();
  const { t, formatNumber } = useI18n("workspace");
  const [text, setText] = useState(project?.instructions || "");
  const [savedText, setSavedText] = useState(project?.instructions || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // A server-side refresh should not erase local edits. It may update the
    // baseline only while the editor is still clean.
    if (text === savedText && !saving) {
      const remote = project?.instructions || "";
      setText(remote);
      setSavedText(remote);
    }
  }, [project?.instructions, project?._id, saving, savedText, text]);

  const changed = text !== savedText;
  const save = async () => {
    if (!changed || saving) return;
    const snapshot = text;
    setSaving(true);
    setError(null);
    try {
      await updateProject(project._id, { instructions: snapshot });
      setSavedText(snapshot);
      toast.success(t("تم حفظ تعليمات المشروع"));
    } catch (requestError) {
      setError(requestError?.message || "تعذر حفظ التعليمات.");
    } finally {
      setSaving(false);
    }
  };
  const copyInstructions = async () => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch { toast.error(t("تعذر نسخ التعليمات")); }
  };

  return <Panel className="workspace-settings-panel">
    <div className="workspace-section-intro">
      <p className="workspace-kicker">{t("ذاكرة ثابتة")}</p>
      <h3>{t("تعليمات المشروع")}</h3>
      <p>{t("تُضاف هذه التعليمات إلى سياق كل محادثة هنا. اكتب الهدف، النبرة، أو قواعد الكود التي لا تريد تكرارها.")}</p>
    </div>
    {error && <StatusNote tone="error">{t(error)}</StatusNote>}
    <label className="ds-field">
      <span className="sr-only">{t("تعليمات المشروع")}</span>
      <Textarea
        value={text}
        onChange={(event) => setText(event.target.value)}
        onKeyDown={(event) => { if ((event.metaKey || event.ctrlKey) && event.key === "Enter") save(); }}
        placeholder={t("مثل: أجب بالعربية، استخدم TypeScript، وكن مباشرًا.")}
        rows={10}
        maxLength={8000}
        data-testid="project-instructions-textarea"
        className="ds-textarea workspace-instructions-input"
        dir="auto"
      />
    </label>
    <div className="workspace-settings-actions">
      <span className={`workspace-dirty-state${changed ? " is-dirty" : ""}`} role="status">
        {saving ? t("جارٍ الحفظ…") : changed ? t("تغييرات غير محفوظة") : t("كل التغييرات محفوظة")}
      </span>
      <span className="workspace-character-count" dir="ltr">{formatNumber(text.length)}/{formatNumber(8000)}</span>
      <ActionButton tone="ghost" onClick={copyInstructions} disabled={!text} data-testid="copy-instructions-btn">
        <Copy aria-hidden="true" /> {copied ? t("تم النسخ") : t("نسخ")}
      </ActionButton>
      <ActionButton onClick={save} loading={saving} disabled={!changed} data-testid="save-instructions-btn">
        <Save aria-hidden="true" /> {t("حفظ التعليمات")}
      </ActionButton>
    </div>
  </Panel>;
}

function NotesTab({ project }) {
  const { t } = useI18n("workspace");
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [draft, setDraft] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editingText, setEditingText] = useState("");
  const [saving, setSaving] = useState(false);
  const requestSeq = useRef(0);
  const abortRef = useRef(null);

  const load = useCallback(async () => {
    const sequence = ++requestSeq.current;
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setLoading(true);
    setLoadError(null);
    try {
      const result = await wsListNotes(project._id, { signal: controller.signal });
      if (!controller.signal.aborted && sequence === requestSeq.current) setNotes(Array.isArray(result) ? result : []);
    } catch (error) {
      if (!isAbortError(error) && !controller.signal.aborted && sequence === requestSeq.current) setLoadError(error?.message || "تعذر تحميل الملاحظات");
    } finally {
      if (!controller.signal.aborted && sequence === requestSeq.current) setLoading(false);
    }
  }, [project._id]);
  useEffect(() => {
    load();
    return () => abortRef.current?.abort();
  }, [load]);

  const add = async () => {
    const content = draft.trim();
    if (!content || saving) return;
    setSaving(true);
    try {
      const note = await wsCreateNote(project._id, content);
      setNotes((previous) => [note, ...previous]);
      setDraft("");
      toast.success(t("تمت إضافة الملاحظة"));
    } catch (error) { toast.error(t(error?.message || "تعذر إضافة الملاحظة")); }
    finally { setSaving(false); }
  };
  const del = async (noteId) => {
    try {
      await wsDeleteNote(noteId);
      setNotes((previous) => previous.filter((note) => note._id !== noteId));
    } catch (error) { toast.error(t(error?.message || "تعذر حذف الملاحظة")); }
  };
  const saveEdit = async () => {
    const content = editingText.trim();
    if (!content || saving || !editingId) return;
    setSaving(true);
    try {
      const updated = await wsUpdateNote(editingId, content);
      setNotes((previous) => previous.map((note) => (note._id === editingId ? updated : note)));
      setEditingId(null);
      setEditingText("");
    } catch (error) { toast.error(t(error?.message || "تعذر حفظ الملاحظة")); }
    finally { setSaving(false); }
  };

  return <Panel className="workspace-settings-panel">
    <div className="workspace-section-intro">
      <p className="workspace-kicker">{t("ذاكرة قابلة للتحرير")}</p>
      <h3>{t("ملاحظات المشروع")}</h3>
      <p>{t("حقائق وتفضيلات قصيرة يتذكرها المساعد في كل محادثات المشروع.")}</p>
    </div>
    <div className="workspace-note-composer">
      <Input
        value={draft}
        onChange={(event) => setDraft(event.target.value)}
        onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); add(); } }}
        placeholder={t("مثل: استخدم TypeScript بدل JavaScript")}
        data-testid="note-input"
        maxLength={4000}
        className="ds-input"
        dir="auto"
      />
      <ActionButton onClick={add} disabled={!draft.trim() || saving} loading={saving} data-testid="add-note-btn"><Plus aria-hidden="true" /> {t("إضافة")}</ActionButton>
    </div>

    <div className="workspace-memory-list" data-testid="notes-list">
      {loading && <LoadingState label={t("جارٍ تحميل الملاحظات…")} compact />}
      {!loading && loadError && <StatusNote tone="error" onRetry={load} retryLabel={t("إعادة المحاولة")}>{t("تعذر تحميل الملاحظات: {error}", { error: t(loadError) })}</StatusNote>}
      {!loading && !loadError && notes.length === 0 && <EmptyState title={t("لا توجد ملاحظات بعد")} description={t("أضف أول حقيقة أو تفضيل تريد الاحتفاظ به.")} />}
      {!loading && !loadError && notes.map((note) => <div key={note._id} data-testid={`note-row-${note._id}`} className="workspace-memory-row">
        <StickyNote aria-hidden="true" />
        {editingId === note._id ? <>
          <Textarea
            value={editingText}
            onChange={(event) => setEditingText(event.target.value)}
            rows={3}
            className="ds-textarea"
            autoFocus
            data-testid={`note-edit-${note._id}`}
            dir="auto"
          />
          <button type="button" onClick={saveEdit} disabled={saving} data-testid={`save-note-${note._id}`} className="workspace-icon-action workspace-success-action" aria-label={t("حفظ الملاحظة")}><Save aria-hidden="true" /></button>
          <button type="button" onClick={() => { setEditingId(null); setEditingText(""); }} className="workspace-icon-action" aria-label={t("إلغاء تعديل الملاحظة")}><X aria-hidden="true" /></button>
        </> : <>
          <div className="workspace-memory-copy" dir="auto">{note.content}</div>
          <button type="button" onClick={() => { setEditingId(note._id); setEditingText(note.content); }} data-testid={`edit-note-${note._id}`} className="workspace-icon-action" aria-label={t("تعديل الملاحظة")}><Pencil aria-hidden="true" /></button>
          <button type="button" onClick={() => del(note._id)} data-testid={`delete-note-${note._id}`} className="workspace-icon-action workspace-danger-action" aria-label={t("حذف الملاحظة")}><Trash2 aria-hidden="true" /></button>
        </>}
      </div>)}
    </div>
  </Panel>;
}

function FileKindIcon({ kind }) {
  if (kind === "image") return <ImageIcon aria-hidden="true" />;
  if (kind === "pdf") return <FileText aria-hidden="true" />;
  if (kind === "docx") return <FileText aria-hidden="true" />;
  if (kind === "text") return <Code2 aria-hidden="true" />;
  return <FileIcon aria-hidden="true" />;
}

function FilesTab({ project }) {
  const { t, formatNumber } = useI18n("workspace");
  const subscription = useSubscription();
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const [preview, setPreview] = useState(null);
  const requestSeq = useRef(0);
  const loadAbortRef = useRef(null);
  const uploadAbortRef = useRef(null);

  const load = useCallback(async () => {
    const sequence = ++requestSeq.current;
    loadAbortRef.current?.abort();
    const controller = new AbortController();
    loadAbortRef.current = controller;
    setLoading(true);
    setLoadError(null);
    try {
      const result = await wsListFiles(project._id, { signal: controller.signal });
      if (!controller.signal.aborted && sequence === requestSeq.current) setFiles(Array.isArray(result) ? result : []);
    } catch (error) {
      if (!isAbortError(error) && !controller.signal.aborted && sequence === requestSeq.current) setLoadError(error?.message || "تعذر تحميل الملفات");
    } finally {
      if (!controller.signal.aborted && sequence === requestSeq.current) setLoading(false);
    }
  }, [project._id]);
  useEffect(() => {
    load();
    return () => { loadAbortRef.current?.abort(); uploadAbortRef.current?.abort(); };
  }, [load]);

  const upload = async (fileList) => {
    if (!fileList?.length || uploading) return;
    if (subscription.isExpired) { subscription.openRenewalModal(); return; }
    setUploading(true);
    uploadAbortRef.current = new AbortController();
    try {
      for (const file of fileList) {
        if (file.size > 25 * 1024 * 1024) { toast.error(t("{name} يتجاوز 25MB", { name: file.name })); continue; }
        setProgress(0);
        try {
          const doc = await wsUploadFile(project._id, file, (value) => setProgress(value), { signal: uploadAbortRef.current.signal });
          setFiles((previous) => [doc, ...previous.filter((item) => item._id !== doc?._id)]);
          toast.success(t("تم رفع {name}", { name: file.name }));
        } catch (error) {
          if (isAbortError(error)) break;
          if (!handleSubscriptionError(error, subscription)) toast.error(t(error?.message || "تعذر رفع الملف"));
        }
      }
    } finally {
      setUploading(false);
      setProgress(0);
      uploadAbortRef.current = null;
    }
  };
  const cancelUpload = () => uploadAbortRef.current?.abort();
  const onFileChange = (event) => { upload(Array.from(event.target.files || [])); event.target.value = ""; };
  const onDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setDragOver(false);
    upload(Array.from(event.dataTransfer.files || []));
  };
  const del = async (fileId) => {
    if (!window.confirm(t("حذف هذا الملف؟ لن يؤثر ذلك في الملفات الأصلية على جهازك."))) return;
    try {
      await wsDeleteFile(fileId);
      setFiles((previous) => previous.filter((file) => file._id !== fileId));
      toast.success(t("تم حذف الملف"));
    } catch (error) { toast.error(t(error?.message || "تعذر حذف الملف")); }
  };
  const toggleContext = async (file) => {
    try {
      const updated = await wsUpdateFile(file._id, { in_context: !file.in_context });
      setFiles((previous) => previous.map((item) => (item._id === file._id ? { ...item, ...updated } : item)));
    } catch (error) { toast.error(t(error?.message || "تعذر تحديث سياق الملف")); }
  };
  const rename = async (file) => {
    const name = window.prompt(t("اسم الملف الجديد:"), file.name);
    const nextName = name?.trim();
    if (!nextName || nextName === file.name) return;
    try {
      const updated = await wsUpdateFile(file._id, { name: nextName });
      setFiles((previous) => previous.map((item) => (item._id === file._id ? { ...item, ...updated } : item)));
    } catch (error) { toast.error(t(error?.message || "تعذر إعادة تسمية الملف")); }
  };

  return <Panel className="workspace-settings-panel">
    <div className="workspace-section-intro">
      <p className="workspace-kicker">{t("سياق المشروع")}</p>
      <h3>{t("ملفات المشروع")}</h3>
      <p>{t("حتى {count} ملفًا لكل مشروع، و{size} للملف الواحد. الملف المفعّل يُرفق تلقائيًا بالمحادثات.", { count: formatNumber(50), size: "25MB" })}</p>
    </div>
    <div
      onDragOver={(event) => { event.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
      data-testid="files-dropzone"
      className={`workspace-dropzone${dragOver ? " is-dragging" : ""}`}
    >
      <UploadCloud aria-hidden="true" />
      <strong>{t("اسحب الملفات إلى هنا")}</strong>
      <span>{t("أو")}</span>
      <label className="workspace-browse-link" data-testid="file-input-label">
        {t("اختر من جهازك")}
        <input type="file" multiple onChange={onFileChange} className="sr-only" data-testid="file-input" />
      </label>
      {uploading && <div className="workspace-upload-progress" role="status">
        <div className="workspace-progress-track"><div style={{ width: `${progress}%` }} /></div>
        <span dir="ltr">{t("جارٍ الرفع… {progress}%", { progress: formatNumber(progress) })}</span>
        <button type="button" onClick={cancelUpload} className="workspace-cancel-upload" data-testid="cancel-upload-btn"><Ban aria-hidden="true" /> {t("إلغاء")}</button>
      </div>}
    </div>

    <div className="workspace-memory-list workspace-files-list" data-testid="files-list">
      {loading && <LoadingState label={t("جارٍ تحميل الملفات…")} compact />}
      {!loading && loadError && <StatusNote tone="error" onRetry={load} retryLabel={t("إعادة المحاولة")}>{t("تعذر تحميل الملفات: {error}", { error: t(loadError) })}</StatusNote>}
      {!loading && !loadError && files.length === 0 && <EmptyState title={t("لا توجد ملفات بعد")} description={t("ارفع ملفًا ليصبح جزءًا من سياق هذا المشروع.")} />}
      {!loading && !loadError && files.map((file) => <div key={file._id} data-testid={`file-row-${file._id}`} className="workspace-memory-row workspace-file-row">
        <FileKindIcon kind={file.kind} />
        <div className="workspace-memory-copy" dir="auto">
          <strong>{file.name}</strong>
          <span dir="ltr">{humanBytes(file.size, formatNumber)} · {file.kind}{file.extracted_len > 0 ? t(" · {count} محرف", { count: formatNumber(Number(file.extracted_len)) }) : ""}</span>
        </div>
        <button type="button" onClick={() => toggleContext(file)} title={file.in_context ? t("مرفق بسياق المساعد") : t("مستبعد من سياق المساعد")} data-testid={`toggle-context-${file._id}`} className={`workspace-icon-action${file.in_context ? " is-context" : ""}`} aria-label={file.in_context ? t("إزالة من السياق") : t("إضافة إلى السياق")}>{file.in_context ? <Eye aria-hidden="true" /> : <EyeOff aria-hidden="true" />}</button>
        <button type="button" onClick={() => setPreview(file)} data-testid={`preview-file-${file._id}`} className="workspace-icon-action" aria-label={t("معاينة أو تنزيل الملف")}><Download aria-hidden="true" /></button>
        <button type="button" onClick={() => rename(file)} data-testid={`rename-file-${file._id}`} className="workspace-icon-action" aria-label={t("إعادة تسمية الملف")}><Pencil aria-hidden="true" /></button>
        <button type="button" onClick={() => del(file._id)} data-testid={`delete-file-${file._id}`} className="workspace-icon-action workspace-danger-action" aria-label={t("حذف الملف")}><Trash2 aria-hidden="true" /></button>
      </div>)}
    </div>
    {preview && <FilePreviewDialog file={preview} onClose={() => setPreview(null)} />}
  </Panel>;
}

function FilePreviewDialog({ file, onClose }) {
  const { t, dir, formatNumber } = useI18n("workspace");
  const [resource, setResource] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const controller = new AbortController();
    let alive = true;
    let revoke = null;
    setResource(null);
    setError(null);
    setLoading(true);
    wsFileDownloadUrl(file._id, { signal: controller.signal }).then((next) => {
      if (!alive || controller.signal.aborted) { next?.revoke?.(); return; }
      revoke = next.revoke;
      setResource(next);
      setLoading(false);
    }).catch((requestError) => {
      if (alive && !isAbortError(requestError)) { setError(requestError?.message || "تعذر تنزيل الملف"); setLoading(false); }
    });
    return () => { alive = false; controller.abort(); revoke?.(); };
  }, [file._id]);
  const url = resource?.url;
  return <Dialog open onOpenChange={(value) => !value && onClose()}>
    <DialogContent className="workspace-dialog workspace-preview-dialog" dir={dir} data-testid="file-preview-dialog">
      <DialogHeader>
        <p className="workspace-kicker">{t("معاينة آمنة")}</p>
        <DialogTitle className="workspace-dialog-title"><FileKindIcon kind={file.kind} /> <span dir="auto">{file.name}</span></DialogTitle>
        <DialogDescription className="workspace-dialog-description" dir="ltr">{humanBytes(file.size, formatNumber)} · {file.kind}</DialogDescription>
      </DialogHeader>
      <div className="workspace-preview-body">
        {loading && <LoadingState label={t("جارٍ تنزيل معاينة مؤقتة…")} />}
        {!loading && error && <StatusNote tone="error">{t(error)}</StatusNote>}
        {!loading && !error && file.kind === "image" && <img src={url} alt={file.name} className="workspace-preview-image" />}
        {!loading && !error && file.kind === "pdf" && <iframe title={t("معاينة {name}", { name: file.name })} src={url} className="workspace-preview-frame" />}
        {!loading && !error && file.kind !== "image" && file.kind !== "pdf" && <a href={url} download={file.name} className="workspace-download-link"><Download aria-hidden="true" /> {t("تنزيل الملف للعرض")}</a>}
      </div>
    </DialogContent>
  </Dialog>;
}

export default function ProjectSettingsDialog({ open, project, onClose }) {
  const { t, dir } = useI18n("workspace");
  const [tab, setTab] = useState("instructions");
  useEffect(() => { if (open) setTab("instructions"); }, [open, project?._id]);
  if (!project) return null;
  return <Dialog open={open} onOpenChange={(value) => !value && onClose()}>
    <DialogContent className="workspace-dialog workspace-settings-dialog" dir={dir} data-testid="project-settings-dialog">
      <div className="workspace-dialog-head workspace-settings-head">
        <DialogHeader>
          <p className="workspace-kicker">{t("إعدادات المشروع")}</p>
          <DialogTitle className="workspace-dialog-title">
            <span className="workspace-settings-project-icon" style={{ "--project-color": project.color || WORKSPACE_BRAND_COLOR }}><ProjectIcon name={project.icon} /></span>
            <span dir="auto">{project.name}</span>
          </DialogTitle>
          <DialogDescription className="workspace-dialog-description">{project.description || t("الذاكرة والملفات والسياق")}</DialogDescription>
        </DialogHeader>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="workspace-settings-tabs">
        <TabsList className="workspace-tabs-list">
          <TabsTrigger value="instructions" data-testid="tab-instructions"><Cog aria-hidden="true" /> {t("التعليمات")}</TabsTrigger>
          <TabsTrigger value="notes" data-testid="tab-notes"><StickyNote aria-hidden="true" /> {t("الملاحظات")}</TabsTrigger>
          <TabsTrigger value="files" data-testid="tab-files"><FileText aria-hidden="true" /> {t("الملفات")}</TabsTrigger>
        </TabsList>
        <div className="workspace-settings-content">
          <TabsContent value="instructions" className="workspace-tab-content"><InstructionsTab key={project._id} project={project} /></TabsContent>
          <TabsContent value="notes" className="workspace-tab-content"><NotesTab key={project._id} project={project} /></TabsContent>
          <TabsContent value="files" className="workspace-tab-content"><FilesTab key={project._id} project={project} /></TabsContent>
        </div>
      </Tabs>
    </DialogContent>
  </Dialog>;
}
