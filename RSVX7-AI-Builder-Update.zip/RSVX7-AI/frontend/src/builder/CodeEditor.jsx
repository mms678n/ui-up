import React, { useEffect, useId, useRef } from 'react';
import { useI18n } from '@/i18n';
import { registerTranslations } from '@/i18n/runtime';
import { Annotation, EditorState, Transaction } from '@codemirror/state';
import { EditorView, keymap, lineNumbers, highlightActiveLineGutter, highlightSpecialChars } from '@codemirror/view';
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
import { javascript } from '@codemirror/lang-javascript';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { json } from '@codemirror/lang-json';
const externalSource = Annotation.define();
registerTranslations('builder', { 'محرر الكود: {path}': 'Code editor: {path}', 'Escape ثم Tab للخروج من المحرر': 'Press Escape, then Tab to leave the editor' });
export default function CodeEditor({ path, value, onChange, disabled }) {
  const host = useRef(null), callback = useRef(onChange), view = useRef(null);
  const { t } = useI18n('builder');
  const hintId = useId();
  callback.current = onChange;
  useEffect(() => {
    const extension = /\.[jt]sx?$/.test(path) ? javascript({ jsx: true, typescript: /\.tsx?$/.test(path) }) : /\.html?$/.test(path) ? html() : /\.css$/.test(path) ? css() : /\.json$/.test(path) ? json() : [];
    const editor = new EditorView({ parent: host.current, state: EditorState.create({ doc: value, extensions: [
      lineNumbers(), highlightActiveLineGutter(), highlightSpecialChars(), history(), extension,
      keymap.of([...defaultKeymap, ...historyKeymap, indentWithTab]),
      EditorState.readOnly.of(disabled), EditorView.editable.of(!disabled),
      EditorView.contentAttributes.of({ 'aria-label': t('محرر الكود: {path}', { path }), 'aria-describedby': hintId }),
      EditorView.theme({ '&': { height: '100%', background: 'var(--background)', color: 'var(--foreground)', fontSize: '13px' }, '.cm-scroller': { fontFamily: 'ui-monospace, monospace', overflow: 'auto' }, '.cm-gutters': { background: 'var(--card)', color: 'var(--muted-foreground)', border: 'none' }, '.cm-content': { padding: '14px 0', minHeight: '100%' }, '&.cm-focused': { outline: 'none' }, '.cm-activeLineGutter': { background: 'var(--accent)' } }),
      EditorView.updateListener.of(update => { if (update.docChanged && !update.transactions.every(transaction => transaction.annotation(externalSource))) callback.current(update.state.doc.toString()); }),
    ] }) });
    view.current = editor;
    return () => { editor.destroy(); view.current = null; };
    // Recreate only when switching files or edit permissions; typing is owned by CodeMirror.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, disabled, t, hintId]);
  useEffect(() => {
    const editor = view.current;
    if (editor && value !== editor.state.doc.toString()) editor.dispatch({ changes: { from: 0, to: editor.state.doc.length, insert: value }, annotations: [externalSource.of(true), Transaction.addToHistory.of(false)] });
  }, [value]);
  return <><p className="builder-editor-keyboard-hint" id={hintId}>{t('Escape ثم Tab للخروج من المحرر')}</p><div ref={host} className="builder-code-editor" dir="ltr" data-testid="builder-code-editor" /></>;
}
