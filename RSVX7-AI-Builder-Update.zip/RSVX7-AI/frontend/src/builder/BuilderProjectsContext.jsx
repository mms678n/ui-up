import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { useAuth } from '@/context/AuthContext';

const BuilderProjectsContext = createContext(null);

export function BuilderProjectsProvider({ children }) {
  const { authFetch, user } = useAuth();
  const key = 'rsvx7_builder_active_' + (user?._id || 'anon');
  const [projects, setProjects] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const activeRef = useRef(null);
  const account = user?._id || null;
  const accountRef = useRef(account); accountRef.current = account;
  const refreshSequence = useRef(0);
  const selectionSequence = useRef(0), selectionGuard = useRef(null);
  const registerSelectionGuard = useCallback((guard) => {
    selectionGuard.current = guard;
    return () => { if (selectionGuard.current === guard) selectionGuard.current = null; };
  }, []);
  const call = useCallback(async (path = '', options = {}) => {
    const response = await authFetch('/builder/projects' + path, options);
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : 'تعذّر إكمال الطلب.');
    return result;
  }, [authFetch]);
  const commitSelection = useCallback((id) => {
    activeRef.current = id; setActiveId(id);
    try { if (id) localStorage.setItem(key, id); else localStorage.removeItem(key); } catch {}
  }, [key]);
  const select = useCallback(async (id) => {
    const sequence = ++selectionSequence.current;
    if (id !== activeRef.current && activeRef.current && selectionGuard.current && await selectionGuard.current() === false) return false;
    if (sequence !== selectionSequence.current || accountRef.current !== account) return false;
    commitSelection(id);
    return true;
  }, [account, commitSelection]);
  const refresh = useCallback(async () => {
    const sequence = ++refreshSequence.current;
    try {
      const list = await call();
      if (accountRef.current !== account || sequence !== refreshSequence.current) return null;
      setProjects(list); setLoading(false); setError('');
      return list;
    } catch (e) {
      if (accountRef.current === account && sequence === refreshSequence.current) { setLoading(false); setError(e.message); }
      throw e;
    }
  }, [call, account]);
  const invalidateRequests = useCallback(() => {
    ++refreshSequence.current;
    ++selectionSequence.current;
  }, []);
  useEffect(() => {
    let disposed = false;
    ++selectionSequence.current;
    setProjects([]); activeRef.current = null; setActiveId(null); setError('');
    if (!account) { setLoading(false); return; }
    let stored = null;
    try { stored = localStorage.getItem(key); } catch {}
    setLoading(true);
    refresh().then((list) => { if (!disposed && list) select(list.some((p) => p._id === stored) ? stored : list[0]?._id || null); }).catch(() => { if (!disposed) setLoading(false); });
    return () => { disposed = true; invalidateRequests(); };
  }, [account, key, refresh, select, invalidateRequests]);
  const create = useCallback(async (name = '') => {
    const project = await call('', { method: 'POST', body: JSON.stringify({ name }) });
    if (accountRef.current !== account) return project;
    ++refreshSequence.current;
    setProjects((prev) => [project, ...prev]); setLoading(false); setError('');
    await select(project._id);
    return project;
  }, [call, select, account]);
  const rename = useCallback(async (id, name) => {
    await call('/' + encodeURIComponent(id), { method: 'PATCH', body: JSON.stringify({ name }) });
    if (accountRef.current !== account) return;
    ++refreshSequence.current;
    setProjects((prev) => prev.map((p) => p._id === id ? { ...p, name } : p));
  }, [call, account]);
  const remove = useCallback(async (id) => {
    await call('/' + encodeURIComponent(id), { method: 'DELETE' });
    if (accountRef.current !== account) return;
    ++refreshSequence.current;
    setProjects((prev) => {
      const next = prev.filter((p) => p._id !== id);
      // Deletion is already confirmed; do not save to the deleted project.
      if (activeRef.current === id) { ++selectionSequence.current; commitSelection(next[0]?._id || null); }
      return next;
    });
  }, [call, commitSelection, account]);
  const value = useMemo(() => ({ projects, activeId, loading, error, select, create, rename, remove, refresh, registerSelectionGuard }), [projects, activeId, loading, error, select, create, rename, remove, refresh, registerSelectionGuard]);
  return <BuilderProjectsContext.Provider value={value}>{children}</BuilderProjectsContext.Provider>;
}

export const useBuilderProjects = () => useContext(BuilderProjectsContext);
