import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import BuilderWorkspace from './BuilderWorkspace';
import { createRuntime } from './runtime';
const mockFetch = jest.fn(), mockRefresh = jest.fn();
let mockProjectId, mockProjectsError;
const mockCreate = jest.fn();
const mockComposer = jest.fn();
const mockProgress = jest.fn();
const mockProgressProps = jest.fn();
const mockEditor = jest.fn();
const mockRuntime = { apply: jest.fn(), dispose: jest.fn(), stop: jest.fn(), runtime: { state: { get: () => ({phase:'idle'}) }, setAgentTasks: jest.fn(), beginTask: jest.fn(), pause: jest.fn(), restoreRepairState: jest.fn(), invalidateChecks: jest.fn() } };
jest.mock('@/context/AuthContext', () => ({ useAuth: () => ({ user: {_id:'alice'}, authFetch: mockFetch }) }));
jest.mock('./BuilderProjectsContext', () => ({ useBuilderProjects: () => ({ activeId:mockProjectId, loading:false, projects:mockProjectId?[{_id:mockProjectId,name:'Existing project'}]:[], error:mockProjectsError, refresh:mockRefresh, select:jest.fn(), create:mockCreate }) }));
jest.mock('@/context/TokensContext', () => ({ useTokens: () => ({refresh:mockRefresh}) }));
jest.mock('@/context/ChatContext', () => ({useChat: () => ({prefs:{modelId:'deepdark',deepThink:true,autoSuffix:{enabled:true,text:'Native suffix'}}})}));
jest.mock('./runtime', () => ({createRuntime: jest.fn(() => mockRuntime),readPreviewHealth:()=>undefined}));
jest.mock('./generated-widgets', () => ({BuildProgress:props=>{mockProgress(props.state);mockProgressProps(props);return null;}}));
jest.mock('./CodeEditor', () => props=>{mockEditor(props);return <pre data-testid="editor-source" data-disabled={String(props.disabled)}>{props.value}</pre>;});
jest.mock('@/components/chat/Markdown', () => ({children})=><div>{children}</div>);
jest.mock('@/components/design/ThemeSwitcher', () => ()=>null);
jest.mock('@/components/chat/ChatInput', () => ({controller})=>{mockComposer(controller);return <div><button disabled={controller.isStreaming} onClick={()=>controller.sendMessage('Build a site',[])}>Send native composer</button><button onClick={()=>controller.deactivateDarkMode()}>Disable native instruction</button><button onClick={()=>controller.stop()}>Stop native composer</button></div>;});
let node, root, state;
const response = body => ({ok:true,json:async()=>body});
beforeEach(()=>{
  global.IS_REACT_ACT_ENVIRONMENT=true; mockProjectId='p_owned'; mockProjectsError=''; jest.clearAllMocks(); mockCreate.mockResolvedValue({_id:'created'}); mockRuntime.apply.mockReset(); createRuntime.mockImplementation(() => mockRuntime); mockRefresh.mockResolvedValue(undefined);
  Object.defineProperty(window,"crypto",{configurable:true,value:{randomUUID:()=>"fixture-request-uuid"}});
  state={revision:1,files:{'/home/project/index.html':{type:'file',content:'<h1>Existing</h1>'}},messages:[],checks:[],model:'admin/chosen-model',darkMode:true};
  mockFetch.mockImplementation(async(path,options)=>{
    if(path.endsWith('/run')) return response({job:{id:'backend-job',status:'running',mode:'build'}});
    return response(state);
  });
  node=document.createElement('div');document.body.appendChild(node);root=createRoot(node);
});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});
async function mount(){await act(async()=>{root.render(<BuilderWorkspace/>);await Promise.resolve();});}
test('native composer carries site instructions while the server selects the model and wallet',async()=>{
  await mount();
  expect(node.textContent).toContain('admin/chosen-model');
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Disable native instruction').click());
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Send native composer').click());
  const call=mockFetch.mock.calls.find(([path])=>path.endsWith('/run'));
  const body=JSON.parse(call[1].body);
  expect(body).toMatchObject({revision:1,text:'Build a site',darkMode:false,personality:'deepdark',deepThink:true,autoSuffix:'Native suffix'});
  expect(body.model).toBeUndefined();expect(body.apiKey).toBeUndefined();
});
test('starting work preserves the selected preview tab and navigation does not cancel the backend job',async()=>{
  await mount();
  const tabs=node.querySelectorAll('[role=tab]');
  await act(async()=>tabs[2].click());
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Send native composer').click());
  expect(tabs[2].getAttribute('aria-selected')).toBe('true');
  await act(async()=>root.render(null));
  expect(mockRuntime.dispose).toHaveBeenCalled();
  expect(mockFetch.mock.calls.some(([path])=>path.endsWith('/cancel'))).toBe(false);
});


test('an old poll cannot replace the state of a newly accepted job', async () => {
  jest.useFakeTimers();
  try {
    await mount();
    const oldState = {...state};
    let releaseOldPoll;
    mockFetch.mockImplementationOnce(() => new Promise(resolve => { releaseOldPoll = () => resolve(response(oldState)); }));
    await act(async () => { jest.advanceTimersByTime(6000); });
    expect(releaseOldPoll).toBeDefined();
    mockFetch.mockImplementation(async (path) => {
      const job = {id:'new-job',status:'running',mode:'planning'};
      return response(path.endsWith('/run') ? {job} : {...state, job});
    });
    const send = [...node.querySelectorAll('button')].find(b => b.textContent === 'Send native composer');
    await act(async () => send.click());
    expect(send.disabled).toBe(true);
    await act(async () => releaseOldPoll());
    expect(send.disabled).toBe(true);
  } finally { jest.useRealTimers(); }
});

const questions = [
  {id:'goal', label:'ما هدف الموقع؟', options:['عرض الأعمال','بيع الخدمات'], multiple:false},
  {id:'features', label:'ما الميزات المطلوبة؟', options:['حجز مواعيد','نموذج تواصل','مدونة'], multiple:true},
];
const clickText = async text => act(async () => [...node.querySelectorAll('button')].find(b => b.textContent === text).click());
const loadQuestions = () => {
  sessionStorage.clear();
  const plan = {kind:'questions', message:'', questions};
  state = {...state, files:{}, plan, proposalId:'questions-one', messages:[{id:'questions-one',role:'assistant',content:'',plan}]};
};
test('all answers and multiple feature choices are sent once only after explicit submission', async () => {
  loadQuestions(); await mount();
  await clickText('عرض الأعمال');
  await clickText('حجز مواعيد');
  await clickText('نموذج تواصل');
  expect(mockFetch.mock.calls.filter(([path]) => path.endsWith('/run'))).toHaveLength(0);
  expect(node.querySelectorAll('[aria-pressed=true]')).toHaveLength(3);
  await clickText('إرسال الإجابات');
  const calls = mockFetch.mock.calls.filter(([path]) => path.endsWith('/run'));
  expect(calls).toHaveLength(1);
  expect(JSON.parse(calls[0][1].body)).toMatchObject({action:'answers',questionMessageId:'questions-one',answers:[
    {id:'goal',options:['عرض الأعمال'],text:''},
    {id:'features',options:['حجز مواعيد','نموذج تواصل'],text:''},
  ]});
});
test('answers are editable before sending and remain after a failed request and remount', async () => {
  loadQuestions(); await mount();
  await clickText('عرض الأعمال'); await clickText('بيع الخدمات');
  await clickText('حجز مواعيد'); await clickText('حجز مواعيد'); await clickText('مدونة');
  mockFetch.mockImplementation(async path => path.endsWith('/run') ? {ok:false,json:async()=>({detail:'connection failed'})} : response(state));
  await clickText('إرسال الإجابات');
  expect(node.textContent).toContain('connection failed');
  expect([...node.querySelectorAll('[aria-pressed=true]')].map(b=>b.textContent)).toEqual(['بيع الخدمات','مدونة']);
  await act(async () => root.render(null));
  await mount();
  expect([...node.querySelectorAll('[aria-pressed=true]')].map(b=>b.textContent)).toEqual(['بيع الخدمات','مدونة']);
});
test('an old question card is locked when a newer proposal replaces it', async () => {
  loadQuestions(); state.plan = {kind:'reply',message:'Ready'}; state.proposalId='new-plan';
  await mount();
  expect(node.querySelector('fieldset').disabled).toBe(true);
  expect(node.textContent).not.toContain('إرسال الإجابات');
});
test('retry calls the server retry action without resending the user answer', async () => {
  loadQuestions(); state.job={id:'failed',status:'failed',mode:'planning',error:'Planning failed'};
  await mount(); await clickText('إعادة المحاولة');
  const call=mockFetch.mock.calls.find(([path])=>path.endsWith('/run'));
  expect(JSON.parse(call[1].body)).toMatchObject({action:'retry',text:''});
});

test('an ambiguous network failure retries the same request ID without another turn', async () => {
  loadQuestions(); await mount();
  let id = 0;
  window.crypto.randomUUID = () => 'fixture-request-' + ++id;
  await clickText('عرض الأعمال'); await clickText('حجز مواعيد');
  mockFetch.mockImplementation(async (path) => {
    if (path.endsWith('/run')) throw new Error('Connection interrupted');
    return response(state);
  });
  await clickText('إرسال الإجابات'); await clickText('إرسال الإجابات');
  const calls = mockFetch.mock.calls.filter(([path]) => path.endsWith('/run')).map(([,options]) => JSON.parse(options.body));
  expect(calls).toHaveLength(2);
  expect(calls[0].requestId).toBe(calls[1].requestId);
  expect(id).toBe(1);
});

test('retry of a failed code repair preserves the runtime repair workflow', async () => {
  state.job = {id:'failed-repair',status:'failed',mode:'build',error:'Connection interrupted',request:{action:'repair'}};
  await mount();
  mockFetch.mockImplementation(async path => {
    const job = {id:'retry-repair',status:'running',mode:'build',request:{action:'repair'}};
    return response(path.endsWith('/run') ? {job} : {...state,job});
  });
  await clickText('إعادة المحاولة');
  expect(mockRuntime.runtime.beginTask).toHaveBeenLastCalledWith(true, true);
});

test.each(['DF_CHAT_ERROR:{"code":"agent_format"}','لم يرسل أحد الوكلاء ملفات أو تقريرًا صالحًا. أعد المحاولة أو اختر نموذجًا آخر.','تعذّر قراءة مخرجات البرمجة أو المراجعة. ملفاتك السابقة محفوظة؛ أعد المحاولة.'])('stored protocol failure %s uses the current readable error',async error=>{
  state.job={id:'old-failure',status:'failed',mode:'build',error};
  await mount();
  expect(node.textContent).not.toContain('DF_CHAT_ERROR');
  expect(node.textContent).not.toContain('لم يرسل أحد الوكلاء');
  expect(node.textContent).toContain('لم يرجع النموذج ملفات مكتملة');
  expect(mockRuntime.runtime.pause).toHaveBeenCalledWith(expect.stringContaining('لم يرجع النموذج ملفات مكتملة'));
});


test('a completed job can request automatic runtime repair before React rerenders busy state', async () => {
  jest.useFakeTimers();
  try {
    state.approvedPlan={kind:'proposal',title:'Fixture'};
    state.job={id:'working',mode:'build',status:'running'};
    await mount();
    const repair=createRuntime.mock.calls[0][1];
    mockRuntime.apply.mockImplementationOnce(()=>{repair({prompt:'Fix the actual failed validation test in client.js'});return Promise.resolve();});
    state={...state,revision:2,job:{id:'working',mode:'build',status:'completed'}};
    await act(async()=>{jest.advanceTimersByTime(1500);await Promise.resolve();});
    const request=mockFetch.mock.calls.find(([path])=>path.endsWith('/run'));
    expect(request).toBeDefined();
    expect(JSON.parse(request[1].body)).toMatchObject({action:'repair',text:'Fix the actual failed validation test in client.js',revision:2});
  }finally{jest.useRealTimers();}
});

test('a disposed workspace cannot send a delayed repair into another session', async () => {
  state.approvedPlan={kind:'proposal',title:'Fixture'};
  await mount();
  const repair=createRuntime.mock.calls[0][1];
  await act(async()=>root.render(null));
  await act(async()=>repair({prompt:'Old project failure'}));
  expect(mockFetch.mock.calls.some(([path])=>path.endsWith('/run'))).toBe(false);
});

test('a running server job displays its actual file and stream progress before final files exist',async()=>{
  state={...state,files:{},job:{id:'live-job',status:'running',mode:'build',model:'synthetic/frozen-model',startedAt:'2026-10-20T00:00:00Z',generation:{files:4,batches:2},modelCall:{phase:'receiving',number:3,chars:900,reasoningChars:0}}};
  await mount();
  expect(mockProgress.mock.calls.at(-1)[0]).toMatchObject({phase:'writing',files:4,generation:{chars:900,calls:3,batches:2}});
  expect(mockRuntime.apply).not.toHaveBeenCalled();
  expect(node.querySelector('[data-testid=builder-model-label]').textContent).toBe('synthetic/frozen-model');
});

test('running draft files appear read-only without replacing or executing committed source', async () => {
  state.job={id:'draft',status:'running',mode:'build',pipeline:{stage:'writing',completed:1,total:2},draftFiles:{'/home/project/src/App.jsx':{type:'file',content:'export default () => <h1>Draft</h1>'}}};
  await mount();
  expect(node.querySelector('[data-testid=builder-file-src-App-jsx]')).not.toBeNull();
  expect(node.querySelector('[data-testid=editor-source]').textContent).toContain('<h1>Draft</h1>');
  expect(node.querySelector('[data-testid=editor-source]').dataset.disabled).toBe('true');
  expect(mockRuntime.apply).not.toHaveBeenCalled();
  expect(state.files['/home/project/index.html'].content).toBe('<h1>Existing</h1>');
});

test('persisted automatic repair attempts are restored before committed files are verified', async () => {
  state.repairState={automaticAttempts:2,fingerprints:['persisted-failure']};
  await mount();
  expect(mockRuntime.runtime.restoreRepairState).toHaveBeenCalledWith(state.repairState);
  expect(mockRuntime.apply).toHaveBeenCalledWith(state.files,false,state.repairState);
  expect(mockRuntime.runtime.restoreRepairState.mock.invocationCallOrder[0]).toBeLessThan(mockRuntime.apply.mock.invocationCallOrder[0]);
});

test('saving an explicit source edit resets the repair budget before verifying that revision', async () => {
  state.repairState={automaticAttempts:2,fingerprints:['old-source-failure']};
  await mount();
  await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('<h1>Edited source</h1>'));
  mockFetch.mockImplementation(async path=>path.endsWith('/files')?response({revision:2}):response(state));
  await act(async()=>node.querySelector('[data-testid=builder-run-checks-btn]').click());
  expect(mockRuntime.apply.mock.calls.at(-1)).toEqual([
    {'/home/project/index.html':{type:'file',content:'<h1>Edited source</h1>'}},false,{automaticAttempts:0,fingerprints:[]},
  ]);
});

test('a rejected automatic repair carries the real diagnostic and visibly pauses', async () => {
  state.approvedPlan={kind:'proposal',title:'Fixture'};
  await mount();
  mockFetch.mockImplementation(async path=>path.endsWith('/run')?{ok:false,json:async()=>({detail:'Automatic repair limit reached'})}:response(state));
  await act(async()=>createRuntime.mock.calls[0][1]({prompt:'Fix failed test',step:'tests',diagnostic:'src/App.jsx:7 expected a button',automatic:true,affectedFiles:['/home/project/src/App.jsx']}));
  const request=mockFetch.mock.calls.find(([path])=>path.endsWith('/run'));
  expect(JSON.parse(request[1].body).repairContext).toEqual({step:'tests',diagnostic:'src/App.jsx:7 expected a button',automatic:true,affectedFiles:['/home/project/src/App.jsx']});
  expect(mockRuntime.runtime.pause).toHaveBeenLastCalledWith('Automatic repair limit reached');
  expect(node.querySelector('[data-testid=builder-error]').textContent).toContain('Automatic repair limit reached');
});

test('Stop waits for pending run acceptance and then cancels that accepted job', async () => {
  state.files={};await mount();
  let accept;
  mockFetch.mockImplementation(async path=>{
    if(path.endsWith('/run'))return new Promise(resolve=>{accept=()=>{state={...state,job:{id:'late-accepted',status:'running',mode:'build'}};resolve(response({job:state.job}));};});
    if(path.endsWith('/cancel')){state={...state,job:{...state.job,status:'cancelled'}};return response({});}
    return response(state);
  });
  await clickText('Send native composer');
  await clickText('Stop native composer');
  expect(mockFetch.mock.calls.some(([path])=>path.endsWith('/cancel'))).toBe(false);
  await act(async()=>{accept();await Promise.resolve();});
  expect(mockFetch.mock.calls.filter(([path])=>path.endsWith('/cancel'))).toHaveLength(1);
  expect(state.job.status).toBe('cancelled');
});

test('an accepted job can be stopped while its optional state refresh is still pending', async () => {
  state.files={};await mount();
  mockFetch.mockImplementation(async path=>{
    if(path.endsWith('/run'))return response({job:{id:'accepted',status:'running',mode:'build'}});
    if(path.endsWith('/cancel'))return response({ok:true});
    return new Promise(()=>{});
  });
  await clickText('Send native composer');
  await clickText('Stop native composer');
  expect(mockFetch.mock.calls.filter(([path])=>path.endsWith('/cancel'))).toHaveLength(1);
});

test('a nonrepairable browser failure does not offer an inert model repair action', async () => {
  state.files={};
  mockRuntime.runtime.canRequestRepair=false;
  mockRuntime.runtime.canRetryRepair=false;
  createRuntime.mockImplementation(onState=>{
    onState({phase:'failed',files:0,checks:[],attempt:0,failureKind:'environment'});
    return mockRuntime;
  });
  await mount();
  expect(mockProgressProps.mock.calls.at(-1)[0].onRepair).toBeUndefined();
});

test('source typed while a save is pending stays unsaved until that source is persisted', async () => {
  await mount();
  await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('<h1>First edit</h1>'));
  const saves=[];
  mockFetch.mockImplementation(async(path,options)=>{
    if(path.endsWith('/files'))return new Promise(resolve=>saves.push({body:JSON.parse(options.body),resolve}));
    return response(state);
  });
  await act(async()=>node.querySelector('[data-testid=builder-save-btn]').click());
  expect(saves).toHaveLength(1);
  await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('<h1>Later edit</h1>'));
  await act(async()=>saves[0].resolve(response({revision:2})));
  expect(node.textContent).toContain('تعديلات غير محفوظة');
  await act(async()=>node.querySelector('[data-testid=builder-save-btn]').click());
  expect(saves).toHaveLength(2);
  expect(saves[1].body).toMatchObject({revision:2,files:{'/home/project/index.html':{content:'<h1>Later edit</h1>'}}});
  await act(async()=>saves[1].resolve(response({revision:3})));
  expect(node.textContent).not.toContain('تعديلات غير محفوظة');
});

test('a poll started before a source save cannot roll back the saved revision', async () => {
  jest.useFakeTimers();
  try {
    await mount();
    const oldState={...state};delete oldState.files;
    let releasePoll;
    mockFetch.mockImplementationOnce(()=>new Promise(resolve=>{releasePoll=()=>resolve(response(oldState));}));
    await act(async()=>jest.advanceTimersByTime(6000));
    await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('First save'));
    mockFetch.mockImplementation(async path=>path.endsWith('/files')?response({revision:2}):response(state));
    await act(async()=>node.querySelector('[data-testid=builder-save-btn]').click());
    await act(async()=>releasePoll());
    await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('Second save'));
    await act(async()=>node.querySelector('[data-testid=builder-save-btn]').click());
    const saves=mockFetch.mock.calls.filter(([path])=>path.endsWith('/files'));
    expect(JSON.parse(saves[1][1].body).revision).toBe(2);
  } finally {jest.useRealTimers();}
});

test('finishing Stop after switching projects cannot load the previous project into the new one', async () => {
  await mount();
  let releaseCancel;
  const oldState={...state,files:{'/home/project/index.html':{type:'file',content:'Old project source'}}};
  const newState={...state,files:{'/home/project/new.html':{type:'file',content:'New project source'}}};
  mockFetch.mockImplementation(async path=>{
    if(path.endsWith('/cancel'))return new Promise(resolve=>{releaseCancel=()=>resolve(response({ok:true}));});
    return response(path.includes('/p_other')?newState:oldState);
  });
  await clickText('Stop native composer');
  mockProjectId='p_other';await mount();
  expect(node.querySelector('[data-testid=editor-source]').textContent).toBe('New project source');
  await act(async()=>releaseCancel());
  expect(node.querySelector('[data-testid=editor-source]').textContent).toBe('New project source');
});

test('oversized text plus reference files is rejected locally with a readable size limit', async () => {
  await mount();
  let accepted;
  await act(async()=>{accepted=await mockComposer.mock.calls.at(-1)[0].sendMessage('Build this', [{name:'large.txt',status:'ready',text:'x'.repeat(20000)}]);});
  expect(accepted).toBe(false);
  expect(mockFetch.mock.calls.some(([path])=>path.endsWith('/run'))).toBe(false);
  expect(node.querySelector('[data-testid=builder-error]').textContent).toContain('20000');
});

test('a failed project list offers a retry without silently creating a replacement project',async()=>{
  mockProjectId=null;mockProjectsError='Project list is unavailable';
  await mount();
  expect(mockCreate).not.toHaveBeenCalled();
  expect(node.querySelector('[data-testid=builder-error]').textContent).toContain('Project list is unavailable');
  await act(async()=>node.querySelector('[data-testid=builder-retry-btn]').click());
  expect(mockRefresh).toHaveBeenCalled();
});

test('a source save completed after a project change cannot show an error in the new project',async()=>{
  await mount();
  await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('Old project edit'));
  let completeSave;
  mockFetch.mockImplementation(async path=>path.endsWith('/files')?new Promise(resolve=>{completeSave=()=>resolve(response({revision:2}));}):response(state));
  await act(async()=>node.querySelector('[data-testid=builder-save-btn]').click());
  mockProjectId='p_other';state={...state,files:{'/home/project/new.html':{type:'file',content:'Current source'}}};await mount();
  await act(async()=>completeSave());
  expect(node.querySelector('[data-testid=builder-error]')).toBeNull();
  expect(node.querySelector('[data-testid=editor-source]').textContent).toBe('Current source');
});
