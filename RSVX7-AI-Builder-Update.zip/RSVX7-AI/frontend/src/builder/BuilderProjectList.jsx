import React, { useState } from 'react';
import { Code2, MoreHorizontal, Pencil, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useI18n } from '@/i18n';
import { registerTranslations } from '@/i18n/runtime';
import { useBuilderProjects } from './BuilderProjectsContext';

registerTranslations('builder-projects', { 'مشاريع Builder': 'Builder projects', 'لا توجد مشاريع بعد': 'No projects yet', 'إعادة التسمية': 'Rename', 'حذف': 'Delete', 'تم حذف المشروع': 'Project deleted', 'اسم المشروع': 'Project name', 'إجراءات المشروع': 'Project actions', 'ملف': 'files', 'جارٍ العمل': 'Working', 'حذف المشروع «{name}» وكل ملفاته؟': 'Delete project “{name}” and all its files?' });

function ProjectRow({ project, active, onOpen }) {
  const { t } = useI18n('builder-projects');
  const { rename, remove } = useBuilderProjects();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(project.name);
  const finish = () => {
    setEditing(false);
    const next = name.trim();
    if (next && next !== project.name) rename(project._id, next).catch((e) => { toast.error(e.message); setName(project.name); });
    else setName(project.name);
  };
  const onDelete = () => window.confirm(t('حذف المشروع «{name}» وكل ملفاته؟', { name: project.name })) && remove(project._id).then(() => toast.success(t('تم حذف المشروع'))).catch((e) => toast.error(e.message));
  return <div onClick={() => !editing && onOpen(project._id)} onKeyDown={(e) => { if (e.key === 'Enter' && !editing) onOpen(project._id); }} role="button" tabIndex={0} className={`chat-row builder-project-row ${active ? 'is-active' : ''}`} data-testid={`builder-project-row-${project._id}`}>
    <Code2 size={16} aria-hidden="true" />
    {editing ? <input autoFocus value={name} onChange={(e) => setName(e.target.value)} onBlur={finish} onClick={(e) => e.stopPropagation()} onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); if (e.key === 'Escape') { setName(project.name); setEditing(false); } }} className="chat-row-edit" aria-label={t('اسم المشروع')} data-testid={`builder-project-rename-input-${project._id}`} /> : <span className="chat-row-title" dir="auto">{project.name}</span>}
    {project.status === 'running' ? <span className="chat-model-tag builder-project-tag is-running">{t('جارٍ العمل')}</span> : project.file_count > 0 && <span className="chat-model-tag builder-project-tag" dir="ltr">{project.file_count} {t('ملف')}</span>}
    <div className="chat-row-actions">
      <DropdownMenu>
        <DropdownMenuTrigger asChild><button onClick={(e) => e.stopPropagation()} className="chat-row-action" aria-label={t('إجراءات المشروع')} data-testid={`builder-project-menu-${project._id}`}><MoreHorizontal size={17} aria-hidden="true" /></button></DropdownMenuTrigger>
        <DropdownMenuContent align="end" onCloseAutoFocus={(e) => e.preventDefault()} className="chat-popover chat-context-menu w-48 text-white">
          <DropdownMenuItem onClick={() => setEditing(true)} data-testid={`builder-project-rename-${project._id}`}><Pencil size={15} />{t('إعادة التسمية')}</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onDelete} className="text-red-300 focus:text-red-200" data-testid={`builder-project-delete-${project._id}`}><Trash2 size={15} />{t('حذف')}</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  </div>;
}

export default function BuilderProjectList({ query = '', onOpened }) {
  const { t } = useI18n('builder-projects');
  const { projects, activeId, loading, select } = useBuilderProjects();
  const normalized = query.trim().toLowerCase();
  const visible = projects.filter((p) => !normalized || p.name.toLowerCase().includes(normalized));
  const open = async (id) => { try { if (await select(id) !== false) onOpened?.(); } catch (e) { toast.error(e.message); } };
  return <div data-testid="builder-project-list">
    <div className="chat-section-label">{t('مشاريع Builder')}</div>
    {loading && !projects.length ? <div className="chat-loading-skeleton">{[1, 2, 3].map((i) => <div key={i} />)}</div>
      : visible.length === 0 ? <div className="chat-empty-history"><Code2 size={19} aria-hidden="true" />{t('لا توجد مشاريع بعد')}</div>
      : visible.map((p) => <ProjectRow key={p._id} project={p} active={p._id === activeId} onOpen={open} />)}
  </div>;
}
