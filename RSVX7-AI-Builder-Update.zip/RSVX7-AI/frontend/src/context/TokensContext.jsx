import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { formatNumber } from "@/i18n";

// Live token balance for the current user. The context intentionally has no
// interval: balance changes are driven by a completed stream usage event or a
// user focus event (throttled to avoid a burst of duplicate requests).
const Ctx = createContext(null);
const BACKEND = process.env.REACT_APP_BACKEND_URL || "";
const FOCUS_REFRESH_WINDOW = 30_000;

async function fetchBalance(signal) {
  const token = localStorage.getItem("rsvx7_token") || "";
  const response = await fetch(`${BACKEND}/api/billing/balance`, {
    credentials: "include",
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    signal,
  });
  if (!response.ok) throw new Error("balance fetch failed");
  return response.json();
}

export function TokensProvider({ children }) {
  const { user } = useAuth();
  const uid = user?._id || user?.id || null;
  const uidRef = useRef(uid);
  const requestRef = useRef(null);
  const balanceRef = useRef(null);
  const lastRefreshRef = useRef(0);
  uidRef.current = uid;

  const [balance, setBalance] = useState(null);
  const [lastUsage, setLastUsage] = useState(null); // {input, output, total, remaining}
  const [loading, setLoading] = useState(Boolean(uid));

  useEffect(() => { balanceRef.current = balance; }, [balance]);

  // `force` defaults to true to preserve the old imperative refresh contract.
  // Focus refresh passes false so repeated focus events within 30 seconds do
  // not create a request storm. A request already in flight is always shared.
  const refresh = useCallback(async ({ force = true } = {}) => {
    const requestedUid = uid;
    if (!requestedUid) {
      requestRef.current?.controller.abort();
      requestRef.current = null;
      setBalance(null);
      setLoading(false);
      return null;
    }

    const active = requestRef.current;
    if (active?.uid === requestedUid) return active.promise;
    if (!force && Date.now() - lastRefreshRef.current < FOCUS_REFRESH_WINDOW) {
      return balanceRef.current;
    }

    const controller = new AbortController();
    setLoading(true);
    const promise = fetchBalance(controller.signal)
      .then((next) => {
        if (!controller.signal.aborted && uidRef.current === requestedUid) {
          balanceRef.current = next;
          setBalance(next);
          lastRefreshRef.current = Date.now();
        }
        return next;
      })
      .catch((error) => {
        // Keep the last known good balance during a transient failure. Abort
        // and user changes are expected control flow, not visible errors.
        if (error?.name === "AbortError") return null;
        return null;
      })
      .finally(() => {
        if (requestRef.current?.promise === promise) requestRef.current = null;
        if (uidRef.current === requestedUid) setLoading(false);
      });

    requestRef.current = { uid: requestedUid, controller, promise };
    return promise;
  }, [uid]);

  useEffect(() => {
    // Never expose the previous account's balance while the next account is
    // loading, and cancel any request owned by the previous account.
    requestRef.current?.controller.abort();
    requestRef.current = null;
    balanceRef.current = null;
    lastRefreshRef.current = 0;
    setBalance(null);
    setLastUsage(null);
    setLoading(Boolean(uid));
    if (uid) void refresh({ force: true });

    return () => {
      requestRef.current?.controller.abort();
      requestRef.current = null;
    };
  }, [uid, refresh]);

  useEffect(() => {
    if (!uid) return undefined;
    const onFocus = () => { void refresh({ force: false }); };
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [uid, refresh]);

  // Called by the chat stream when it receives the `usage` SSE event. Apply
  // the server-provided remaining amount immediately, then refresh cumulative
  // counters from Mongo with a shared, forced request.
  const applyUsage = useCallback((usage) => {
    if (!uid || uidRef.current !== uid) return;
    setLastUsage(usage);
    if (usage?.remaining !== undefined && usage.remaining >= 0) {
      setBalance((previous) => {
        const next = previous ? { ...previous, token_balance: usage.remaining } : previous;
        balanceRef.current = next;
        return next;
      });
    }
    void refresh({ force: true });
  }, [uid, refresh]);

  const value = {
    balance,
    lastUsage,
    loading,
    refresh,
    applyUsage,
    isUnlimited: !!balance?.unlimited,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useTokens = () => {
  const context = useContext(Ctx);
  if (!context) throw new Error("useTokens must be used within TokensProvider");
  return context;
};

// Human-friendly token formatter — mirrors DeepSeek's "4,218,442" style.
export function formatTokens(value) {
  if (value === -1 || value === null || value === undefined) return "∞";
  if (typeof value !== "number") return String(value);
  return formatNumber(value);
}
