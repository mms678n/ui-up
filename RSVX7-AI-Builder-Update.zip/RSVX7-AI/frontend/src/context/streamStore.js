/**
 * External source of truth for the one assistant message currently streaming.
 *
 * `push` is deliberately cheap: it only replaces a pending cumulative string
 * and schedules one animation frame. Subscribers are notified once per frame,
 * never once per network token. `getSnapshot` still exposes the latest pending
 * cumulative value synchronously, which keeps the old public contract intact
 * for callers that read immediately after `push` while React gets a single
 * stable notification per frame through `useSyncExternalStore`. Each frame
 * publishes all received text without an artificial typing delay. Terminal flushes are immediate.
 *
 * The regular ChatContext state is committed once at stream termination. The
 * external store is then flushed and stopped, so a hidden tab or an aborted
 * reader cannot leave a queued frame or an active stream behind.
 */

let currentId = null;
let pendingBuffer = "";
let publishedBuffer = "";
let pendingReasoning = "";
let publishedReasoning = "";
let generation = 0;
let frameHandle = null;
let frameKind = null;
const listeners = new Set();

// Rolling window of text-delta SSE timestamps, not TCP/read() chunks or tokens.
// Kept small so getRate() stays constant-cost for normal streams.
let chunkTimes = [];
let workload = { starts: 0, pushes: 0, frames: 0, notifications: 0, chunks: 0 };

const now = () => (typeof performance !== "undefined" && typeof performance.now === "function"
  ? performance.now() : Date.now());

const emit = () => {
  workload.notifications += 1;
  for (const listener of listeners) listener();
};

const cancelFrame = () => {
  if (frameHandle == null) return;
  if (frameKind === "raf" && typeof cancelAnimationFrame === "function") {
    cancelAnimationFrame(frameHandle);
  } else {
    clearTimeout(frameHandle);
  }
  frameHandle = null;
  frameKind = null;
};

const publish = (expectedId = null, expectedGeneration = generation, immediate = true) => {
  if ((expectedId && currentId !== expectedId) || expectedGeneration !== generation || !currentId) return false;
  if (pendingBuffer === publishedBuffer && pendingReasoning === publishedReasoning) return false;
  // Publish the complete received value once per frame, without a typing queue.
  publishedBuffer = pendingBuffer;
  publishedReasoning = pendingReasoning;
  workload.frames += 1;
  emit();
  return true;
};

const scheduleFrame = () => {
  if (frameHandle != null || !currentId) return;
  const scheduledGeneration = generation;
  if (typeof requestAnimationFrame === "function") {
    frameKind = "raf";
    frameHandle = requestAnimationFrame(() => {
      if (scheduledGeneration !== generation) return;
      frameHandle = null;
      frameKind = null;
      publish(currentId, scheduledGeneration, false);
      if (scheduledGeneration === generation && (pendingBuffer !== publishedBuffer || pendingReasoning !== publishedReasoning)) scheduleFrame();
    });
  } else {
    frameKind = "timeout";
    frameHandle = setTimeout(() => {
      if (scheduledGeneration !== generation) return;
      frameHandle = null;
      frameKind = null;
      publish(currentId, scheduledGeneration, false);
      if (scheduledGeneration === generation && (pendingBuffer !== publishedBuffer || pendingReasoning !== publishedReasoning)) scheduleFrame();
    }, 16);
  }
};

export const streamStore = {
  start(msgId) {
    cancelFrame();
    currentId = msgId;
    generation += 1;
    pendingBuffer = "";
    publishedBuffer = "";
    pendingReasoning = "";
    publishedReasoning = "";
    chunkTimes = [];
    workload.starts += 1;
    emit();
  },

  push(text) {
    if (!currentId) return false;
    const next = typeof text === "string" ? text : String(text ?? "");
    // Grow-only writes are normal, but replacement is supported for continue
    // mode where overlap de-duplication can legitimately shrink one update.
    if (next === pendingBuffer) return false;
    pendingBuffer = next;
    workload.pushes += 1;
    scheduleFrame();
    return true;
  },

  pushReasoning(text) {
    if (!currentId) return false;
    const next = typeof text === "string" ? text : String(text ?? "");
    if (next === pendingReasoning) return false;
    pendingReasoning = next;
    scheduleFrame();
    return true;
  },

  /** Publish both channels now (used for terminal events and visibility). */
  flush(expectedId = null) {
    if (expectedId && currentId !== expectedId) return false;
    cancelFrame();
    return publish(expectedId, generation);
  },

  /** Record ONE text SSE event; retained name for client compatibility. */
  recordChunk() {
    chunkTimes.push(now());
    workload.chunks += 1;
    if (chunkTimes.length > 40) chunkTimes.shift();
  },

  /** Text SSE events/sec over the most recent one-second window. */
  getRate() {
    if (!chunkTimes.length) return 0;
    const cutoff = now() - 1000;
    let count = 0;
    for (let i = chunkTimes.length - 1; i >= 0; i -= 1) {
      if (chunkTimes[i] < cutoff) break;
      count += 1;
    }
    return count;
  },

  // Passing an expected id makes delayed cleanup from an old run harmless.
  // The no-argument form remains compatible with existing callers.
  stop(expectedId = null) {
    if (expectedId && currentId !== expectedId) return false;
    const hadState = currentId !== null || pendingBuffer !== "" || publishedBuffer !== "" || pendingReasoning !== "";
    cancelFrame();
    currentId = null;
    pendingBuffer = "";
    publishedBuffer = "";
    pendingReasoning = "";
    publishedReasoning = "";
    chunkTimes = [];
    if (hadState) emit();
    return hadState;
  },

  getActiveId() { return currentId; },
  getGeneration() { return generation; },

  /** Lightweight instrumentation for synthetic stream/chunk workload tests. */
  getMetrics() {
    return {
      ...workload,
      activeId: currentId,
      pendingLength: pendingBuffer.length,
      publishedLength: publishedBuffer.length,
      rate: this.getRate(),
    };
  },
  resetMetrics() {
    workload = { starts: 0, pushes: 0, frames: 0, notifications: 0, chunks: 0 };
  },

  subscribe(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },

  // The pending string is immutable and therefore stable between pushes.
  getSnapshot(msgId) {
    return msgId === currentId ? pendingBuffer : null;
  },
  /** React reads only the frame-published value; persistence reads pending. */
  getPublishedSnapshot(msgId) {
    return msgId === currentId ? publishedBuffer : null;
  },
  getReasoningSnapshot(msgId) {
    return msgId === currentId ? pendingReasoning : null;
  },
  getPublishedReasoningSnapshot(msgId) {
    return msgId === currentId ? publishedReasoning : null;
  },
};
