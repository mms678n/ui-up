import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { ActionButton, AuthShell, Panel, StatusNote } from "@/components/design/Primitives";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/auth";
import "@/components/auth-ui.css";

function PasswordField({ id, value, onChange, autoComplete, testId, label = "كلمة المرور", onRecover }) {
  const { t } = useI18n("auth");
  const [visible, setVisible] = useState(false);
  return (
    <div className="ds-field auth-ui-field">
      <div className="auth-ui-password-label"><label className="auth-ui-label" htmlFor={id}>{t(label)}</label>{onRecover && <button type="button" onClick={onRecover} className="auth-ui-link" data-testid="link-recover">{t("نسيت كلمة المرور؟")}</button>}</div>
      <div className="auth-ui-input-wrap has-toggle">
        <input
          id={id}
          data-testid={testId}
          className="ds-input auth-ui-input"
          placeholder={t(label)}
          type={visible ? "text" : "password"}
          value={value}
          onChange={onChange}
          autoComplete={autoComplete}
          required
          minLength={6}
        />
        <button
          type="button"
          className="auth-ui-toggle"
          onClick={() => setVisible((current) => !current)}
          aria-label={visible ? t("إخفاء كلمة المرور") : t("إظهار كلمة المرور")}
          aria-pressed={visible}
          data-testid={`${testId}-toggle`}
        >
          {visible ? <EyeOff size={17} aria-hidden="true" /> : <Eye size={17} aria-hidden="true" />}
        </button>
      </div>
    </div>
  );
}

export default function Login({ onSwitch = () => { window.location.hash = "#register"; }, onRecover = () => { window.location.hash = "#recover"; }, onSuccess }) {
  const { login } = useAuth();
  const { t, dir } = useI18n("auth");
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [remember, setRemember] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(u.trim(), p, remember);
      onSuccess?.();
    } catch (err) {
      setError(err?.message || "تعذّر تسجيل الدخول.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell
      className="auth-ui-shell auth-ui-login"
      title={t("مرحبًا بعودتك")}
      subtitle={t("سجّل الدخول للمتابعة إلى مساحة عملك في rsvx7.")}
      footer={(
        <div className="auth-ui-link-row">
          <button type="button" onClick={onSwitch} className="auth-ui-link" data-testid="link-register">{t("إنشاء حساب جديد")}</button>
        </div>
      )}
    >
      <Panel className="auth-ui-card" dir={dir}>
        {error && <StatusNote tone="error">{t(error)}</StatusNote>}
        <form onSubmit={submit} className="ds-form-stack auth-ui-form" noValidate>
          <div className="ds-field auth-ui-field">
            <label className="auth-ui-label" htmlFor="login-username">{t("اسم المستخدم")}</label>
            <input
              id="login-username"
              data-testid="login-username"
              className="ds-input auth-ui-input"
              placeholder={t("اسم المستخدم")}
              value={u}
              onChange={(event) => setU(event.target.value)}
              autoComplete="username"
              dir="ltr"
              required
              minLength={3}
              spellCheck="false"
            />
            <span className="auth-ui-hint">{t("اكتب المعرّف كما هو، من دون مسافات.")}</span>
          </div>
          <PasswordField
            id="login-password"
            testId="login-password"
            value={p}
            onChange={(event) => setP(event.target.value)}
            autoComplete="current-password"
            onRecover={onRecover}
          />
          <label className="auth-ui-check">
            <input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} data-testid="login-remember" />
            {t("تذكّر هذا الجهاز")}
          </label>
          <ActionButton type="submit" loading={busy} tone="primary" className="auth-ui-submit" data-testid="login-submit">
            {busy ? t("جارٍ تسجيل الدخول…") : t("تسجيل الدخول")}
          </ActionButton>
        </form>
      </Panel>
    </AuthShell>
  );
}
