import React, { act } from "react";
import { createRoot } from "react-dom/client";
import AdminAISettings from "./AdminAISettings";
import { setLanguage, translate } from "@/i18n/runtime";
import "@/i18n/catalogs/admin";

const mockAuthFetch = jest.fn();
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ authFetch: mockAuthFetch, user: { _id: "admin-language", username: "owner", role: "super_admin" } }) }));
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
jest.mock("@/components/ui/button", () => ({ Button: (props) => require("react").createElement("button", props) }));
jest.mock("@/components/ui/input", () => ({ Input: (props) => require("react").createElement("input", props) }));
jest.mock("@/components/ui/label", () => ({ Label: (props) => require("react").createElement("label", props) }));
jest.mock("@/components/ui/badge", () => ({ Badge: (props) => require("react").createElement("span", props) }));

const reply = (json, ok = true) => ({ ok, json: async () => json });
const initial = { model: "nousresearch/hermes-3-llama-3.1-405b", base_url: "https://openrouter.ai/api/v1", key_configured: true, context_length: 131072 };
let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  setLanguage("en");
  mockAuthFetch.mockReset().mockResolvedValue(reply(initial));
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  setLanguage("ar");
});

test("admin renders English UI with LTR direction and localized numbers without changing model IDs", async () => {
  await act(async () => root.render(<AdminAISettings />));

  expect(container.querySelector("section").dir).toBe("ltr");
  expect(container.textContent).toContain("AI model settings");
  expect(container.textContent).toContain("Save model");
  expect(container.textContent).toContain("131,072 tokens");
  expect(container.querySelector('[data-testid="ai-active-model"]').textContent).toBe(initial.model);
  expect(container.textContent).not.toContain("إعدادات نموذج الذكاء الاصطناعي");
});

test("admin namespace keeps dynamic identifiers intact while translating the surrounding label", () => {
  expect(translate("إجراءات {username}", { username: "alice_01" }, "admin", "en")).toBe("Actions for alice_01");
  expect(translate("تعديل القسيمة {code}", { code: "WELCOME10K" }, "admin", "en")).toBe("Edit coupon WELCOME10K");
});
